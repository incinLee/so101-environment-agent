@echo off
echo Starting the SO101 local input screen...
echo Keep this window open while using the app.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0start_app.ps1"
set "APP_EXIT=%ERRORLEVEL%"
echo.
echo SO101 app stopped. Exit code: %APP_EXIT%
echo Startup and error logs are in the logs folder next to this file.
pause
exit /b %APP_EXIT%
