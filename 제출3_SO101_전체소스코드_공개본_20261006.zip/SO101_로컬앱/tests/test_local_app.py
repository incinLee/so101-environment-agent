"""Loopback HTTP and evidence-contract tests for the local SO-101 interface.

Uses real classifier and scene validation, read-only historical MuJoCo reports,
and an explicitly synthetic artifact fixture. Does not run physics, training,
native viewer windows, hardware, or outside-network requests.
"""
from __future__ import annotations

import argparse
import copy
from datetime import datetime, timezone
import http.client
import importlib.util
import io
import json
import os
from pathlib import Path
import socket
import tempfile
import threading
import time
import unittest
from unittest import mock

HERE = Path(__file__).resolve().parent
WORKSPACE = Path(__file__).resolve().parents[2]
PACKAGED_APP = HERE.parent / "app.py"
APP_PATH = PACKAGED_APP if PACKAGED_APP.is_file() else WORKSPACE / "outputs/SO101_로컬앱/app.py"
spec = importlib.util.spec_from_file_location("so101_local_app_under_test", APP_PATH)
app = importlib.util.module_from_spec(spec)
spec.loader.exec_module(app)
ROOT = app.project_path(os.environ.get("SO101_PROJECT_ROOT"))


def write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    if isinstance(data, bytes):
        path.write_bytes(data)
    else:
        path.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")


class HttpAppTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temporary = tempfile.TemporaryDirectory(prefix="so101-ui-test-", dir=Path(__file__).parent)
        cls.fixture_root = Path(cls.temporary.name)
        cls.fixture_run = cls.fixture_root / "runs/synthetic_fixture"
        cls.video_bytes = bytes(range(256)) * 3
        write(cls.fixture_run / "workflow_report.json", {
            "goal": "synthetic artifact fixture; not simulation evidence",
            "status": "passed", "baseline": {"successes": 1, "trials": 1},
            "physical_execution": "not_run",
        })
        write(cls.fixture_run / "video/simulation.mp4", cls.video_bytes)
        write(cls.fixture_run / "video/video_report.json", {
            "task_success": True, "video": {"video_path": "simulation.mp4", "video_status": "synthetic_test_fixture"},
        })
        write(cls.fixture_run / "private.npz", b"NOT SERVED")
        write(cls.fixture_root / "outside.json", {"private_fixture": True})
        # Actual app, classifier and validator; substitute only a disposable runs tree.
        cls.server = app.make_server(ROOT, 0)
        cls.agent = cls.server.agent
        cls.agent.root = cls.fixture_root
        cls.agent.runs_dir = cls.fixture_root / "runs"
        cls.agent.log_dir = cls.fixture_root / "logs"
        cls.agent.log_dir.mkdir()
        cls.port = cls.server.server_address[1]
        cls.thread = threading.Thread(target=cls.server.serve_forever, kwargs={"poll_interval": 0.05}, daemon=True)
        cls.thread.start()
        # Warm actual model before multithreaded requests; no external model call.
        cls.agent.classify(app.GOALS[0])

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.agent.close()
        cls.server.server_close()
        cls.thread.join(2)
        cls.temporary.cleanup()

    def request(self, method, path, payload=None, *, headers=None, authenticated=True, raw=None):
        default_headers = {"Host": f"127.0.0.1:{self.port}"}
        if method == "POST":
            default_headers["Content-Type"] = "application/json"
            if authenticated:
                default_headers["X-Session-Token"] = self.agent.token
            raw = raw if raw is not None else json.dumps(payload, ensure_ascii=False).encode("utf-8")
        default_headers.update(headers or {})
        connection = http.client.HTTPConnection("127.0.0.1", self.port, timeout=5)
        try:
            connection.request(method, path, body=raw, headers=default_headers)
            response = connection.getresponse()
            data = response.read()
            return response.status, dict(response.getheaders()), data
        finally:
            connection.close()

    def post(self, path, payload, **kwargs):
        status, headers, raw = self.request("POST", path, payload, **kwargs)
        return status, json.loads(raw.decode("utf-8"))

    def test_health_binds_loopback(self):
        self.assertEqual(self.server.server_address[0], "127.0.0.1")
        status, headers, raw = self.request("GET", "/api/health")
        self.assertEqual(status, 200)
        self.assertEqual(json.loads(raw)["status"], "ready")
        self.assertEqual(headers["X-Content-Type-Options"], "nosniff")
        self.assertIn("frame-ancestors 'none'", headers["Content-Security-Policy"])

    def test_existing_listener_cannot_share_an_app_origin(self):
        if os.name == "nt":
            self.assertFalse(self.server.allow_reuse_address)
            self.assertEqual(self.server.socket.getsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE), 1)
        with self.assertRaises(OSError):
            app.make_server(ROOT, self.port)
        alternate = app.make_server(ROOT, 0)
        try:
            self.assertNotEqual(alternate.server_address[1], self.port)
            self.assertNotEqual(alternate.agent.token, self.agent.token)
        finally:
            alternate.agent.close()
            alternate.server_close()
        self.assertEqual(self.request("GET", "/api/health")[0], 200)

    def test_main_occupied_port_falls_back_and_reports_new_address(self):
        made, written = [], []
        original_make = app.make_server

        def make_without_blocking(root, port, **kwargs):
            server = original_make(root, port, **kwargs)
            server.serve_forever = lambda **kwargs: None
            made.append(server)
            return server

        args = argparse.Namespace(project_root=str(ROOT), port=self.port, no_browser=True, viewer_seconds=300)
        with mock.patch.object(app.argparse.ArgumentParser, "parse_args", return_value=args), \
                mock.patch.object(app, "make_server", side_effect=make_without_blocking) as constructor, \
                mock.patch.object(app, "write_json", side_effect=lambda path, data: written.append((path, data))), \
                mock.patch("sys.stdout", new=io.StringIO()):
            app.main()
        self.assertEqual([call.args[1] for call in constructor.call_args_list], [self.port, 0])
        self.assertEqual(len(made), 1)
        chosen_port = made[0].server_address[1]
        self.assertNotEqual(chosen_port, self.port)
        self.assertEqual(written[0][1]["url"], f"http://127.0.0.1:{chosen_port}/")
        self.assertEqual(written[0][1]["app_version"], app.APP_VERSION)
        self.assertTrue(made[0].agent.closed)

    def test_session_reports_actual_capabilities_and_token(self):
        status, _, raw = self.request("GET", "/api/session")
        session = json.loads(raw)
        self.assertEqual(status, 200)
        self.assertEqual(session["token"], self.agent.token)
        self.assertEqual(session["goals"], app.GOALS)
        self.assertEqual(session["default_scene"], self.agent.defaults)
        self.assertEqual(session["default_workers"], 8)
        self.assertEqual(session["maximum_workers"], 8)

    def test_workers_are_bounded_integers_and_omission_defaults_to_eight(self):
        previous = len(self.agent.jobs)
        for workers in (0, -1, 9, True, False, 8.0, "8", None, [8]):
            with self.subTest(workers=workers):
                status, response = self.post("/api/run", {"goal": app.GOALS[0], "workers": workers})
                self.assertEqual(status, 400)
                self.assertIn("error", response)
        self.assertEqual(len(self.agent.jobs), previous)
        self.assertEqual(self.agent.validate_request({"goal": app.GOALS[0]})["workers"], 8)
        for workers in range(1, 9):
            validated = self.agent.validate_request({"goal": app.GOALS[0], "workers": workers})
            self.assertEqual(validated["workers"], workers)
            self.assertFalse(validated["train_policy"])

    def parallel_fixture(self, name="synthetic_parallel", *, complete=False):
        run = self.fixture_root / "runs" / name
        slots = [{"slot": seed, "seed": seed, "pid": 100 + seed, "status": "running",
                  "evidence_directory": f"baseline/seed-{seed}"} for seed in range(8)]
        write(run / "baseline/parallel_progress.json", {
            "requested_workers": 8, "effective_workers": 8, "completed": 0, "total": 9,
            "status": "running", "evidence_kind": "simulation", "slots": slots,
        })
        for seed in range(8):
            # Disposable synthetic bytes test access control, not visual/physics correctness.
            write(run / f"baseline/seed-{seed}/camera_initial.png", b"synthetic PNG access fixture")
        if complete:
            write(run / "workflow_report.json", {"status": "passed", "baseline": {"successes": 9, "trials": 9},
                                                 "policy_evaluation": {"successes": 0, "trials": 2}})
        return run

    def test_incomplete_progress_has_eight_real_path_slots_and_keeps_nine_total(self):
        self.parallel_fixture()
        progress = self.agent.parallel_progress("synthetic_parallel")
        self.assertEqual(progress["effective_workers"], 8)
        self.assertEqual(progress["total"], 9)
        self.assertEqual(len(progress["slots"]), 8)
        self.assertEqual(progress["collection"], "scripted_baseline")
        self.assertEqual(progress["slots"][7]["seed"], 7)
        self.assertIn("/baseline/seed-7/camera_initial.png?key=", progress["slots"][7]["images"]["initial"])
        self.assertNotIn(self.agent.token, json.dumps(progress))

    def test_incomplete_camera_requires_path_bound_authentication(self):
        self.parallel_fixture("synthetic_camera_auth")
        relative = "baseline/seed-0/camera_initial.png"
        url = self.agent.camera_url("synthetic_camera_auth", relative)
        status, headers, body = self.request("GET", url)
        self.assertEqual(status, 200)
        self.assertEqual(headers["Content-Type"], "image/png")
        self.assertEqual(body, b"synthetic PNG access fixture")
        for denied in (url.split("?")[0], url + "wrong", url.replace("seed-0", "seed-1")):
            with self.subTest(path=denied):
                self.assertEqual(self.request("GET", denied)[0], 403)
        # Existing report-gated endpoint cannot expose this incomplete run.
        self.assertEqual(self.request("GET", "/artifact/synthetic_camera_auth/" + relative)[0], 404)

    def test_camera_whitelist_blocks_traversal_and_unregistered_seed(self):
        run = self.parallel_fixture("synthetic_camera_paths")
        write(run / "secret.json", {"private_fixture": True})
        write(run / "baseline/seed-8/camera_initial.png", b"unregistered fixture")
        for relative in ("secret.json", "baseline/seed-0/../../secret.json", "baseline/seed-9/camera_initial.png",
                         "baseline/seed-0/camera_not_allowed.png", "baseline/seed-0/camera_initial.png/../secret.json",
                         "baseline%5cseed-0%5ccamera_initial.png", "C:%5cWindows%5csecret.png"):
            with self.subTest(relative=relative):
                url = "/parallel-camera/synthetic_camera_paths/" + relative + "?key=" + self.agent.camera_key("synthetic_camera_paths", relative)
                status, _, body = self.request("GET", url)
                self.assertIn(status, (400, 403, 404))
                self.assertNotIn(b"private_fixture", body)
        url = self.agent.camera_url("synthetic_camera_paths", "baseline/seed-8/camera_initial.png")
        self.assertEqual(self.request("GET", url)[0], 404)

    def test_progress_rejects_invalid_or_untrusted_slot_paths(self):
        run = self.parallel_fixture("synthetic_progress_invalid")
        good = app.read_json(run / "baseline/parallel_progress.json")
        variants = []
        for key, value in (("requested_workers", True), ("effective_workers", 9), ("completed", -1),
                           ("total", 10), ("evidence_kind", "real")):
            variants.append({**good, key: value})
        unsafe = copy.deepcopy(good)
        unsafe["slots"][0]["evidence_directory"] = "../../outside"
        variants.append(unsafe)
        for invalid in variants:
            with self.subTest(invalid=invalid):
                write(run / "baseline/parallel_progress.json", invalid)
                self.assertIsNone(self.agent.parallel_progress("synthetic_progress_invalid"))

    def test_completed_summary_preserves_parallel_and_policy_separation(self):
        self.parallel_fixture("synthetic_parallel_completed", complete=True)
        status, _, raw = self.request("GET", "/api/runs/synthetic_parallel_completed")
        summary = json.loads(raw)
        self.assertEqual(status, 200)
        self.assertEqual(summary["parallel"]["effective_workers"], 8)
        self.assertEqual(len(summary["parallel"]["episodes"]), 8)
        self.assertEqual(summary["parallel"]["training_batch_size"], 64)
        self.assertEqual(summary["parallel"]["learning_method"], "imitation_learning")
        self.assertEqual((summary["policy_successes"], summary["policy_trials"]), (0, 2))

    def test_job_poll_includes_partial_parallel_progress(self):
        self.parallel_fixture("synthetic_job_progress")
        self.agent.jobs["synthetic_job_progress"] = {
            "id": "synthetic_job_progress", "run_id": "synthetic_job_progress", "status": "running",
            "phase": "workflow", "log_file": str(self.agent.log_dir / "missing.log"),
        }
        try:
            status, _, raw = self.request("GET", "/api/jobs/synthetic_job_progress")
            self.assertEqual(status, 200)
            self.assertEqual(len(json.loads(raw)["parallel"]["slots"]), 8)
        finally:
            self.agent.jobs.pop("synthetic_job_progress")

    def test_worker_setting_is_forwarded_as_typed_cli_argument(self):
        called = []

        def fake_cli(job_id, arguments, timeout):
            called.append(arguments)
            run = self.agent.run_path(self.agent.jobs[job_id]["run_id"])
            write(run / "workflow_report.json", {"status": "passed", "goal": app.GOALS[1]})
            return 0

        with mock.patch.object(self.agent, "_command", fake_cli):
            job = self.agent.start({"goal": app.GOALS[1], "workers": 8, "train_policy": True})
            deadline = time.monotonic() + 3
            while self.agent.active_id and time.monotonic() < deadline:
                time.sleep(0.01)
            self.assertEqual(self.agent.jobs[job["job_id"]]["status"], "completed")
        self.assertEqual(called[0][called[0].index("--workers") + 1], "8")

    def test_grid_uses_text_nodes_and_full_eight_defaults(self):
        source = (APP_PATH.parent / "static/app.js").read_text(encoding="utf-8")
        html = (APP_PATH.parent / "static/index.html").read_text(encoding="utf-8")
        self.assertNotIn("innerHTML", source)
        self.assertNotIn("insertAdjacentHTML", source)
        self.assertIn('value="full" checked', html)
        self.assertIn('value="8" selected', html)
        self.assertIn("safeURL(available[selected])", source)

    def test_actual_supported_intent(self):
        status, result = self.post("/api/intent", {"goal": app.GOALS[0]})
        self.assertEqual(status, 200)
        self.assertEqual(result["intent"], "tray_transfer")
        self.assertTrue(result["ai_used"])
        self.assertFalse(result["llm_used"])
        self.assertFalse(result["hardware_access"])

    def test_actual_response_intent(self):
        status, result = self.post("/api/intent", {"goal": app.GOALS[1]})
        self.assertEqual(status, 200)
        self.assertEqual(result["intent"], "response_calibration")

    def test_unsupported_and_hardware_goals_do_not_start(self):
        for goal in ("오늘 날씨 알려줘", "실제 로봇 모터를 켜줘"):
            with self.subTest(goal=goal):
                status, result = self.post("/api/intent", {"goal": goal})
                self.assertEqual(status, 200)
                self.assertEqual(result["intent"], "unsupported")
                previous = len(self.agent.jobs)
                status, result = self.post("/api/run", {"goal": goal})
                self.assertEqual(status, 400)
                self.assertIn("error", result)
                self.assertEqual(len(self.agent.jobs), previous)

    def test_post_requires_current_token(self):
        for options in ({"authenticated": False}, {"headers": {"X-Session-Token": "wrong"}}):
            with self.subTest(options=options):
                status, result = self.post("/api/intent", {"goal": app.GOALS[0]}, **options)
                self.assertEqual(status, 403)
                self.assertIn("error", result)

    def test_cross_origin_post_rejected(self):
        status, _ = self.post("/api/intent", {"goal": app.GOALS[0]}, headers={"Origin": "https://other.example"})
        self.assertEqual(status, 403)

    def test_same_origin_post_allowed(self):
        for hostname in ("127.0.0.1", "localhost"):
            with self.subTest(hostname=hostname):
                status, _ = self.post("/api/intent", {"goal": app.GOALS[0]}, headers={"Origin": f"http://{hostname}:{self.port}"})
                self.assertEqual(status, 200)

    def test_unrecognized_host_rejected_for_read_and_write(self):
        status, _, _ = self.request("GET", "/api/session", headers={"Host": "attacker.example"})
        self.assertEqual(status, 403)
        status, _ = self.post("/api/intent", {"goal": app.GOALS[0]}, headers={"Host": "attacker.example"})
        self.assertEqual(status, 403)

    def test_content_type_and_body_format_validated(self):
        status, _ = self.post("/api/intent", {"goal": app.GOALS[0]}, headers={"Content-Type": "text/plain"})
        self.assertEqual(status, 400)
        for raw in (b"[1,2]", b"null", b"{broken}", b"\xff"):
            with self.subTest(raw=raw):
                status, _, _ = self.request("POST", "/api/intent", raw=raw)
                self.assertEqual(status, 400)

    def test_input_size_bounded(self):
        status, _, _ = self.request("POST", "/api/intent", raw=b"x" * 32769)
        self.assertEqual(status, 400)
        status, _, _ = self.request("POST", "/api/intent", raw=b"", headers={"Content-Length": "0"})
        self.assertEqual(status, 400)

    def test_nonfinite_json_rejected_before_validation(self):
        for value in (b"NaN", b"Infinity", b"-Infinity"):
            with self.subTest(value=value):
                raw = b'{"goal":"part transfer","scene":{"object_mass_kg":' + value + b'}}'
                status, _, _ = self.request("POST", "/api/run", raw=raw)
                self.assertEqual(status, 400)

    def test_intent_goal_shape_validated(self):
        for payload in ({"goal": None}, {"goal": ""}, {"goal": "x" * 1001}, {"goal": "ok", "extra": True}, {"goal": "ok\u0001"}):
            with self.subTest(payload=repr(payload)[:80]):
                status, _ = self.post("/api/intent", payload)
                self.assertEqual(status, 400)

    def test_training_mode_is_boolean_and_fields_are_whitelisted(self):
        for payload in ({"goal": app.GOALS[0], "train_policy": "false"},
                        {"goal": app.GOALS[0], "train_policy": 1},
                        {"goal": app.GOALS[0], "extra": "value"},
                        {"goal": app.GOALS[0], "scene": {"hold_seconds": 0.1}},
                        {"goal": app.GOALS[0], "scene": {"timestep_s": 0.01}}):
            with self.subTest(payload=payload):
                status, _ = self.post("/api/run", payload)
                self.assertEqual(status, 400)

    def test_actual_geometry_validator_rejects_invalid_scene(self):
        changes = (
            {"target_center_m": [0.20, -0.07]},
            {"object_mass_kg": 0.201},
            {"object_mass_kg": True},
            {"source_center_m": [0.2]},
            {"source_center_m": [0.5, 0.5]},
            {"object_size_m": [0.2, 0.2, 0.2]},
        )
        previous = len(self.agent.jobs)
        for scene in changes:
            with self.subTest(scene=scene):
                status, result = self.post("/api/run", {"goal": app.GOALS[0], "scene": scene})
                self.assertEqual(status, 400)
                self.assertIn("error", result)
        self.assertEqual(len(self.agent.jobs), previous)

    def test_valid_scene_uses_meter_values_without_mutating_defaults(self):
        defaults = copy.deepcopy(self.agent.defaults)
        payload = {"goal": app.GOALS[0], "scene": {"target_center_m": [0.2, 0.08]}}
        validated = self.agent.validate_request(payload)
        self.assertEqual(validated["scene"]["target_center_m"], [0.2, 0.08])
        validated["scene"]["source_center_m"][0] = 0.3
        self.assertEqual(self.agent.defaults, defaults)
        self.assertEqual(payload["scene"], {"target_center_m": [0.2, 0.08]})

    def test_static_content_types_and_head(self):
        for path, content_type in (("/app.js", "text/javascript"), ("/style.css", "text/css"), ("/", "text/html")):
            with self.subTest(path=path):
                status, headers, body = self.request("GET", path)
                self.assertEqual(status, 200)
                self.assertTrue(headers["Content-Type"].startswith(content_type))
                self.assertGreater(len(body), 0)
                head_status, head_headers, head_body = self.request("HEAD", path)
                self.assertEqual(head_status, 200)
                self.assertEqual(head_headers["Content-Length"], headers["Content-Length"])
                self.assertEqual(head_body, b"")

    def test_whitelisted_artifact_read_and_mp4_type(self):
        status, headers, body = self.request("GET", "/artifact/synthetic_fixture/video/simulation.mp4")
        self.assertEqual(status, 200)
        self.assertEqual(body, self.video_bytes)
        self.assertEqual(headers["Content-Type"], "video/mp4")

    def test_path_traversal_and_unapproved_extension_rejected(self):
        paths = (
            "/artifact/synthetic_fixture/../../outside.json",
            "/artifact/synthetic_fixture/%2e%2e/%2e%2e/outside.json",
            "/artifact/synthetic_fixture/%2e%2e%5coutside.json",
            "/artifact/synthetic_fixture/C:%5cWindows%5csecret.json",
            "/artifact/synthetic_fixture/private.npz",
            "/artifact/../outside.json",
            "/artifact/synthetic_fixture//outside.json",
            "/api/runs/%2e%2e",
        )
        for path in paths:
            with self.subTest(path=path):
                status, _, body = self.request("GET", path)
                self.assertIn(status, (400, 404))
                self.assertNotIn(b"private_fixture", body)
                self.assertNotIn(b"NOT SERVED", body)

    def test_missing_report_cannot_expose_arbitrary_run_files(self):
        write(self.fixture_root / "runs/no_report/secret.json", {"private_fixture": True})
        status, _, body = self.request("GET", "/artifact/no_report/secret.json")
        self.assertEqual(status, 404)
        self.assertNotIn(b"private_fixture", body)

    def test_cancelled_app_job_takes_priority_over_successful_workflow_in_history(self):
        run = self.fixture_root / "runs/synthetic_cancelled"
        write(run / "workflow_report.json", {
            "goal": "synthetic completed workflow with later cancellation",
            "status": "passed", "workflow_execution": "passed",
            "baseline": {"successes": 1, "trials": 1},
        })
        write(run / "ui_job.json", {"status": "cancelled", "cancel_requested": True})
        status, _, raw = self.request("GET", "/api/runs/synthetic_cancelled")
        summary = json.loads(raw)
        self.assertEqual(status, 200)
        self.assertEqual(summary["workflow_status"], "passed")
        self.assertEqual(summary["app_job_status"], "cancelled")
        # Preserve the successful workflow evidence while identifying the app run as stopped.
        self.assertEqual((summary["baseline_successes"], summary["baseline_trials"]), (1, 1))
        status, _, raw = self.request("GET", "/api/runs")
        cancelled = next(row for row in json.loads(raw)["runs"] if row["id"] == "synthetic_cancelled")
        self.assertEqual(status, 200)
        self.assertEqual(cancelled["status"], "cancelled")

    def test_mp4_byte_ranges(self):
        cases = (("bytes=0-9", 0, 9), ("bytes=10-", 10, 767), ("bytes=-5", 763, 767), ("bytes=760-9999", 760, 767))
        for header, start, end in cases:
            with self.subTest(header=header):
                status, headers, body = self.request("GET", "/artifact/synthetic_fixture/video/simulation.mp4", headers={"Range": header})
                self.assertEqual(status, 206)
                self.assertEqual(body, self.video_bytes[start:end + 1])
                self.assertEqual(headers["Content-Range"], f"bytes {start}-{end}/768")
                self.assertEqual(int(headers["Content-Length"]), end - start + 1)

    def test_invalid_byte_ranges_rejected(self):
        for header in ("bytes=768-", "bytes=20-10", "bytes=-0", "bytes=", "bytes=0-1,3-4", "other=0-1"):
            with self.subTest(header=header):
                status, _, _ = self.request("GET", "/artifact/synthetic_fixture/video/simulation.mp4", headers={"Range": header})
                self.assertEqual(status, 416)

    def test_unknown_job_and_endpoint_are_404(self):
        for method, path, payload in (("GET", "/api/jobs/missing", None), ("GET", "/missing", None), ("POST", "/api/missing", {})):
            with self.subTest(path=path):
                status, _, _ = self.request(method, path, payload)
                self.assertEqual(status, 404)

    def test_single_active_job_conflict_and_cooperative_cancel(self):
        entered, released = threading.Event(), threading.Event()

        def controlled_worker(job_id):
            self.agent.update(job_id, status="running", phase="workflow")
            entered.set()
            released.wait(5)
            self.agent.update(job_id, status="cancelled", phase="cancelled")
            with self.agent.lock:
                self.agent.active_id = None
                self.agent.workers.pop(job_id, None)

        with mock.patch.object(self.agent, "_work", controlled_worker):
            try:
                status, first = self.post("/api/run", {"goal": app.GOALS[0]})
                self.assertEqual(status, 202)
                self.assertTrue(entered.wait(2))
                status, second = self.post("/api/run", {"goal": app.GOALS[0]})
                self.assertEqual(status, 409)
                self.assertIn("error", second)
                status, response = self.post("/api/cancel", {"job_id": first["job_id"]})
                self.assertEqual(status, 200)
                self.assertEqual(response["status"], "cancel_requested")
                status, _, raw = self.request("GET", "/api/jobs/" + first["job_id"])
                job = json.loads(raw)
                self.assertEqual(status, 200)
                self.assertTrue(job["cancel_requested"])
                # Cancellation deliberately does not claim immediate process termination.
                self.assertEqual(job["status"], "running")
            finally:
                released.set()
                for worker in list(self.agent.workers.values()):
                    worker.join(2)

    def test_final_record_write_failure_releases_active_job(self):
        real_write = app.write_json
        finished = threading.Event()

        def fake_cli(job_id, arguments, timeout):
            # Synthetic report exercises orchestration/finalizer; physics was not run.
            run = self.agent.run_path(self.agent.jobs[job_id]["run_id"])
            write(run / "workflow_report.json", {"status": "passed", "goal": app.GOALS[1]})
            return 0

        def fail_only_final_record(path, value):
            if path.name == "ui_job.json":
                finished.set()
                raise OSError("synthetic disk write failure")
            return real_write(path, value)

        with mock.patch.object(self.agent, "_command", fake_cli), mock.patch.object(app, "write_json", fail_only_final_record):
            first = self.agent.start({"goal": app.GOALS[1]})
            self.assertTrue(finished.wait(2))
            deadline = time.monotonic() + 2
            while self.agent.active_id and time.monotonic() < deadline:
                time.sleep(0.01)
            self.assertIsNone(self.agent.active_id)
            self.assertEqual(self.agent.jobs[first["job_id"]]["record_error"], "synthetic disk write failure")
            self.assertNotIn(first["job_id"], self.agent.workers)


class ActualEvidenceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.agent = app.LocalAgent(ROOT)

    @classmethod
    def tearDownClass(cls):
        cls.agent.close()

    def test_historical_baseline_and_learned_policy_are_separate(self):
        result = self.agent.summary("release-demo-20261006")
        raw = app.read_json(ROOT / "runs/release-demo-20261006/workflow_report.json")
        self.assertEqual((result["baseline_successes"], result["baseline_trials"]), (9, 9))
        self.assertEqual((result["policy_successes"], result["policy_trials"]), (0, 2))
        self.assertEqual(result["policy_task_status"], "failed")
        self.assertEqual(result["physical_execution"], "not_run")
        self.assertEqual(result["offline_mae"], raw["policy_evaluation"]["offline_test"]["mae"])
        self.assertEqual(result["parallel"]["effective_workers"], 1)
        self.assertTrue(result["parallel"]["legacy_sequential"])
        self.assertEqual(result["parallel"]["total"], 9)
        self.assertEqual(len(result["parallel"]["episodes"]), 9)

    def test_response_metrics_match_actual_independent_holdout(self):
        result = self.agent.summary("release-demo-20261006")
        raw = app.read_json(ROOT / "runs/release-demo-20261006/workflow_report.json")
        self.assertEqual(result["response_before_mse"], raw["response_fit"]["holdout_before"]["mse"])
        self.assertEqual(result["response_after_mse"], raw["response_fit"]["holdout_after"]["mse"])
        self.assertAlmostEqual(result["response_before_mse"], 1.583278182987686e-5, places=16)
        self.assertAlmostEqual(result["response_after_mse"], 1.1870612865446337e-6, places=16)

    def test_repaired_world_uses_repaired_photos(self):
        result = self.agent.summary("release-repair-20261006")
        self.assertGreater(len(result["repairs"]), 0)
        self.assertIn("baseline_retry/seed-0/camera_initial.png", result["urls"]["initial_image"])
        self.assertIn("environment_retry/scene.xml", result["urls"]["world"])

    def test_historical_video_is_separate_trial(self):
        result = self.agent.summary("my-check-20261005-223509013Z-c7d53166")
        self.assertEqual((result["baseline_successes"], result["baseline_trials"]), (1, 1))
        self.assertTrue(result["video_trial_task_success"])
        self.assertEqual(result["video_status"], "executed")
        self.assertEqual(result["policy_task_status"], "not_run")
        self.assertIsNone(result["policy_trials"])
        self.assertIn("video/simulation.mp4", result["urls"]["video"])


class ShutdownRaceTests(unittest.TestCase):
    def test_close_waits_until_new_worker_is_registered(self):
        # Deterministically pause worker construction. Shutdown must not finish
        # between reserving an active job and registering that job's worker.
        # No child command, physics, training or hardware is invoked.
        with tempfile.TemporaryDirectory(prefix="so101-ui-race-", dir=HERE) as temporary:
            agent = app.LocalAgent(ROOT)
            agent.root = Path(temporary)
            agent.runs_dir = agent.root / "runs"
            agent.log_dir = agent.root / "logs"
            agent.log_dir.mkdir()
            real_thread = threading.Thread
            constructing, release_constructor, close_completed = (threading.Event() for _ in range(3))
            start_errors, close_errors = [], []

            def controlled_constructor(*args, **kwargs):
                constructing.set()
                if not release_constructor.wait(2):
                    raise RuntimeError("test fixture constructor timed out")
                return real_thread(*args, **kwargs)

            def no_command_worker(job_id):
                with agent.lock:
                    if agent.active_id == job_id:
                        agent.active_id = None
                    agent.workers.pop(job_id, None)

            def starting():
                try:
                    agent.start({"goal": app.GOALS[0]})
                except Exception as error:
                    start_errors.append(error)

            def closing():
                try:
                    agent.close()
                except Exception as error:
                    close_errors.append(error)
                finally:
                    close_completed.set()

            starter = real_thread(target=starting, daemon=True)
            closer = real_thread(target=closing, daemon=True)
            with mock.patch.object(agent, "_work", no_command_worker), mock.patch.object(app.threading, "Thread", controlled_constructor):
                try:
                    starter.start()
                    self.assertTrue(constructing.wait(2))
                    closer.start()
                    self.assertFalse(close_completed.wait(0.15), "shutdown returned before the reserved job worker was registered")
                finally:
                    release_constructor.set()
                    starter.join(2)
                    closer.join(2)
            self.assertFalse(starter.is_alive())
            self.assertFalse(closer.is_alive())
            self.assertFalse(start_errors)
            self.assertFalse(close_errors)
            self.assertTrue(agent.closed)
            self.assertEqual(agent.workers, {})


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--result-json", type=Path, default=Path(__file__).with_name("api_test_result.json"))
    args = parser.parse_args()
    suite = unittest.defaultTestLoader.loadTestsFromModule(__import__(__name__))
    stream = io.StringIO()
    started = time.monotonic()
    result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
    report = {
        "tested_at_utc": datetime.now(timezone.utc).isoformat(),
        "status": "passed" if result.wasSuccessful() else "failed",
        "test_count": result.testsRun,
        "failures": [{"test": str(case), "detail": detail} for case, detail in result.failures],
        "errors": [{"test": str(case), "detail": detail} for case, detail in result.errors],
        "skipped": len(result.skipped),
        "duration_s": time.monotonic() - started,
        "scope": "Real loopback HTTP server, real local intent classifier and scene validator, read-only historical reports; synthetic disposable byte-range artifacts and job-control fixture.",
        "new_physics_runs": 0, "new_training_runs": 0, "hardware_access": False,
        "external_network_calls": 0,
        "native_viewer_validation": "not_run",
        "browser_ui_validation": "performed separately by parent agent",
        "stdout": stream.getvalue(),
    }
    args.result_json.parent.mkdir(parents=True, exist_ok=True)
    args.result_json.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(stream.getvalue())
    print(json.dumps({key: report[key] for key in ("status", "test_count", "skipped", "duration_s")}, ensure_ascii=False))
    raise SystemExit(0 if result.wasSuccessful() else 1)
