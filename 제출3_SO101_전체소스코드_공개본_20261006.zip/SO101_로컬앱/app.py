"""Loopback-only user interface for the existing, simulation-only SO-101 agent.

The interface accepts typed goals and declared scene parameters. It invokes
fixed CLI argument lists in the existing project environment; user text is
never a command. It does not install packages or connect physical devices.
"""
from __future__ import annotations

import argparse
import copy
from datetime import datetime, timezone
import hashlib
import hmac
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import mimetypes
from pathlib import Path
import re
import secrets
import socket
import subprocess
import sys
import threading
import time
from urllib.parse import parse_qs, quote, unquote, urlsplit
import webbrowser
import os

APP_NAME = "so101-local-agent"
APP_VERSION = "0.2.0"
APP_DIR = Path(__file__).resolve().parent
STATIC_DIR = APP_DIR / "static"
DEFAULT_PROJECT = APP_DIR.parent / "so101-env-agent"
EDITABLE_SCENE = {"source_center_m", "target_center_m", "object_size_m",
                  "object_mass_kg", "tray_size_m", "table_size_m"}
GOALS = ["부품을 한 트레이에서 다른 트레이로 옮겨줘", "시뮬레이션 관절 응답을 비교하고 지연을 추정해줘"]
RUN_ID = re.compile(r"[A-Za-z0-9_-]{1,100}\Z")
FILE_TYPES = {".html", ".json", ".jsonl", ".png", ".mp4", ".avi", ".xml", ".log"}
CAMERA_PHASES = ("initial", "close", "lift", "place", "hold")
PARALLEL_CAMERA = re.compile(r"(baseline(?:_retry)?)/seed-([0-8])/camera_(initial|close|lift|place|hold)\.png\Z")


class InputError(ValueError):
    pass


class BusyError(RuntimeError):
    pass


def read_json(path: Path):
    try:
        if not path.is_file() or path.stat().st_size > 2_000_000:
            return None
        return json.loads(path.read_text(encoding="utf-8-sig"))
    except (OSError, ValueError):
        return None


def write_json(path: Path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    scratch = path.with_name(path.name + ".tmp")
    scratch.write_text(json.dumps(value, ensure_ascii=False, allow_nan=False, indent=2) + "\n", encoding="utf-8")
    scratch.replace(path)


def inside(path: Path, parent: Path) -> Path:
    resolved = path.resolve()
    if not resolved.is_relative_to(parent.resolve()):
        raise InputError("파일 경로가 허용된 폴더를 벗어났습니다.")
    return resolved


def project_path(value=None):
    candidate = Path(value) if value else APP_DIR.parent / "so101-env-agent"
    if not (candidate / "src/robot_env_agent/cli.py").is_file() and value is None:
        candidate = DEFAULT_PROJECT
    candidate = candidate.resolve()
    if not (candidate / "src/robot_env_agent/cli.py").is_file():
        raise InputError("준비된 so101-env-agent 프로젝트를 찾지 못했습니다. --project-root 경로를 확인하세요.")
    return candidate


def import_backend(root):
    source = str(root / "src")
    if source not in sys.path:
        sys.path.insert(0, source)
    from robot_env_agent.intent import classify_goal
    from robot_env_agent.simulation import DEFAULT_SCENE, validate_scene
    return classify_goal, DEFAULT_SCENE, validate_scene


class LocalAgent:
    def __init__(self, root: Path, *, viewer_seconds=300):
        self.root = root.resolve()
        self.runs_dir = inside(self.root / "runs", self.root)
        self.classify, defaults, self.validate_scene = import_backend(self.root)
        self.defaults = copy.deepcopy(defaults)
        self.token = secrets.token_urlsafe(32)
        self.viewer_seconds = viewer_seconds
        self.jobs = {}
        self.lock = threading.RLock()
        self.active_id = None
        self.processes = {}
        self.viewers = {}
        self.workers = {}
        self.closed = False
        self.log_dir = APP_DIR / "logs"
        self.log_dir.mkdir(parents=True, exist_ok=True)

    def validate_request(self, request):
        if not isinstance(request, dict) or set(request) - {"goal", "scene", "train_policy", "workers"}:
            raise InputError("요청 항목을 확인하세요.")
        goal = request.get("goal")
        if not isinstance(goal, str) or not goal.strip() or len(goal) > 1000:
            raise InputError("목표 문장을 1~1,000자 이내로 입력하세요.")
        train = request.get("train_policy", False)
        if type(train) is not bool:
            raise InputError("학습 모드를 확인하세요.")
        workers = request.get("workers", 8)
        if type(workers) is not int or not 1 <= workers <= 8:
            raise InputError("동시 작업장 수는 1~8 사이의 정수로 입력하세요.")
        changes = request.get("scene", {})
        if not isinstance(changes, dict) or set(changes) - EDITABLE_SCENE:
            raise InputError("수정 가능한 작업장 조건만 입력하세요. 평가 기준과 물리 시간 설정은 고정입니다.")
        scene = {**copy.deepcopy(self.defaults), **changes}
        try:
            scene = self.validate_scene(scene)
            intent = self.classify(goal)
        except (ValueError, TypeError, OverflowError) as exc:
            messages = {
                "source and target trays overlap": "출발 트레이와 도착 트레이가 겹칩니다. 위치를 바꾸세요.",
                "tray must remain on the tabletop": "트레이가 작업면 밖으로 나갑니다. 위치 또는 작업면 크기를 확인하세요.",
                "part must fit inside the tray with wall clearance": "부품이 트레이 내부에 들어가지 않습니다. 치수를 확인하세요.",
            }
            raise InputError(messages.get(str(exc), "입력값을 확인하세요: " + str(exc))) from exc
        if intent["intent"] == "unsupported":
            raise InputError("현재 지원하는 목표는 부품 이송과 시뮬레이션 응답 비교입니다. 예시 문장을 사용하거나 목표를 다시 입력하세요.")
        return {"goal": goal.strip(), "scene": scene, "train_policy": train, "workers": workers, "intent_result": intent}

    def run_path(self, run_id):
        if not isinstance(run_id, str) or not RUN_ID.fullmatch(run_id):
            raise InputError("실행 이름을 확인하세요.")
        return inside(self.runs_dir / run_id, self.runs_dir)

    def artifact(self, run_id, relative):
        run = self.run_path(run_id)
        if not (run / "workflow_report.json").is_file():
            raise FileNotFoundError("실행 기록이 없습니다.")
        raw = Path(relative)
        if raw.is_absolute() or ".." in raw.parts or raw.suffix.lower() not in FILE_TYPES:
            raise InputError("허용되지 않은 결과 파일입니다.")
        path = inside(run / raw, run)
        if not path.is_file():
            raise FileNotFoundError("결과 파일이 아직 생성되지 않았습니다.")
        return path

    @staticmethod
    def url(run_id, relative):
        return "/artifact/" + quote(run_id, safe="") + "/" + quote(relative, safe="/")

    def camera_key(self, run_id, relative):
        return hmac.new(self.token.encode(), (run_id + "/" + relative).encode(), hashlib.sha256).hexdigest()

    def camera_url(self, run_id, relative):
        return "/parallel-camera/" + quote(run_id, safe="") + "/" + relative + "?key=" + self.camera_key(run_id, relative)

    def camera_artifact(self, run_id, relative, key):
        run = self.run_path(run_id)
        match = PARALLEL_CAMERA.fullmatch(relative)
        if not match or not isinstance(key, str) or not hmac.compare_digest(self.camera_key(run_id, relative), key):
            raise PermissionError("이 작업장 사진을 읽을 권한이 없습니다.")
        if not (run / "workflow_report.json").is_file():
            progress = self.parallel_progress(run_id)
            expected = match[1] + "/seed-" + match[2]
            if not progress or not any(s["evidence_directory"] == expected for s in progress["slots"]):
                raise FileNotFoundError("현재 실행의 작업장 사진이 아닙니다.")
        path = inside(run / relative, run)
        if not path.is_file():
            raise FileNotFoundError("작업장 사진을 아직 저장하지 않았습니다.")
        return path

    def episode_images(self, run_id, parent, seed):
        run = self.run_path(run_id)
        relative = f"{parent}/seed-{seed}"
        folder = inside(run / relative, run)
        images = {}
        for phase in CAMERA_PHASES:
            path = inside(folder / f"camera_{phase}.png", run)
            if path.is_file():
                images[phase] = self.camera_url(run_id, relative + "/" + path.name)
        report = read_json(folder / "simulation_report.json")
        return {"seed": seed, "evidence_directory": relative, "images": images,
                "task_success": report.get("task_success") if isinstance(report, dict) else None,
                "simulation_seconds": report.get("simulated_seconds") if isinstance(report, dict) else None}

    def parallel_progress(self, run_id):
        run = self.run_path(run_id)
        for parent in ("baseline_retry", "baseline"):
            data = read_json(run / parent / "parallel_progress.json")
            if not isinstance(data, dict) or data.get("evidence_kind") != "simulation":
                continue
            integers = ("requested_workers", "effective_workers", "completed", "total")
            if any(type(data.get(key)) is not int for key in integers):
                continue
            if not (1 <= data["effective_workers"] <= data["requested_workers"] <= 8
                    and 0 <= data["completed"] <= data["total"] <= 9):
                continue
            slots = data.get("slots")
            if not isinstance(slots, list) or len(slots) > 8:
                continue
            result = {key: data[key] for key in integers}
            result.update(status=data.get("status") if isinstance(data.get("status"), str) else "unknown",
                          evidence_kind="simulation", collection="scripted_baseline", parent=parent, slots=[])
            seen = set()
            valid = True
            for slot in slots:
                if not isinstance(slot, dict):
                    valid = False
                    break
                index, seed = slot.get("slot"), slot.get("seed")
                directory = slot.get("evidence_directory")
                if (type(index) is not int or not 0 <= index < data["effective_workers"] or index in seen
                        or type(seed) is not int or not 0 <= seed <= 8
                        or directory != f"{parent}/seed-{seed}"):
                    valid = False
                    break
                seen.add(index)
                row = self.episode_images(run_id, parent, seed)
                row.update(slot=index, status=slot.get("status") if isinstance(slot.get("status"), str) else "unknown",
                           pid=slot.get("pid") if type(slot.get("pid")) is int else None)
                result["slots"].append(row)
            if valid:
                result["slots"].sort(key=lambda row: row["slot"])
                return result
        return None

    def parallel_evidence(self, run_id, baseline):
        progress = self.parallel_progress(run_id)
        parent = progress["parent"] if progress else "baseline_retry" if (self.run_path(run_id) / "baseline_retry").is_dir() else "baseline"
        episodes = [self.episode_images(run_id, parent, seed) for seed in range(9)]
        episodes = [row for row in episodes if row["images"] or row["task_success"] is not None]
        if not progress:
            # Old records were collected sequentially. Do not relabel their
            # saved multi-episode snapshots as simultaneous simulation.
            total = baseline.get("trials") if type(baseline.get("trials")) is int else len(episodes)
            progress = {"requested_workers": 1, "effective_workers": 1, "completed": total,
                        "total": total, "status": "recorded", "evidence_kind": "simulation",
                        "collection": "scripted_baseline", "parent": parent, "slots": [], "legacy_sequential": True}
        return {**progress, "episodes": episodes, "displayed_episodes": min(8, len(episodes)),
                "learning_method": "imitation_learning", "training_batch_size": 64}

    def summary(self, run_id):
        run = self.run_path(run_id)
        report = read_json(run / "workflow_report.json")
        if not isinstance(report, dict):
            raise FileNotFoundError("실행 보고서가 아직 없습니다.")
        manifest = report.get("environment_manifest", {})
        world = None
        raw_world = manifest.get("world_path")
        if isinstance(raw_world, str):
            try:
                candidate = inside(Path(raw_world), run)
                if candidate.is_file():
                    world = candidate
            except InputError:
                pass
        urls = {"report_html": self.url(run_id, "index.html"),
                "report_json": self.url(run_id, "workflow_report.json")}
        if world:
            urls["world"] = self.url(run_id, world.relative_to(run).as_posix())
            urls["scene_manifest"] = self.url(run_id, (world.parent / "scene_manifest.json").relative_to(run).as_posix())
        video = read_json(run / "video/video_report.json")
        if isinstance(video, dict):
            relative = video.get("video", {}).get("video_path")
            if isinstance(relative, str):
                try:
                    self.artifact(run_id, "video/" + relative)
                    urls["video"] = self.url(run_id, "video/" + relative)
                    urls["video_report"] = self.url(run_id, "video/video_report.json")
                except (InputError, FileNotFoundError):
                    pass
        images = [("initial_image", "camera_initial.png"), ("final_image", "camera_hold.png")]
        for name, filename in images:
            for parent in ("video", "baseline_retry/seed-0", "baseline/seed-0"):
                relative = parent + "/" + filename
                try:
                    self.artifact(run_id, relative)
                except (InputError, FileNotFoundError):
                    continue
                urls[name] = self.url(run_id, relative)
                break
        baseline = report.get("baseline", {})
        policy = report.get("policy_evaluation", {})
        response = report.get("response_fit", {})
        ui_job = read_json(run / "ui_job.json") or {}
        # Raw response keys differ between historical revisions. Read the actual
        # independent evaluation metrics without guessing a percent improvement.
        response_before = response.get("holdout_before", {}).get("mse", response.get("holdout_mse_before"))
        response_after = response.get("holdout_after", {}).get("mse", response.get("holdout_mse_after"))
        for key in ("heldout", "holdout", "holdout_comparison", "validation"):
            obj = response.get(key)
            if isinstance(obj, dict):
                response_before = obj.get("before_mse", obj.get("baseline_mse", response_before))
                response_after = obj.get("after_mse", obj.get("fitted_mse", response_after))
        result = {
            "run_id": run_id, "goal": report.get("goal"),
            "intent_result": report.get("intent_result", {}), "trace": report.get("trace", []),
            "scene": manifest.get("scene", report.get("final_scene_assumptions", report.get("scene_assumptions", {}))),
            "requested_scene": report.get("scene_assumptions", {}), "repairs": report.get("repairs", []),
            "workflow_status": report.get("workflow_execution", report.get("status")),
            "app_job_status": ui_job.get("status"), "app_job_error": ui_job.get("error"),
            "baseline_successes": baseline.get("successes"), "baseline_trials": baseline.get("trials"),
            "policy_task_status": report.get("policy_task_status", "not_run"),
            "policy_successes": policy.get("successes"), "policy_trials": policy.get("trials"),
            "offline_mae": policy.get("offline_test", {}).get("mae"),
            "response_before_mse": response_before, "response_after_mse": response_after,
            "video_trial_task_success": video.get("task_success") if isinstance(video, dict) else None,
            "video_status": video.get("video", {}).get("video_status") if isinstance(video, dict) else None,
            "physical_execution": report.get("physical_execution", "not_run"),
            "error": report.get("error"), "urls": urls,
            "parallel": self.parallel_evidence(run_id, baseline),
        }
        return result

    def history(self):
        rows = []
        if not self.runs_dir.is_dir():
            return rows
        paths = sorted(self.runs_dir.iterdir(), key=lambda p: p.stat().st_mtime, reverse=True)
        for path in paths[:250]:
            if not path.is_dir() or not RUN_ID.fullmatch(path.name):
                continue
            try:
                s = self.summary(path.name)
            except (InputError, FileNotFoundError, OSError, AttributeError):
                continue
            rows.append({"id": path.name, "title": s["goal"], "status": s["app_job_status"] or s["workflow_status"],
                         "baseline_successes": s["baseline_successes"], "baseline_trials": s["baseline_trials"],
                         "policy_task_status": s["policy_task_status"],
                         "report_url": s["urls"].get("report_html"), "video_url": s["urls"].get("video"),
                         "image_url": s["urls"].get("initial_image")})
            if len(rows) == 15:
                break
        return rows

    def start(self, payload):
        request = self.validate_request(payload)
        with self.lock:
            if self.closed:
                raise BusyError("앱을 종료하는 중입니다.")
            if self.active_id:
                raise BusyError("진행 중인 실행이 있습니다. 완료되거나 중지된 뒤 다시 실행하세요.")
            job_id = secrets.token_hex(12)
            stamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
            run_id = "ui-" + stamp + "Z-" + job_id[:8]
            job = {"id": job_id, "run_id": run_id, "status": "queued", "phase": "queued",
                   "message": "실행을 준비합니다.", "request": request, "started_at": time.time(),
                   "log_file": str(self.log_dir / (job_id + ".log")), "cancel_requested": False}
            self.jobs[job_id] = job
            self.active_id = job_id
            worker = threading.Thread(target=self._work, args=(job_id,), daemon=True, name="agent-" + job_id[:8])
            self.workers[job_id] = worker
            worker.start()
        return {"job_id": job_id, "run_id": run_id, "status": "queued"}

    def update(self, job_id, **values):
        with self.lock:
            self.jobs[job_id].update(values)

    def _command(self, job_id, arguments, timeout):
        job = self.jobs[job_id]
        environment = dict(os.environ)
        environment["PYTHONPATH"] = str(self.root / "src")
        environment["PYTHONIOENCODING"] = "utf-8"
        command = [sys.executable, "-m", "robot_env_agent", *arguments]
        flags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
        with open(job["log_file"], "a", encoding="utf-8") as log:
            log.write("\nCOMMAND " + json.dumps(command, ensure_ascii=False) + "\n")
            log.flush()
            with self.lock:
                if self.closed:
                    raise RuntimeError("앱 종료 요청으로 실행을 중단했습니다.")
                proc = subprocess.Popen(command, cwd=self.root, env=environment, stdin=subprocess.DEVNULL,
                                        stdout=log, stderr=subprocess.STDOUT, creationflags=flags)
                self.processes[job_id] = proc
            try:
                return proc.wait(timeout=timeout)
            except subprocess.TimeoutExpired as exc:
                proc.terminate()
                try:
                    proc.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    proc.kill()
                    proc.wait(timeout=5)
                raise RuntimeError("제한 시간을 초과했습니다. 생성된 파일과 로그는 보존했습니다.") from exc
            finally:
                with self.lock:
                    self.processes.pop(job_id, None)

    def _work(self, job_id):
        job = self.jobs[job_id]
        run = self.run_path(job["run_id"])
        result = None
        try:
            self.update(job_id, status="running", phase="workflow",
                        message="목표를 분류하고 환경 생성·실행·평가를 수행합니다.")
            scene_dir = inside(self.runs_dir / "ui-inputs", self.runs_dir)
            scene_path = scene_dir / (job_id + ".json")
            write_json(scene_path, job["request"]["scene"])
            args = ["demo", "--goal=" + job["request"]["goal"], "--scene", str(scene_path),
                    "--output-dir", str(run.relative_to(self.root)), "--workers", str(job["request"]["workers"])]
            args += ["--epochs", "60"] if job["request"]["train_policy"] else ["--skip-training"]
            workflow_exit = self._command(job_id, args, 600 if job["request"]["train_policy"] else 300)
            if run.is_dir():
                write_json(run / "ui_input.json", {**job["request"], "interface_version": APP_VERSION})
            try:
                result = self.summary(job["run_id"])
            except FileNotFoundError:
                pass
            if self.jobs[job_id]["cancel_requested"]:
                self.update(job_id, status="cancelled", phase="cancelled", result=result,
                            message="현재 단계 완료 후 중지했습니다. 이미 생성한 기록은 보존했습니다.")
                return
            if result and job["request"]["intent_result"]["intent"] == "tray_transfer":
                report = read_json(run / "workflow_report.json")
                world = inside(Path(report["environment_manifest"]["world_path"]), run)
                self.update(job_id, phase="video", result=result,
                            message="같은 환경에서 별도의 새 기준 제어 시행을 녹화합니다.")
                video_exit = self._command(job_id, ["record-video", "--world", str(world), "--controller", "scripted",
                                                    "--seed", "0", "--fps", "15", "--output-dir",
                                                    str((run / "video").relative_to(self.root))], 120)
                result = self.summary(job["run_id"])
                if video_exit:
                    raise RuntimeError("영상 저장이 완료되지 않았습니다. 원본 실행 결과와 로그를 확인하세요.")
            if self.jobs[job_id]["cancel_requested"]:
                self.update(job_id, status="cancelled", phase="cancelled", result=result,
                            message="현재 단계 완료 후 중지했습니다. 이미 생성한 기록은 보존했습니다.")
                return
            if workflow_exit or result is None:
                raise RuntimeError((result or {}).get("error") or "작업 실행이 실패했습니다. 평가 기록과 로그를 보존했습니다.")
            self.update(job_id, status="completed", phase="completed", result=result,
                        message="실행과 기록 저장을 마쳤습니다. 기준 제어와 학습 정책의 작업 결과를 각각 확인하세요.")
        except Exception as exc:
            try:
                result = self.summary(job["run_id"])
            except (FileNotFoundError, InputError, AttributeError):
                pass
            self.update(job_id, status="failed", phase="failed", error=str(exc), result=result,
                        message="실행 중 오류가 발생했습니다. 입력과 로그는 보존했습니다.")
        finally:
            self.update(job_id, ended_at=time.time())
            try:
                if run.is_dir():
                    with self.lock:
                        saved = copy.deepcopy(self.jobs[job_id])
                    write_json(run / "ui_job.json", saved)
            except OSError as exc:
                self.update(job_id, record_error=str(exc))
            finally:
                with self.lock:
                    if self.active_id == job_id:
                        self.active_id = None
                    self.workers.pop(job_id, None)

    def job(self, job_id):
        with self.lock:
            if job_id not in self.jobs:
                raise FileNotFoundError("실행 작업을 찾지 못했습니다.")
            job = copy.deepcopy(self.jobs[job_id])
        path = Path(job.pop("log_file"))
        try:
            with path.open("rb") as log:
                length = path.stat().st_size
                log.seek(max(0, length - 16_384))
                job["logs"] = log.read().decode("utf-8", "replace")
        except OSError:
            job["logs"] = ""
        if job["status"] == "running" and job["phase"] == "workflow":
            current = read_json(self.run_path(job["run_id"]) / "workflow_state.json")
            if isinstance(current, dict) and isinstance(current.get("status"), str):
                job["phase"] = current["status"]
        job["parallel"] = self.parallel_progress(job["run_id"])
        return job

    def cancel(self, job_id):
        with self.lock:
            if job_id not in self.jobs:
                raise FileNotFoundError("실행 작업을 찾지 못했습니다.")
            if self.jobs[job_id]["status"] not in ("queued", "running"):
                return {"status": self.jobs[job_id]["status"], "message": "이미 종료된 실행입니다."}
            self.jobs[job_id]["cancel_requested"] = True
        return {"status": "cancel_requested", "message": "현재 단계 완료 후 중지합니다. 이미 생성한 기록은 보존합니다."}

    def viewer(self, run_id):
        run = self.run_path(run_id)
        report = read_json(run / "workflow_report.json")
        if not report or not report.get("environment_manifest", {}).get("world_path"):
            raise InputError("생성된 작업장이 없습니다.")
        world = inside(Path(report["environment_manifest"]["world_path"]), run)
        if not world.is_file():
            raise InputError("작업장 파일이 없습니다.")
        with self.lock:
            if self.closed:
                raise BusyError("앱을 종료하는 중입니다.")
            previous = self.viewers.get(run_id)
            if previous and previous.poll() is None:
                return {"status": "already_open", "seconds": self.viewer_seconds, "scene_only": True}
            environment = dict(os.environ, PYTHONPATH=str(self.root / "src"), PYTHONIOENCODING="utf-8")
            command = [sys.executable, "-m", "robot_env_agent", "view-sim", "--world", str(world),
                       "--seconds", str(self.viewer_seconds)]
            log_path = self.log_dir / ("viewer-" + run_id + ".log")
            with log_path.open("a", encoding="utf-8") as log:
                process = subprocess.Popen(command, cwd=self.root, env=environment,
                                           stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
                                           creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0)
            self.viewers[run_id] = process
        time.sleep(0.15)
        code = process.poll()
        if code is not None and code != 0:
            raise RuntimeError("작업장 창을 열지 못했습니다. 앱 logs 폴더의 viewer 기록을 확인하세요.")
        return {"status": "opened", "seconds": self.viewer_seconds, "scene_only": True}

    def close(self):
        with self.lock:
            self.closed = True
            processes = list(self.processes.values()) + list(self.viewers.values())
            workers = list(self.workers.values())
            active = self.active_id
            if active:
                self.jobs[active].update(cancel_requested=True, status="cancelled", phase="cancelled",
                                         message="앱 종료 요청으로 중단했습니다. 이미 생성한 파일은 보존합니다.",
                                         ended_at=time.time())
        for process in processes:
            if process.poll() is None:
                process.terminate()
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    process.kill()
        for worker in workers:
            worker.join(timeout=5)
        if active:
            with self.lock:
                saved = copy.deepcopy(self.jobs[active])
                saved.update(status="cancelled", phase="cancelled", cancel_requested=True,
                             message="앱 종료 요청으로 중단했습니다. 이미 생성한 파일은 보존합니다.")
                self.jobs[active].update(saved)
            write_json(self.log_dir / (active + ".cancelled.json"), saved)
            run = self.run_path(saved["run_id"])
            if run.is_dir():
                write_json(run / "ui_job.json", saved)


class Handler(BaseHTTPRequestHandler):
    server_version = "SO101Local/" + APP_VERSION

    def log_message(self, format, *args):
        # PowerShell 5.1 interprets native stderr as an error stream. Normal
        # HTTP access records go to stdout so they cannot stop the launcher.
        print("HTTP " + (format % args), flush=True)

    @property
    def agent(self):
        return self.server.agent

    def host_allowed(self):
        port = self.server.server_address[1]
        return self.headers.get("Host") in {f"127.0.0.1:{port}", f"localhost:{port}"}

    def headers_common(self):
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; media-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")
        self.send_header("Cache-Control", "no-store")

    def json(self, value, status=200):
        raw = json.dumps(value, ensure_ascii=False, allow_nan=False).encode("utf-8")
        self.send_response(status)
        self.headers_common()
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(raw)

    def body(self):
        if not self.host_allowed():
            raise PermissionError("이 앱은 현재 PC에서만 사용할 수 있습니다.")
        port = self.server.server_address[1]
        origin = self.headers.get("Origin")
        if origin and origin not in {f"http://127.0.0.1:{port}", f"http://localhost:{port}"}:
            raise PermissionError("다른 웹사이트의 실행 요청은 허용하지 않습니다.")
        if not secrets.compare_digest(self.headers.get("X-Session-Token", ""), self.agent.token):
            raise PermissionError("앱 화면을 새로고침한 뒤 다시 실행하세요.")
        if self.headers.get("Content-Type", "").split(";")[0].strip().lower() != "application/json":
            raise InputError("JSON 요청이 필요합니다.")
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError as exc:
            raise InputError("입력 크기를 확인하세요.") from exc
        if not 0 < length <= 32_768:
            raise InputError("입력 크기가 허용 범위를 벗어났습니다.")
        try:
            value = json.loads(self.rfile.read(length).decode("utf-8"),
                               parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))
        except (ValueError, UnicodeError) as exc:
            raise InputError("입력 내용을 읽을 수 없습니다.") from exc
        if not isinstance(value, dict):
            raise InputError("요청 형식을 확인하세요.")
        return value

    def file(self, path):
        size = path.stat().st_size
        start, end = 0, size - 1
        partial = False
        header = self.headers.get("Range")
        if header:
            match = re.fullmatch(r"bytes=(\d*)-(\d*)", header)
            if not match or not any(match.groups()):
                self.json({"error": "영상 범위 요청을 확인하세요."}, 416)
                return
            first, last = match.groups()
            if not first:
                start = max(0, size - int(last))
            else:
                start = int(first)
                end = min(int(last), size - 1) if last else size - 1
            if start > end or start >= size or end < 0:
                self.send_response(416)
                self.headers_common()
                self.send_header("Content-Range", f"bytes */{size}")
                self.send_header("Content-Length", "0")
                self.end_headers()
                return
            partial = True
        content_type = {".js": "text/javascript", ".css": "text/css", ".mp4": "video/mp4"}.get(path.suffix) or mimetypes.guess_type(path.name)[0] or "application/octet-stream"
        if path.suffix == ".jsonl":
            content_type = "text/plain"
        if path.suffix in {".html", ".css", ".js", ".json", ".jsonl", ".xml", ".log"}:
            content_type += "; charset=utf-8"
        self.send_response(206 if partial else 200)
        self.headers_common()
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(end - start + 1))
        self.send_header("Accept-Ranges", "bytes")
        if partial:
            self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
        self.end_headers()
        if self.command == "HEAD":
            return
        with path.open("rb") as file:
            file.seek(start)
            remaining = end - start + 1
            while remaining:
                chunk = file.read(min(remaining, 64 * 1024))
                if not chunk:
                    break
                self.wfile.write(chunk)
                remaining -= len(chunk)

    def do_HEAD(self):
        self.do_GET()

    def do_GET(self):
        try:
            if not self.host_allowed():
                raise PermissionError("현재 PC의 주소로 접속하세요.")
            path = unquote(urlsplit(self.path).path)
            if path in {"/", "/index.html", "/app.js", "/style.css", "/static/index.html", "/static/app.js", "/static/style.css"}:
                filename = "index.html" if path == "/" else path.rsplit("/", 1)[-1]
                self.file(STATIC_DIR / filename)
            elif path == "/api/health":
                self.json({"app_name": APP_NAME, "app_version": APP_VERSION, "status": "ready"})
            elif path == "/api/session":
                with self.agent.lock:
                    active = self.agent.active_id
                self.json({"app_name": APP_NAME, "app_version": APP_VERSION, "token": self.agent.token,
                           "project_root": str(self.agent.root), "default_scene": self.agent.defaults,
                           "default_workers": 8, "maximum_workers": 8,
                           "goals": GOALS, "runs": self.agent.history(), "active_job_id": active})
            elif path == "/api/runs":
                self.json({"runs": self.agent.history()})
            elif path.startswith("/api/runs/"):
                self.json(self.agent.summary(path[len("/api/runs/"):]))
            elif path.startswith("/api/jobs/"):
                self.json(self.agent.job(path[len("/api/jobs/"):]))
            elif path.startswith("/artifact/"):
                parts = path[len("/artifact/"):].split("/", 1)
                if len(parts) != 2:
                    raise InputError("결과 파일을 확인하세요.")
                self.file(self.agent.artifact(*parts))
            elif path.startswith("/parallel-camera/"):
                parts = path[len("/parallel-camera/"):].split("/", 1)
                if len(parts) != 2:
                    raise InputError("작업장 사진 경로를 확인하세요.")
                values = parse_qs(urlsplit(self.path).query).get("key", [])
                self.file(self.agent.camera_artifact(*parts, values[0] if len(values) == 1 else ""))
            else:
                raise FileNotFoundError("페이지를 찾지 못했습니다.")
        except (InputError, ValueError) as exc:
            self.json({"error": str(exc)}, 400)
        except PermissionError as exc:
            self.json({"error": str(exc)}, 403)
        except FileNotFoundError as exc:
            self.json({"error": str(exc)}, 404)
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception as exc:
            self.json({"error": "결과를 읽지 못했습니다: " + str(exc)}, 500)

    def do_POST(self):
        try:
            payload = self.body()
            path = urlsplit(self.path).path
            if path == "/api/intent":
                if set(payload) != {"goal"}:
                    raise InputError("목표 문장만 입력하세요.")
                self.json(self.agent.classify(payload["goal"]))
            elif path == "/api/run":
                self.json(self.agent.start(payload), 202)
            elif path == "/api/cancel":
                if set(payload) != {"job_id"}:
                    raise InputError("실행 작업을 확인하세요.")
                self.json(self.agent.cancel(payload["job_id"]))
            elif path == "/api/viewer":
                if set(payload) != {"run_id"}:
                    raise InputError("생성된 작업장을 선택하세요.")
                self.json(self.agent.viewer(payload["run_id"]))
            else:
                raise FileNotFoundError("지원하지 않는 작업입니다.")
        except (InputError, ValueError, TypeError) as exc:
            self.json({"error": str(exc)}, 400)
        except PermissionError as exc:
            self.json({"error": str(exc)}, 403)
        except BusyError as exc:
            self.json({"error": str(exc)}, 409)
        except FileNotFoundError as exc:
            self.json({"error": str(exc)}, 404)
        except Exception as exc:
            self.json({"error": str(exc)}, 500)


class LoopbackHTTPServer(ThreadingHTTPServer):
    # Windows SO_REUSEADDR can bind two listeners to the same address. That
    # would mix old/new app sessions at one browser origin instead of taking
    # the existing fallback-to-an-unused-port path.
    allow_reuse_address = os.name != "nt"

    def server_bind(self):
        if os.name == "nt":
            self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_EXCLUSIVEADDRUSE, 1)
        super().server_bind()


def make_server(root, port=8768, *, viewer_seconds=300):
    server = LoopbackHTTPServer(("127.0.0.1", port), Handler)
    try:
        server.agent = LocalAgent(root, viewer_seconds=viewer_seconds)
    except Exception:
        server.server_close()
        raise
    server.daemon_threads = True
    return server


def main():
    parser = argparse.ArgumentParser(description="SO-101 local input and result screen (MuJoCo simulation only)")
    parser.add_argument("--project-root")
    parser.add_argument("--port", type=int, default=8768)
    parser.add_argument("--no-browser", action="store_true")
    parser.add_argument("--viewer-seconds", type=int, default=300)
    args = parser.parse_args()
    if not 0 <= args.port <= 65535 or not 1 <= args.viewer_seconds <= 600:
        parser.error("invalid port or viewer duration")
    root = project_path(args.project_root)
    try:
        server = make_server(root, args.port, viewer_seconds=args.viewer_seconds)
    except OSError:
        server = make_server(root, 0, viewer_seconds=args.viewer_seconds)
    port = server.server_address[1]
    url = f"http://127.0.0.1:{port}/"
    write_json(APP_DIR / "server_info.json", {"app_name": APP_NAME, "app_version": APP_VERSION,
                                             "url": url, "pid": os.getpid(), "project_root": str(root)})
    print("SO101 LOCAL APP " + APP_VERSION, flush=True)
    print("Open this address: " + url, flush=True)
    print("Simulation only. Keep this console open. Ctrl+C stops the app.", flush=True)
    if not args.no_browser:
        try:
            webbrowser.open(url)
        except Exception as exc:
            print("Browser could not be opened. Copy the address above. " + str(exc), flush=True)
    try:
        server.serve_forever(poll_interval=0.2)
    except KeyboardInterrupt:
        print("Stopping the local app; preserving all run records.", flush=True)
    finally:
        server.agent.close()
        server.server_close()


if __name__ == "__main__":
    main()
