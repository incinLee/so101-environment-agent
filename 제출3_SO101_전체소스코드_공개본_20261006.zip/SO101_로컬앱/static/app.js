'use strict';

(() => {
  const $ = (id) => document.getElementById(id);
  const state = { token: null, jobId: null, runId: null, active: false, polling: null, started: 0, cancelRequested: false, goals: {}, runs: [], pollErrors: 0, parallelResult: null, parallelKey: null };
  const labels = { queued: '준비 중', running: '실행 중', completed: '완료', passed: '실행 완료', failed: '실패', unsupported: '미지원', not_run: '미실행', cancelled: '중지됨', cancel_requested: '중지 요청됨' };
  const phaseLabels = { queued: '실행 준비', workflow: '목표 해석 · 입력 검사', validate_assumed_scene: '작업장 조건 검사', construct_environment: '가상 작업장 생성', physics_feedback: '기준 제어 실행 · 평가', consider_bounded_layout_repair: '배치 수정 검토', reconstruct_assumed_layout_once: '수정한 작업장 생성', collect_episode_split_demonstrations: '학습 데이터 구성', train_chunk_transformer: '행동 정책 학습', evaluate_frozen_policy: '학습 정책 평가', fit_simulated_response: '시뮬레이션 응답 비교', complete_with_evidence: '평가 기록 저장', video: '새 이송 영상 저장', completed: '기록 저장 완료', failed: '실행 오류', cancelled: '중지됨' };
  const intentLabels = { tray_transfer: '부품 이송', response_calibration: '시뮬레이션 응답 비교', unsupported: '지원하지 않는 목표', unknown: '분류하지 못한 목표' };
  const inputIds = ['sourceX', 'sourceY', 'targetX', 'targetY', 'cubeSize', 'objectMass', 'trayWidth', 'trayDepth', 'trayHeight', 'tableWidth', 'tableDepth'];

  const setText = (id, value) => { $(id).textContent = value == null ? '' : String(value); };
  const show = (id, visible = true) => { $(id).hidden = !visible; };
  const pretty = (value) => typeof value === 'string' ? value : JSON.stringify(value ?? {}, null, 2);
  const finite = (value) => value !== null && value !== undefined && value !== '' && Number.isFinite(Number(value));
  const number = (value, digits = 4) => finite(value) ? Number(value).toFixed(digits) : '미기록';
  const errorMessage = (error) => error?.message || String(error);
  const safeURL = (url) => {
    if (typeof url !== 'string' || !url) return null;
    try { const parsed = new URL(url, location.href); return parsed.origin === location.origin && ['http:', 'https:'].includes(parsed.protocol) ? parsed.href : null; } catch (_) { return null; }
  };

  async function api(path, body) {
    const options = { method: body === undefined ? 'GET' : 'POST', headers: { 'Accept': 'application/json' }, cache: 'no-store' };
    if (body !== undefined) { options.headers['Content-Type'] = 'application/json'; options.headers['X-Session-Token'] = state.token || ''; options.body = JSON.stringify(body); }
    const response = await fetch(path, options);
    let data;
    try { data = await response.json(); } catch (_) { throw new Error(`응답을 읽지 못했습니다 (${response.status}).`); }
    if (!response.ok) { const detail = data.message ?? data.error ?? data.detail; throw new Error(typeof detail === 'string' ? detail : detail ? pretty(detail) : `요청에 실패했습니다 (${response.status}).`); }
    return data;
  }

  function setConnection(ok, message) { $('connectionDot').className = `dot ${ok ? 'ready' : 'failed'}`; setText('connectionText', message); }
  function setError(error, startup = false) { setText(startup ? 'startupError' : 'jobError', errorMessage(error)); show(startup ? 'startupError' : 'jobError'); }
  function setBusy(busy) {
    state.active = busy;
    $('configuration').disabled = busy || !state.token;
    $('cancelButton').disabled = !busy || state.cancelRequested;
    setText('runButton', busy ? '실행 중…' : '환경 생성 + 실행 + 결과 저장');
    $('refreshRuns').disabled = !state.token;
  }
  function statusBadge(status) {
    $('statusBadge').className = `badge ${status === 'completed' ? 'success' : status === 'failed' ? 'failed' : status === 'cancelled' ? 'cancelled' : ['running', 'queued'].includes(status) ? 'running' : 'neutral'}`;
    setText('statusBadge', labels[status] || status || '대기');
  }
  function updateElapsed() {
    if (!state.started) return;
    const seconds = Math.max(0, Math.floor((Date.now() - state.started) / 1000));
    setText('elapsedTime', `${String(Math.floor(seconds / 60)).padStart(2, '0')}:${String(seconds % 60).padStart(2, '0')}`);
  }
  function progressSteps(phase, status) {
    const steps = document.querySelectorAll('.progress-steps span');
    const text = String(phase || '').toLowerCase();
    let current = 0;
    if (/scene|environment|world|환경|작업장|layout/.test(text)) current = 1;
    if (/train|eval|baseline|policy|demo|실행|학습|평가|response|physics|dataset|demonstration/.test(text)) current = 2;
    if (/video|record|render|package|영상|저장/.test(text)) current = 3;
    steps.forEach((step, index) => { step.className = status === 'completed' || index < current ? 'done' : state.active && index === current ? 'current' : ''; });
  }

  function applyDefaults(scene = {}) {
    const mapping = { sourceX: scene.source_center_m?.[0], sourceY: scene.source_center_m?.[1], targetX: scene.target_center_m?.[0], targetY: scene.target_center_m?.[1], cubeSize: scene.object_size_m?.[0], objectMass: scene.object_mass_kg, trayWidth: scene.tray_size_m?.[0], trayDepth: scene.tray_size_m?.[1], trayHeight: scene.tray_size_m?.[2], tableWidth: scene.table_size_m?.[0], tableDepth: scene.table_size_m?.[1] };
    for (const [id, value] of Object.entries(mapping)) if (finite(value)) $(id).value = Number((Number(value) * (['sourceX', 'sourceY', 'targetX', 'targetY'].includes(id) ? 100 : 1000)).toFixed(4));
  }
  function sceneInput() {
    const values = Object.fromEntries(inputIds.map((id) => [id, Number($(id).value)]));
    for (const id of inputIds) if ($(id).value.trim() === '' || !Number.isFinite(values[id])) throw new Error('작업장 입력값을 숫자로 확인해 주세요.');
    const cube = values.cubeSize / 1000;
    return { source_center_m: [values.sourceX / 100, values.sourceY / 100], target_center_m: [values.targetX / 100, values.targetY / 100], object_size_m: [cube, cube, cube], object_mass_kg: values.objectMass / 1000, tray_size_m: [values.trayWidth / 1000, values.trayDepth / 1000, values.trayHeight / 1000], table_size_m: [values.tableWidth / 1000, values.tableDepth / 1000, 0.05] };
  }
  function normalizeGoals(goals) {
    if (Array.isArray(goals)) goals.forEach((goal) => {
      if (typeof goal === 'string') { if (/응답|response|보정/.test(goal)) state.goals.response = goal; else state.goals.transfer = goal; }
      else if (goal) { const value = goal.goal ?? goal.text ?? goal.example; const intent = goal.intent ?? goal.id ?? goal.key; if (value) state.goals[/response|calibration|응답/.test(intent || value) ? 'response' : 'transfer'] = value; }
    });
    else if (goals && typeof goals === 'object') Object.entries(goals).forEach(([key, value]) => { state.goals[/response|calibration|응답/.test(key) ? 'response' : 'transfer'] = typeof value === 'string' ? value : value?.goal ?? value?.text; });
  }
  function intentParts(result) {
    const raw = result?.raw_intent ?? result?.intent ?? result?.label ?? result?.prediction ?? result?.classifier?.intent ?? 'unknown';
    const confidence = result?.confidence ?? result?.probability ?? result?.classifier?.confidence;
    const route = result?.routing ?? result?.routed_intent ?? result?.selected_intent;
    return { raw: typeof raw === 'string' ? raw : pretty(raw), confidence, route, model: result?.model_kind ?? result?.modelkind ?? result?.classifier_kind ?? result?.model_type, reason: result?.reason };
  }
  function renderIntent(container, result) {
    container.replaceChildren();
    if (!result) { container.textContent = '목표 분류 기록이 없습니다.'; return; }
    const parts = intentParts(result);
    const title = document.createElement('b'); title.textContent = `목표 분류: ${intentLabels[parts.raw] || parts.raw}`; container.append(title);
    const pieces = [];
    if (finite(parts.confidence)) pieces.push(`분류 점수 ${(Number(parts.confidence) * 100).toFixed(1)}%`);
    if (parts.model) pieces.push('로컬에서 학습한 목표 분류기');
    if (parts.route) pieces.push(`실행 경로 ${typeof parts.route === 'string' ? (intentLabels[parts.route] || parts.route) : pretty(parts.route)}`);
    if (pieces.length) { const p = document.createElement('p'); p.textContent = pieces.join(' · '); container.append(p); }
    if (parts.reason) { const p = document.createElement('p'); p.textContent = typeof parts.reason === 'string' ? parts.reason : pretty(parts.reason); container.append(p); }
    const note = document.createElement('p'); note.textContent = '분류 점수는 목표 분류기의 출력이며, 작업 성공률이 아닙니다.'; note.className = 'helper'; container.append(note);
  }

  async function interpret() {
    const goal = $('goal').value.trim();
    if (!goal) { $('goal').reportValidity(); return; }
    $('interpretButton').disabled = true; setText('interpretButton', '해석 중…'); show('jobError', false);
    try { const result = await api('/api/intent', { goal }); renderIntent($('intentPreview'), result); show('intentPreview'); }
    catch (error) { setError(error); }
    finally { $('interpretButton').disabled = false; setText('interpretButton', '목표 해석 확인 →'); }
  }
  function metric(label, value, note, tone = '', compact = false) {
    const card = document.createElement('div'); card.className = `metric ${tone}`;
    const l = document.createElement('span'); l.className = 'metric-label'; l.textContent = label;
    const v = document.createElement('strong'); v.className = `metric-value ${compact ? 'compact' : ''}`; v.textContent = value;
    const n = document.createElement('span'); n.className = 'metric-note'; n.textContent = note;
    card.append(l, v, n); return card;
  }
  function setImage(id, figureId, url) {
    const safe = safeURL(url); show(figureId, !!safe);
    if (safe) $(id).src = safe; else $(id).removeAttribute('src');
    return !!safe;
  }
  function updateWorkerHelp() {
    const full = document.querySelector('input[name="runMode"]:checked').value === 'full';
    const workers = Number($('workers').value);
    setText('workerHelp', full ? `${workers}개 독립 환경에서 기준 제어 시연을 수집합니다. 시연은 총 9회이며, 남은 시행은 빈 작업장에서 이어서 실행합니다. 학습 5회 · 검증 2회 · 시험 2회로 분리하고, 훈련 샘플 배치는 64입니다. 응답 비교 목표에서는 이송 시연과 정책 학습을 생략합니다.` : '빠른 확인은 동시 작업장 수 설정과 관계없이 작업장 1개에서 시연 1회만 실행합니다. 새 정책 학습을 생략합니다. 응답 비교 목표도 이송 작업장을 병렬 실행하지 않습니다.');
  }
  function renderParallelGrid(id, rows, count, phase = null) {
    const grid = $(id); grid.replaceChildren();
    for (let index = 0; index < count; index += 1) {
      const row = phase ? rows[index] : rows.find((item) => item.slot === index);
      const card = document.createElement('figure'); card.className = 'parallel-card';
      const title = document.createElement('b'); title.textContent = phase ? `시연 ${(row?.seed ?? index) + 1} · seed ${row?.seed ?? index}` : `작업장 ${index + 1}${row ? ` · seed ${row.seed}` : ''}`;
      card.append(title);
      const available = row?.images || {};
      const selected = phase || ['hold', 'place', 'lift', 'close', 'initial'].find((key) => available[key]);
      const url = safeURL(available[selected]);
      if (url) {
        const link = document.createElement('a'); link.href = url; link.target = '_blank'; link.rel = 'noopener';
        const image = document.createElement('img'); image.src = url; image.alt = `seed ${row.seed}의 실제 MuJoCo ${selected} 단계 사진`; image.loading = 'lazy'; link.append(image); card.append(link);
      } else {
        const placeholder = document.createElement('div'); placeholder.className = 'parallel-placeholder'; placeholder.textContent = row ? '단계 사진 저장 대기' : '작업장 준비 대기'; card.append(placeholder);
      }
      const caption = document.createElement('figcaption');
      const success = row?.task_success;
      caption.textContent = success === true ? '기준 제어 성공' : success === false ? '기준 제어 실패' : row ? labels[row.status] || row.status || '사진 기록' : '대기';
      if (row?.pid) caption.textContent += ` · PID ${row.pid}`;
      card.append(caption); grid.append(card);
    }
  }
  function renderParallelProgress(parallel, requested = 8) {
    const key = pretty(parallel || { requested });
    if (key === state.parallelKey) return;
    state.parallelKey = key;
    show('parallelProgress');
    if (!parallel) {
      setText('parallelStatus', `${requested}개 작업장 준비 중 · 실제 실행 사진이 저장되면 표시합니다.`);
      renderParallelGrid('parallelGrid', [], requested); return;
    }
    setText('parallelStatus', `요청 ${parallel.requested_workers}개 · 실제 동시 작업장 ${parallel.effective_workers}개 · 시연 ${parallel.completed}/${parallel.total}회 완료`);
    renderParallelGrid('parallelGrid', Array.isArray(parallel.slots) ? parallel.slots : [], parallel.effective_workers);
  }
  function renderParallelResult(parallel) {
    state.parallelResult = parallel;
    const rows = Array.isArray(parallel?.episodes) ? parallel.episodes : [];
    show('parallelResult', rows.length > 0);
    if (!rows.length) return;
    const count = Math.min(8, rows.length);
    const history = parallel.legacy_sequential ? '이전 순차 실행 기록' : '독립 환경 수집 기록';
    setText('parallelResultStatus', `${history} · 동시 작업장 ${parallel.effective_workers}개 · 시연 총 ${parallel.total}회 중 첫 ${count}회 표시. ${parallel.total === 9 ? '9번째 시행은 원본 실행 기록에 함께 저장했습니다.' : ''}`);
    renderParallelGrid('parallelResultGrid', rows, count, $('parallelPhase').value);
  }
  function renderTrace(trace) {
    const list = $('traceList'); list.replaceChildren();
    const entries = Array.isArray(trace) ? trace : trace && typeof trace === 'object' ? Object.entries(trace).map(([name, value]) => ({ name, ...typeof value === 'object' && value !== null ? value : { value } })) : [];
    if (!entries.length) { const item = document.createElement('li'); item.textContent = '저장된 도구 실행 기록이 없습니다.'; list.append(item); return; }
    entries.forEach((entry, index) => {
      const item = document.createElement('li'); const name = document.createElement('b');
      name.textContent = typeof entry === 'string' ? entry : entry.tool ?? entry.tool_name ?? entry.name ?? entry.action ?? entry.step ?? `도구 ${index + 1}`; item.append(name);
      if (entry && typeof entry === 'object') {
        const status = entry.status ?? entry.result?.status;
        if (status) { const span = document.createElement('span'); span.textContent = ` · ${labels[status] || status}`; item.append(span); }
        const details = document.createElement('details'); const summary = document.createElement('summary'); summary.textContent = '세부 기록'; const pre = document.createElement('pre'); pre.textContent = pretty(entry); details.append(summary, pre); item.append(details);
      }
      list.append(item);
    });
  }
  function renderResult(result, runId) {
    state.runId = runId || result?.run_id || state.runId;
    show('resultEmpty', false); show('resultContent');
    setText('resultSubtitle', state.runId ? `실행 기록: ${state.runId}` : '선택한 실행의 저장된 결과입니다.'); setText('resultGoal', result.goal || '저장된 목표 문장이 없습니다.');
    const metrics = $('resultMetrics'); metrics.replaceChildren();
    const trials = Number(result.baseline_trials || 0); const successes = Number(result.baseline_successes || 0);
    metrics.append(metric('스크립트 기준 제어', trials ? `${successes} / ${trials}` : '미실행', trials ? '성공 횟수 / 평가 횟수' : '이 목표에서는 이송 평가가 없을 수 있습니다.', trials ? successes === trials ? 'success' : 'fail' : '', !trials));
    const policyStatus = String(result.policy_task_status || 'not_run');
    const policyTrials = Number(result.policy_trials || 0); const policySuccesses = Number(result.policy_successes || 0);
    if (policyTrials) metrics.append(metric('학습 정책 평가', `${policySuccesses} / ${policyTrials}`, '성공 횟수 / 평가 횟수', policySuccesses === policyTrials ? 'success' : 'fail'));
    else metrics.append(metric('학습 정책 평가', /skip|not_run|not_train|disabled|미|생략/.test(policyStatus) ? '미실행' : labels[policyStatus] || policyStatus, '빠른 확인과 응답 비교는 정책 평가를 생략합니다.', '', true));
    if (finite(result.offline_mae)) metrics.append(metric('별도 평가 행동 오차', number(result.offline_mae, 6), '오프라인 평균 절대 오차 · rad', '', true));
    if (finite(result.response_before_mse) || finite(result.response_after_mse)) metrics.append(metric('응답 오차 MSE', `${finite(result.response_before_mse) ? Number(result.response_before_mse).toExponential(3) : '미기록'} → ${finite(result.response_after_mse) ? Number(result.response_after_mse).toExponential(3) : '미기록'}`, '시뮬레이션 응답 비교 · rad²', '', true));
    setText('metricExplanation', '트레이 내부 정착, 부품 속도, 그리퍼 열림과 접촉 해제 등을 함께 확인합니다. 영상은 별도 실행의 기록이므로 위 평가 횟수에 추가하지 않습니다.');
    renderParallelResult(result.parallel);
    const urls = result.urls || {};
    const video = safeURL(urls.video);
    $('resultVideo').pause();
    if (video) { $('resultVideo').src = video; $('resultVideo').load(); $('videoDownload').href = video; $('videoDownload').target = '_blank'; $('videoDownload').rel = 'noopener'; }
    else { $('resultVideo').removeAttribute('src'); $('resultVideo').load(); $('videoDownload').removeAttribute('href'); }
    show('resultVideo', !!video); show('noVideo', !video); show('videoDownload', !!video);
    const initial = setImage('initialImage', 'initialFigure', urls.initial_image); const final = setImage('finalImage', 'finalFigure', urls.final_image); show('noImage', !initial && !final);
    renderIntent($('resultIntent'), result.intent_result); renderTrace(result.trace);
    setText('requestedScene', pretty(result.requested_scene || result.scene || {})); setText('actualScene', pretty(result.scene || {}));
    setText('viewerMessage', ''); $('viewerButton').disabled = !state.runId;
    const links = $('resultLinks'); links.replaceChildren();
    [['report_html', '전체 평가 화면'], ['report_json', '원본 실행 기록'], ['scene_manifest', '작업장 설정 기록'], ['world', 'MuJoCo 작업장 파일'], ['video_report', '영상 평가 기록']].forEach(([key, label]) => {
      const url = safeURL(urls[key]); if (!url) return; const link = document.createElement('a'); link.href = url; link.textContent = `${label} ↗`; link.target = '_blank'; link.rel = 'noopener'; links.append(link);
    });
    renderHistory();
  }

  function renderHistory() {
    const target = $('runHistory'); target.replaceChildren();
    if (!state.runs.length) { const p = document.createElement('p'); p.className = 'helper'; p.textContent = '아직 저장된 실행 기록이 없습니다. 첫 작업을 실행해 보세요.'; target.append(p); return; }
    const list = document.createElement('div'); list.className = 'history-list';
    state.runs.forEach((run) => {
      const button = document.createElement('button'); button.type = 'button'; button.className = `history-item ${run.id === state.runId ? 'selected' : ''}`;
      const left = document.createElement('span'); const title = document.createElement('span'); title.className = 'history-title'; title.textContent = run.title || run.id; const id = document.createElement('span'); id.className = 'history-id'; id.textContent = run.id; left.append(title, id);
      const right = document.createElement('span'); right.className = 'history-summary';
      const summary = document.createElement('span'); const trials = Number(run.baseline_trials || 0); summary.textContent = trials ? `기준 제어 ${Number(run.baseline_successes || 0)}/${trials}` : '상세 기록 확인';
      const badge = document.createElement('span'); badge.className = `badge ${run.status === 'failed' ? 'failed' : run.status === 'completed' ? 'success' : run.status === 'running' ? 'running' : 'neutral'}`; badge.textContent = labels[run.status] || run.status || '저장됨'; right.append(summary, badge); button.append(left, right);
      button.addEventListener('click', async () => {
        button.disabled = true;
        try { const result = await api(`/api/runs/${encodeURIComponent(run.id)}`); renderResult(result, run.id); $('resultHeading').scrollIntoView({ behavior: 'smooth', block: 'start' }); }
        catch (error) { setError(error); }
        finally { button.disabled = false; }
      }); list.append(button);
    }); target.append(list);
  }
  async function refreshHistory() { const data = await api('/api/runs'); state.runs = Array.isArray(data.runs) ? data.runs : []; renderHistory(); }
  function renderLogs(logs) {
    const text = Array.isArray(logs) ? logs.map((entry) => typeof entry === 'string' ? entry : entry.message ?? entry.text ?? pretty(entry)).join('\n') : typeof logs === 'string' ? logs : logs ? pretty(logs) : '기록을 기다리고 있습니다.';
    const log = $('jobLog'); const bottom = log.scrollHeight - log.scrollTop - log.clientHeight < 35;
    log.textContent = text;
    if (bottom) log.scrollTop = log.scrollHeight;
  }
  async function pollJob() {
    const jobId = state.jobId;
    if (!jobId || !state.active) return;
    try {
      const job = await api(`/api/jobs/${encodeURIComponent(jobId)}`);
      if (state.jobId !== jobId) return;
      state.pollErrors = 0; setConnection(true, '로컬 앱 연결됨');
      statusBadge(job.status); setText('jobPhase', phaseLabels[job.phase] || labels[job.status] || '실행'); setText('jobMessage', job.message || '실행 기록을 확인하고 있습니다.'); setText('statusSummary', job.message || '현재 실행을 진행하고 있습니다.'); renderLogs(job.logs); updateElapsed(); progressSteps(job.phase, job.status);
      if (job.parallel) renderParallelProgress(job.parallel);
      else if (job.request?.intent_result?.intent === 'response_calibration') show('parallelProgress', false);
      if (job.error) setError(typeof job.error === 'string' ? job.error : pretty(job.error));
      if (['completed', 'failed', 'cancelled'].includes(job.status)) {
        setBusy(false); $('cancelButton').disabled = true; show('cancelButton', false);
        if (job.result) renderResult(job.result, job.run_id);
        else if (job.status === 'completed' && job.run_id) { try { renderResult(await api(`/api/runs/${encodeURIComponent(job.run_id)}`), job.run_id); } catch (error) { setError(error); } }
        if (job.status === 'failed' && !job.error) setError(job.message || '실행에 실패했습니다. 위 실행 기록을 확인해 주세요.');
        setText('statusSummary', job.status === 'completed' ? '실행과 기록 저장을 마쳤습니다. 평가 성공 여부는 아래 결과를 확인하세요.' : job.status === 'cancelled' ? '중지되었습니다. 설정을 바꾸어 다시 실행할 수 있습니다.' : '실행 중 문제가 발생했습니다. 오류와 기록을 확인해 주세요.');
        try { await refreshHistory(); } catch (error) { setError(error); }
        return;
      }
    } catch (error) {
      state.pollErrors += 1; setConnection(false, '상태 연결 재확인'); setError(`진행 상태를 가져오지 못했습니다. 자동으로 다시 확인합니다.\n${errorMessage(error)}`);
    }
    if (state.active && state.jobId === jobId) state.polling = setTimeout(pollJob, Math.min(1000 + state.pollErrors * 1000, 5000));
  }
  async function run(event) {
    event.preventDefault(); if (state.active || !state.token) return;
    if (!$('runForm').reportValidity()) return;
    let payload;
    try { const goal = $('goal').value.trim(); if (!goal) throw new Error('목표 문장을 입력해 주세요.'); payload = { goal, scene: sceneInput(), train_policy: document.querySelector('input[name="runMode"]:checked').value === 'full', workers: Number($('workers').value) }; }
    catch (error) { setError(error); return; }
    show('jobError', false); show('startupError', false); setText('viewerMessage', ''); state.cancelRequested = false; state.pollErrors = 0; state.started = Date.now(); state.parallelKey = null; renderParallelProgress(null, payload.train_policy ? payload.workers : 1);
    setBusy(true); show('jobProgress'); show('cancelButton'); setText('jobPhase', '실행 준비'); setText('jobMessage', '입력값을 확인하고 새 실행을 준비하고 있습니다.'); setText('statusSummary', '새 가상 작업장을 준비합니다.'); statusBadge('queued'); $('logDetails').open = true; renderLogs([]);
    try {
      const result = await api('/api/run', payload); state.jobId = result.job_id; state.runId = result.run_id;
      if (!state.jobId) throw new Error('실행 번호를 받지 못했습니다. 실행 기록을 확인해 주세요.');
      statusBadge(result.status || 'queued'); await pollJob();
    } catch (error) { setBusy(false); statusBadge('failed'); setError(error); setText('statusSummary', '실행을 시작하지 못했습니다. 입력값과 오류를 확인해 주세요.'); show('cancelButton', false); }
  }
  async function cancel() {
    if (!state.jobId || !state.active || state.cancelRequested) return;
    $('cancelButton').disabled = true;
    try { const result = await api('/api/cancel', { job_id: state.jobId }); state.cancelRequested = true; setText('cancelButton', '중지 요청됨'); setText('cancelHelp', result.message || '현재 단계가 끝난 뒤 중지합니다.'); }
    catch (error) { setError(error); $('cancelButton').disabled = false; }
  }
  async function viewer() {
    if (!state.runId) return;
    $('viewerButton').disabled = true; setText('viewerMessage', '작업장 창을 여는 중입니다…');
    try { const result = await api('/api/viewer', { run_id: state.runId }); setText('viewerMessage', result.status === 'already_open' ? '작업장 창이 이미 열려 있습니다. 작업 표시줄을 확인하세요.' : '작업장 창 열기를 요청했습니다. 별도 창이나 작업 표시줄을 확인하세요. 배치와 시점 확인용입니다.'); }
    catch (error) { setText('viewerMessage', `작업장 창을 열지 못했습니다: ${errorMessage(error)}`); }
    finally { $('viewerButton').disabled = false; }
  }
  function switchMedia(showVideo) {
    show('videoPane', showVideo); show('imagePane', !showVideo); $('videoTab').classList.toggle('active', showVideo); $('imageTab').classList.toggle('active', !showVideo); $('videoTab').setAttribute('aria-selected', String(showVideo)); $('imageTab').setAttribute('aria-selected', String(!showVideo)); if (!showVideo) $('resultVideo').pause();
  }
  async function init() {
    setBusy(false); $('configuration').disabled = true;
    $('runForm').addEventListener('submit', run); $('interpretButton').addEventListener('click', interpret); $('cancelButton').addEventListener('click', cancel); $('viewerButton').addEventListener('click', viewer);
    $('refreshRuns').addEventListener('click', async () => { $('refreshRuns').disabled = true; try { await refreshHistory(); } catch (error) { setError(error); } finally { $('refreshRuns').disabled = false; } });
    $('videoTab').addEventListener('click', () => switchMedia(true)); $('imageTab').addEventListener('click', () => switchMedia(false));
    $('workers').addEventListener('change', updateWorkerHelp);
    document.querySelectorAll('input[name="runMode"]').forEach((input) => input.addEventListener('change', updateWorkerHelp));
    $('parallelPhase').addEventListener('change', () => renderParallelResult(state.parallelResult));
    updateWorkerHelp();
    document.querySelectorAll('[data-example]').forEach((button) => button.addEventListener('click', () => { $('goal').value = state.goals[button.dataset.example] || (button.dataset.example === 'response' ? '시뮬레이션의 관절 응답을 비교하고 응답 계수와 지연을 추정해줘.' : '파란 트레이의 부품을 초록 트레이로 옮겨줘.'); show('intentPreview', false); $('goal').focus(); }));
    $('goal').addEventListener('input', () => show('intentPreview', false));
    window.addEventListener('beforeunload', () => { if (state.polling) clearTimeout(state.polling); });
    try {
      const session = await api('/api/session'); state.token = session.token;
      if (!state.token) throw new Error('로컬 앱 연결 정보를 받지 못했습니다. 앱을 다시 실행해 주세요.');
      applyDefaults(session.default_scene); normalizeGoals(session.goals); setText('versionLabel', `${session.app_name || 'SO-101 환경 에이전트'} ${session.app_version || ''}`.trim()); state.runs = Array.isArray(session.runs) ? session.runs : []; renderHistory(); setConnection(true, '로컬 앱 연결됨'); setBusy(false);
      if (session.active_job_id) { state.jobId = session.active_job_id; state.started = Date.now(); state.cancelRequested = false; setBusy(true); show('jobProgress'); show('cancelButton'); $('logDetails').open = true; await pollJob(); }
    } catch (error) { setConnection(false, '연결 실패'); setError(`로컬 앱에 연결하지 못했습니다. 실행 도구를 켠 상태에서 이 페이지를 열어 주세요.\n${errorMessage(error)}`, true); setText('runHistory', '연결 후 실행 기록을 확인할 수 있습니다.'); }
  }
  init();
})();
