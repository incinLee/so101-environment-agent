[CmdletBinding()]
param(
    [string]$ProjectRoot,
    [int]$Port = 8768,
    [switch]$NoBrowser
)
$ErrorActionPreference = 'Stop'
$appOldEncoding = $env:PYTHONIOENCODING
$appOldOutput = $OutputEncoding
$appTranscript = $false
$appExit = 0
try {
    $appLogDirectory = Join-Path $PSScriptRoot 'logs'
    New-Item -ItemType Directory -Path $appLogDirectory -Force | Out-Null
    $appBootstrapLog = Join-Path $appLogDirectory ('startup-' + (Get-Date -Format 'yyyyMMdd-HHmmssfff') + '.log')
    Start-Transcript -LiteralPath $appBootstrapLog -Force | Out-Null
    $appTranscript = $true
    if (-not $ProjectRoot) {
        $ProjectRoot = Join-Path (Split-Path -Parent $PSScriptRoot) 'so101-env-agent'
    }
    $appRoot = (Resolve-Path -LiteralPath $ProjectRoot).Path
    $appPython = Join-Path $appRoot '.venv/Scripts/python.exe'
    if (-not (Test-Path -LiteralPath $appPython -PathType Leaf)) { throw '프로젝트 전용 .venv가 없습니다. 준비된 프로젝트 경로를 확인하세요.' }
    $appServer = Join-Path $PSScriptRoot 'app.py'
    if (-not (Test-Path -LiteralPath $appServer -PathType Leaf)) { throw 'ZIP을 모두 압축 해제한 뒤 START_APP.cmd를 실행하세요.' }
    $env:PYTHONIOENCODING = 'utf-8'
    $OutputEncoding = New-Object System.Text.UTF8Encoding
    Write-Host '목표와 작업장 조건을 입력하는 SO101 로컬 화면을 시작합니다.'
    Write-Host '브라우저가 자동으로 열리지 않으면 아래 Open this address 주소를 브라우저에 입력하세요.'
    Write-Host '이 창은 앱을 실행하는 동안 열어 두세요. Ctrl+C를 누르면 앱을 종료합니다.'
    Write-Host ('시작 로그: ' + $appBootstrapLog)
    $appArguments = @($appServer, '--project-root', $appRoot, '--port', "$Port")
    if ($NoBrowser) { $appArguments += '--no-browser' }
    $ErrorActionPreference = 'Continue'
    & $appPython @appArguments 2>&1 | ForEach-Object { Write-Host $_ }
    $appExit = $LASTEXITCODE
    $ErrorActionPreference = 'Stop'
} catch {
    Write-Host ('앱 시작 오류: ' + $_.Exception.Message) -ForegroundColor Red
    Write-Host ('로그 폴더: ' + (Join-Path $PSScriptRoot 'logs'))
    $appExit = 1
} finally {
    if ($null -eq $appOldEncoding) { Remove-Item -LiteralPath 'Env:PYTHONIOENCODING' -ErrorAction SilentlyContinue }
    else { $env:PYTHONIOENCODING = $appOldEncoding }
    $OutputEncoding = $appOldOutput
    if ($appTranscript) { Stop-Transcript | Out-Null }
}
exit $appExit
