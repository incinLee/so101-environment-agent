# 시뮬레이션 확인·검증·영상 저장

기준일: 2026-10-06. 현재 개발 PC의 Windows에서 먼저 실행한다. 실제 로봇·USB 웹캠을 연결할 필요가 없다. 현재 구현의 영상은 MuJoCo가 계산한 가상 SO-101과 부품의 동작이다. 실물 시연이나 카메라 인식 검증을 뜻하지 않는다.

## 1. 기존 결과를 먼저 열기

파일 탐색기에서 아래 폴더를 연다.

```text
.\so101-env-agent
```

현재 작업 폴더에는 개발 중 실제 실행한 결과와 `.venv`가 있다. `runs\release-demo-20261006\index.html`을 더블클릭하면 브라우저에서 실행 결과를 읽을 수 있다. 이 HTML은 요약·사진·로그를 담은 결과 화면이다. 실행되는 로봇 동영상이나 실시간 시뮬레이터 창은 별도로 연다.

PowerShell에서는 다음과 같다.

```powershell
Set-Location -LiteralPath '.\so101-env-agent'
Start-Process -FilePath (Join-Path (Get-Location) 'runs/release-demo-20261006/index.html')
```

전달한 **source ZIP에는 `.venv`와 `runs`가 들어 있지 않다.** ZIP을 새 폴더에 풀었다면 먼저 [QUICKSTART.md](QUICKSTART.md)의 `scripts/run_demo.ps1`을 실행하여 환경과 새 실행 결과를 만든다. 아래의 `runs/release-demo-20261006` 대신 그 스크립트가 출력한 데모 폴더를 사용한다.

## 2. 코드와 작업 성공을 각각 검증하기

프로젝트 폴더에서 PowerShell을 열고 다음을 실행한다.

```powershell
$env:PYTHONPATH = Join-Path (Get-Location) 'src'
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
```

끝부분의 `OK`와 실패·오류·생략 시험 수를 확인한다. 의존성이 없어 생략된 시험이 있으면 실제 물리·학습 경로를 모두 검증했다고 해석하지 않는다. 이전 실행 시험 수와 범위는 [VALIDATION_FINAL.json](VALIDATION_FINAL.json)에 기록돼 있다.

다음으로 새 데모를 실행하여 현재 PC에서 결과를 재생성한다. 출력 폴더는 실행마다 새 이름을 사용한다.

```powershell
$env:PYTHONPATH = Join-Path (Get-Location) 'src'
$simulationDemo = 'runs/demo-' + (Get-Date -Format 'yyyyMMdd-HHmmssfff')
.\.venv\Scripts\python.exe -m robot_env_agent demo --scene configs/scene.simulation.json --output-dir $simulationDemo --epochs 60
Start-Process -FilePath (Join-Path (Get-Location) "$simulationDemo/index.html")
```

이 데모는 환경 생성, 스크립트 시연 9회, episode 단위 5/2/2 분할, 작은 상태 기반 chunk Transformer 학습, 학습 정책 2회 평가, 시뮬레이션 응답 추정을 실행한다. 현재 보존된 결과는 스크립트 이송 **9/9 성공**, 학습 정책 **0/2 실패**다. 재실행 결과는 새 보고서의 실제 수치를 사용한다. CLI 종료 코드 0은 도구 흐름 실행 완료를 뜻하며 학습 정책의 작업 성공과 다르다.

성공은 영상이 그럴듯해 보이는지로 판정하지 않는다. 회전한 부품 전체가 목표 트레이 안에 들어가고, 이동 속도가 0.03m/s 이하이며, 그리퍼가 0.5rad 이상 열린 상태이고 그리퍼와 부품의 접촉이 없어야 한다. 이 조건이 1초 이상 지속되어야 성공이다. 스크립트 baseline은 retreat/hold 단계 조건도 추가로 적용한다. 실제 판정값과 seed, 물리 시간, 관절·부품 trace를 함께 남긴다. 부품 순간이동이나 강제 부착은 사용하지 않는다.

AI 에이전트의 피드백 증거는 `runs\release-repair-20261006\index.html`과 `workflow_report.json`에서 확인한다. 최초 실패와 재시도 성공이 각각 남아 있으며, 재시도는 가정한 트레이 좌표만 한 번 바꾼다. 부품 크기·유지 시간·성공 판정의 보호 해시는 유지한다. 이 결과는 가상 환경 배치 수정 증거이며 실물 모터 보정 결과가 아니다.

## 3. 가상 장면을 직접 열기

현재 보존된 장면을 MuJoCo 창으로 열려면 다음을 실행한다.

```powershell
$env:PYTHONPATH = Join-Path (Get-Location) 'src'
.\.venv\Scripts\python.exe -m robot_env_agent view-sim --world runs/release-demo-20261006/environment/scene.xml
```

창을 닫거나 기본 제한 시간 5분이 지나면 종료된다. 이 창은 생성된 팔·부품·트레이 배치와 시점을 직접 확인하는 용도다. 물리 계산과 자동 이송을 실행하지 않으므로 작업 성공을 판정하는 창은 아니다. 이송 동작은 다음 영상 명령으로 실행하여 남긴다.

새 데모를 사용한다면 `--world` 값을 `$simulationDemo/environment/scene.xml`로 바꾼다. 장면 XML과 mesh 파일은 한 환경 폴더 안에 함께 있으므로 XML만 옮기면 안 된다.

## 4. 실제 물리 실행을 MP4로 남기기

화면을 수동 녹화하지 않고 시뮬레이션 실행 중 카메라 프레임을 저장한다. 기존 로그의 위치값으로 부품을 옮기는 재연 영상이 아니다. MP4 인코더는 프로젝트의 `.venv`에만 설치한다. 현재 개발 폴더에는 이미 설치되어 있으며, ZIP을 새로 풀었거나 다른 PC에서 실행하면 다음 명령을 먼저 실행한다.

```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements-video.txt
```

다음 명령은 스크립트 제어기로 seed 0의 새 물리 실행을 수행하고 15fps MP4를 생성한다.

```powershell
$env:PYTHONPATH = Join-Path (Get-Location) 'src'
$videoRun = 'runs/video-scripted-' + (Get-Date -Format 'yyyyMMdd-HHmmssfff')
.\.venv\Scripts\python.exe -m robot_env_agent record-video --world runs/release-demo-20261006/environment/scene.xml --controller scripted --output-dir $videoRun --seed 0 --fps 15
$videoReport = Get-Content -LiteralPath "$videoRun/video_report.json" -Raw | ConvertFrom-Json
Start-Process -FilePath (Join-Path (Get-Location) "$videoRun/$($videoReport.video.video_path)")
```

영상 파일은 `simulation.mp4`이며 MP4 인코더가 없으면 `simulation.avi`로 저장된다. 정확한 이름은 `video_report.json`의 `video.video_path`에 기록된다. 같은 폴더의 `video_report.json`과 `video_frame_timeline.jsonl`도 보존한다. `video.video_status`가 `executed`인지, `task_success`가 true/false인지 각각 확인한다. 영상 생성 완료와 이송 성공은 별개의 결과다. 출력 폴더를 덮어쓰지 않으므로 매번 새 이름을 사용한다.

최종 0.2.1 검증에서는 전체 시험 108개가 통과했고 생략은 0이었다. 새 scripted seed0 녹화는 이송 성공/13초/195프레임, learned seed7 녹화는 이송 실패/14.067초/211프레임이었다. 두 MP4의 전체 디코딩·프레임 수·시간 기록·SHA256을 확인하고 6초와 12초 장면도 눈으로 확인했다. [VALIDATION_VIDEO.json](VALIDATION_VIDEO.json)에 기록한다. 기본 인코더는 설치된 imageio-ffmpeg를 사용한다. 임의의 `--encoder` 실행 파일이 멈추는 경우까지 전체 실행 시간을 보장하지 않는다.

학습 정책도 **별도로** 촬영한다. 아래에서는 기존 평가에 사용한 heldout seed 7을 사용한다. 스크립트 성공 영상을 학습 모델의 성공 영상으로 표시하지 않는다.

```powershell
$env:PYTHONPATH = Join-Path (Get-Location) 'src'
$policyVideoRun = 'runs/video-learned-' + (Get-Date -Format 'yyyyMMdd-HHmmssfff')
.\.venv\Scripts\python.exe -m robot_env_agent record-video --world runs/release-demo-20261006/environment/scene.xml --controller learned --checkpoint runs/release-demo-20261006/policy --output-dir $policyVideoRun --seed 7 --fps 15
$policyVideoReport = Get-Content -LiteralPath "$policyVideoRun/video_report.json" -Raw | ConvertFrom-Json
Start-Process -FilePath (Join-Path (Get-Location) "$policyVideoRun/$($policyVideoReport.video.video_path)")
```

학습 정책 실패 영상도 평가 증거다. 이번 녹화는 해당 seed의 새 시행이며, 이전 0/2 평가 기록을 바꾸지 않는다. 실패를 지우거나 성공 장면만 이어 붙여 전체 성공률을 표시하지 않는다. 현 모델은 카메라 영상을 입력받지 않고 시뮬레이터의 관절·부품 위치를 입력받는 작은 상태 기반 모델이다. 기존 ACT 전체 이미지/CVAE 아키텍처와 구분해 설명한다.

설치와 기본 장면 준비를 묶은 스크립트는 다음과 같다. 프로젝트 `.venv`가 준비된 상태에서 사용한다. `-World`를 생략하면 `build-sim`으로 새 장면을 생성한 뒤 scripted 물리 실행을 녹화한다. 선행 baseline 데모나 정책 학습은 실행하지 않는다. `-Open`은 생성 영상을 연다.

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\record_video.ps1 -Open
```

학습 영상에는 full 데모에서 생성한 checkpoint가 필요하다. 현재 저장된 checkpoint 폴더는 `runs/release-demo-20261006/policy`이며 `policy_manifest.json`과 `weights.npz`를 함께 포함한다. 새 학습 결과를 녹화할 때는 같은 데모의 environment와 policy 경로를 짝지어 지정한다.

## 5. 시연 설명 영상 구성

대회 설명 영상은 공식 분량 제한 안에서 다음 순서로 구성하면 흐름이 명확하다.

1. 약 20초: 스마트팩토리의 트레이 이송 작업, 제공한 목표와 시뮬레이션 가정을 보여준다.
2. 약 40초: 결과 HTML에서 목표 분류 → 도구 호출 → 환경 생성 → 물리 결과 확인을 보여준다.
3. 약 30초: 실패한 배치와 한 번의 좌표 수정, 보호된 평가 기준, 재시도 결과를 보여준다.
4. 약 30초: 스크립트 이송 MP4와 성공 판정·실행 횟수를 보여준다.
5. 약 30초: 학습 정책 MP4와 0/2 실패 결과, 학습 오차와 실제 성공률의 차이를 설명한다.
6. 약 20초: 시뮬레이션 응답 비교와 실물 전이·카메라 입력·기존 ACT 연동의 남은 작업을 설명한다.

위 MP4는 로봇 시뮬레이션 clip이다. 설명·결과 화면까지 포함한 최종 발표 영상은 화면 녹화 또는 영상 편집 도구에서 별도로 구성한다. 영상과 `workflow_report.json`, `video_report.json`, 관련 trace를 함께 보관하면 어떤 실행을 보여준 것인지 추적할 수 있다. 실행 결과·원본 보정·영상·학습 weights는 기본 Git 업로드 대상에서 제외되어 있다.

## 문제 발생 시

- `No module named robot_env_agent`: 프로젝트 루트에서 `$env:PYTHONPATH`를 설정했는지 확인한다.
- `No module named mujoco` 또는 `torch`: [QUICKSTART.md](QUICKSTART.md)의 bootstrap 절차를 사용한다. 다른 Python의 전역 패키지 설치로 해결하지 않는다.
- world 또는 checkpoint가 없음: source ZIP에는 실행 결과가 포함되지 않는다. 데모를 먼저 실행하고 그 출력 폴더를 사용한다.
- 출력 폴더가 이미 존재함: 새 timestamp 이름으로 실행한다. 기존 평가 증거를 지우지 않는다.
- renderer/OpenGL 오류: 로그를 보존한다. 해당 실행은 영상 생성 성공으로 기록하지 않는다. Ubuntu에서는 그래픽 세션·렌더링 환경이 별도로 필요할 수 있으며 현재 사용자 Ubuntu PC에서는 검증하지 않았다.

Windows에서 영상과 판정 기록을 확인한 다음 Ubuntu로 이전한다. 실물 적용은 두 follower의 A/B 보정 파일 매핑, 모터 단위·범위, 카메라 배치·좌표, 안전 범위 확인과 별도의 실측 비교가 완료된 후 진행한다.
