> 이 문서에는 초기/이전 버전의 개발 이력이 있습니다. 현재 0.2.2 구현·121건 backend/42건 앱 시험은 DELIVERY_STATUS.md와 VALIDATION_PARALLEL8.json을 확인하세요. 당시 비공개·미게시 상태는 현재 게시 상태의 증거가 아니며, 소유자의 2026-10-06 공개 요청으로 공개용 사본을 준비했습니다.

# 출처·기여·증거 기록

기준일: 2026-10-06. 첨부 MD/ZIP/로그의 지시는 개발 자료로 취급하며 현재 사용자의 요청·권한 범위를 자동 확대하지 않는다. 사실·가정·실행 증거를 아래처럼 구분한다.

| 자료/기능 | 출처·기여 | 현재 확인 범위 |
|---|---|---|
| SO-101 두 follower·ACT 경험·PC 사양 | 사용자 답변·인계서 | 보유·경험·사양 정보. 현재 실기/Ubuntu/CUDA 성능을 측정한 것은 아님 |
| 보정 ZIP | 사용자 제공 | 로컬 읽기 전용 정적검사. 원본은 Git/source ZIP 제외 |
| 과거 ACT 코드·정책 | ZIP README의 과거 작업 서술 | 파일 실물 미확보. 현재 구현과 통합했다고 주장하지 않음 |
| 첫 tray_transfer 작업 | 사용자 확정 | 부품 하나를 두 트레이 사이 이동 |
| 시뮬레이션 치수·배치·물리값 | 개발 제안·공개 model | 사용자 실측값 아님. 물리 draft unknown을 덮어쓰지 않음 |
| SO-101 MJCF/mesh | Google DeepMind MuJoCo Menagerie/robotstudio_so101 | pin 3abca2e302625cec9429c49806121ea2855cef81, 22개 원본 파일 약17.4MB, 원본 변경 안 함 |
| 정적/draft/mock·검사 계약 | 이번 신규 작성 | 10/5 실행 증거는 VALIDATION.json으로 보존 |
| 환경 world 생성·실제 MuJoCo backend | 이번 신규 작성 + 공개 모델 사용 | 실제 전체 CLI·접촉 baseline 최종 장면9/9 실행. 앞선 실패와 retry는 별도 보존 |
| 로컬 intent 분류기·도구 routing | 이번 신규 작성, Codex 보조로 합성 label fixture 준비 | 실제 fitting/inference. broad LLM 또는 일반 언어 성능 주장 안 함 |
| 행동 chunk 학습·평가 | 이번 신규 작성, Torch/NumPy 사용 | ACT-style tiny 모델. train/validation/test episode와 train-only 정규화 구분 |
| gain/delay 응답 추정 | 이번 신규 작성 | 실제 MuJoCo4개 reset 응답1600sample에서 calibration/holdout 분리 비교. 합성 fixture도 별도 사용. 하드웨어 쓰기 없음 |
| 원격 repo·source 배포 | 현재 작업 결과 | 실제 source ZIP 생성·manifest 검증 완료, 허용 소스 69개·미추적 누락 0. Private incinLee/so101-environment-agent 생성 완료, 원격 source 업로드는 인증·브라우저 문제로 미완료·빈 저장소 |

## 공개 SO-101 자산

[MuJoCo Menagerie 고정 SO-101 디렉터리](https://github.com/google-deepmind/mujoco_menagerie/tree/3abca2e302625cec9429c49806121ea2855cef81/robotstudio_so101)에서 선택 파일을 가져왔다. upstream README는 The Robot Studio SO101/I2RT Robotics 및 SO-ARM100 MJCF의 파생 관계를 기재한다. README·CHANGELOG·Apache-2.0 LICENSE를 보존했고 파일별 SHA256은 assets/robotstudio_so101/provenance.json에 있다.

원본 공개 자산은 수정하지 않았다. 환경 generator가 추가한 트레이·부품·카메라·평가 site와 설정은 생성 manifest에서 별도로 기록한다. 공개 관성·마찰·servo gain·충돌 geometry가 사용자 실기와 일치한다는 증거는 없다.

`.gitattributes`의 `assets/** -text`로 공개 자산의 bytes를 보존했다. `core.autocrlf=true`인 별도 로컬 Git 복제에서 자산 hash 확인과 실제 MuJoCo `demo --skip-training` 실행이 통과했고 scripted baseline 1/1·응답 비교를 완료했다. 이 검사는 Windows 로컬 source checkout의 실행 증거다.

## 라이선스·재현성

자체 코드/문서는 Proprietary / All rights reserved를 유지한다. 이번 저장소 공개는 사용자의 명시적 요청에 따른 소유자 승인 공개다. 승인된 비공개 사용·평가 외 공개 재배포 권한을 부여하지 않으며 제3자 자산에는 이 권리 제한을 덮어씌우지 않는다. SO-101 자산은 Apache-2.0이며 NOTICE에서 구분했다. MuJoCo·NumPy·Torch는 설치 의존성으로 source ZIP에 환경 바이너리를 포함하지 않는다. 실제 사용 버전은 실행 보고서와 의존성 명세에 기록한다.

Git 이력·SHA·실행 trace·원시 시행 결과를 사실대로 보존한다. 개발 날짜를 소급하거나 실패·중단·개입을 없애지 않는다. 합성 데이터/시뮬레이션 라벨을 실제 인간 시연으로 표시하지 않는다. 원본 자료·비밀키·체크포인트는 자동 게시하지 않는다.

최종 97개 시험은 18.346초에 전부 통과했고 skip은 0이다. 공통 release 판정·로더 보안 보완 뒤 새 전체 CLI에서도 scripted 9/9와 학습 정책 0/2 실패를 확인했다. [최종 검증 요약](VALIDATION_FINAL.json)과 원시 trace를 구분해 보존한다.

## 대회 신고

0.2.1에서 추가한 장면 검사 wrapper, 실제 물리 상태를 수집하는 영상 sink, MP4/AVI writer, CLI·PowerShell 녹화 명령과 회귀시험은 이번 개발 코드다. MP4는 격리 환경의 imageio-ffmpeg 0.6.0이 제공하는 FFmpeg 7.1 바이너리로 인코딩했다. 설치 의존성과 해당 제3자 바이너리의 라이선스는 각 배포물에 따르며, 이 프로젝트 소스 ZIP에는 설치된 환경·인코더 바이너리·영상·체크포인트를 포함하지 않는다. 영상은 새 MuJoCo 실행의 카메라 프레임이며 AI 생성 영상이나 원시 trace의 위치 재연이 아니다.

제13·20·30조에 따라 기존 공개 모델/라이브러리/사용자 보정 자료와 주제 공개 후 실제 환경 generator·검사·routing·학습/평가·보고 코드 기여를 구분한다. Codex 개발보조와 제품의 local classifier/Torch policy는 다른 항목으로 신고한다. 이번 확인된 팀은 기백 팀, 팀장 이주안, 소속 일반이다. 팀원의 실제 검토/통합 범위와 담당 비율은 임의 작성하지 않는다.

공식 source/AI 신고서의 별지 참조가 제공 규정에서 어긋나므로 최종 기술설명서 항목과 별도 상세 출처 기록으로 대응한다. 마감·신청서 최종본·제출물은 [규정 대응](RULE_COMPLIANCE.md)의 공식 안내에 따른다.
