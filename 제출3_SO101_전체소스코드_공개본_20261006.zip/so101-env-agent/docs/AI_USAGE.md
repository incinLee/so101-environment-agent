# AI 사용 기록

기준일: 2026-10-06. 개발 도구·제품 런타임 모델·움직임 정책의 역할을 분리해 기록한다.

| 대상 | 실제 사용 범위 | 증거와 제한 |
|---|---|---|
| Codex 개발보조 | 요구사항·코드·테스트·실행 안내·출처/규정 문서 작성, 제공 자료의 허용된 정적검사 | 참가팀의 실제 인적 검토·기여는 따로 기록. Codex 자체를 제품 runtime으로 표시하지 않음 |
| 로컬 intent AI | 문자2/3/4-gram TF-IDF와 gradient-descent softmax, 두 목표 tray_transfer/response_calibration 분류 | 합성 한·영 개발 예제36개로 fitting, 별도 fixture16개 평가. 일반 언어/안전 정확도의 근거 아님 |
| 목표 안전 guard | 명시적 규칙으로 실기·평가기준 우회·비밀/경로 요청 거부 | 학습 AI 판단과 구분. softmax confidence는 안전보장 확률이 아님 |
| 행동 chunk 정책 | Torch 2.8.0 CPU의 32차원2층4-head Transformer, state 12 / action 6 / chunk 4 | ACT-style tiny 모델. original ACT 이미지 encoder·CVAE·사용자 ACT 자산 통합 미구현 |
| scripted baseline | damped IK와 제한된 관절 setpoint로 실제 MuJoCo 접촉 이송 | 학습 정책이 아니며 baseline 성공을 AI 정책 성공으로 보고하지 않음 |
| 응답 추정 | 범위가 제한된 scalar gain/delay 수치 추정과 별도 holdout 비교 | LLM 생성 수치가 아니며 합성 검증은 실측 보정이 아님 |

제품 runtime은 외부 LLM/API를 사용하지 않는 로컬 경로를 선택했다. 텍스트를 shell 명령으로 실행하지 않고 등록 tool과 검증된 인자만 사용한다. 실행 예산·제한된 retry·보호된 평가 기준을 적용한다. 전체 runtime/정책의 최종 수행 근거는 [전달 상태](DELIVERY_STATUS.md)와 실제 trace를 따른다.

보정 ZIP과 참고 MD는 사용자 제공 자료다. 과거 코드·정책은 ZIP에 없으므로 현재 통합됐다고 쓰지 않는다. 공개 SO-101 자산은 고정 upstream commit·파일별 SHA256·Apache-2.0으로 구분한다. 사용자 원본 코드·영상·로그를 제품 외부 모델로 보내는 기능은 이 경로에 포함하지 않는다.

제출 설명에는 실제 사용한 도구·모델·버전, 작성/수정 범위, 팀의 검토·통합·시험, 실패와 한계를 기록한다. 알려지지 않은 팀명·담당자·모델 식별자·성과 수치를 만들어 넣지 않는다. 좁은 fixture 성과를 일반 사용자 정확도나 산업 신뢰성으로 확대하지 않는다.
