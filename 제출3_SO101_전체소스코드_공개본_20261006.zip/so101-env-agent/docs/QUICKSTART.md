# 실행 안내

기준일: 2026-10-06, 버전 0.2.2. 실제 MuJoCo·학습 분류기·행동 chunk 모듈과 독립 CPU 작업장 1~8개 병렬 시연 수집을 포함한다. 기존 0.2.0 Windows CPU 전체 CLI의 학습 정책 holdout 이송은 0/2건 실패했다. 이 과거 결과를 새 병렬 실행 결과로 간주하지 않는다. Ubuntu/CUDA·실제 로봇 실행은 검증하지 않았다. 기존 결과·제한은 [전달 상태](DELIVERY_STATUS.md), 새 병렬 실행 절차는 [8개 작업장 안내](PARALLEL_GUIDE.md)에 있다.

## 데모

source 프로젝트 폴더에서 실행한다. Python 3.10 이상이 필요하며 첫 실행은 프로젝트의 격리 가상환경과 필요한 의존성을 준비한다. wheel 설치 배포는 robot 자산·configs 포함이 미구현이므로 지원하지 않는다. 원본 데이터·전역 Python·드라이버를 변경하는 절차가 아니다.

Windows PowerShell:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\run_demo.ps1
```

Ubuntu:

```bash
bash scripts/run_demo.sh
```

Ubuntu 명령은 제공하는 실행 절차이며 해당 사용자 Ubuntu 호스트에서는 실행하지 않았다. Bash는 Git Bash syntax 검사만 통과했다. Windows wrapper는 이미 의존성이 설치된 환경에서 `-SkipInstall -SkipPolicy`로 baseline 1건·응답 비교를 실제 실행했다. 전체 Windows CLI 데모는 별도 실행했고, CLI help의 위 계약도 확인했다.

정책 설치·학습을 생략하고 환경·baseline·응답 경로만 실행하려면 PowerShell 스크립트에 `-SkipPolicy`를, Bash 스크립트에 `--skip-policy`를 붙인다. `-SkipInstall`/`--skip-install`은 시뮬레이션 의존성이 이미 준비된 경우에만 사용한다.

가상환경 준비 후 직접 호출하는 Windows 명령:

```powershell
$env:PYTHONPATH = Join-Path (Get-Location) 'src'
.\.venv\Scripts\python.exe -m robot_env_agent demo --goal "부품을 한 트레이에서 다른 트레이로 옮기는 환경을 구성하고 검증해줘" --scene configs/scene.simulation.json --output-dir runs/my-demo --epochs 60
```

Ubuntu에서는 다음과 같다.

```bash
export PYTHONPATH=src
.venv/bin/python -m robot_env_agent demo --goal '부품을 한 트레이에서 다른 트레이로 옮기는 환경을 구성하고 검증해줘' --scene configs/scene.simulation.json --output-dir runs/my-demo --epochs 60
```

실행 증거를 보존하도록 매번 새로운 output-dir를 사용한다. 기본 epochs는60이며 학습 예산을 무한히 늘리지 않는다. 모델·그리퍼 동작은 실제 물리 계산 안에서 수행한다. 프로그램은 USB·카메라 장비·실제 모터를 연결하지 않는다. exit0은 도구 흐름 실행 완료이며 학습 정책 task_success와 별개다. 학습 분류기의 잘못된 목표 판단이나 정책 실패도 결과에 그대로 남긴다.

## 8개 작업장의 시연 수집

설치된 `.venv`에서 아래 CLI를 실행한다. 기존 bootstrap 스크립트에 새 worker 인수를 가정해 전달하지 않는다.

```powershell
$env:PYTHONPATH = Join-Path (Get-Location) 'src'
.\.venv\Scripts\python.exe -m robot_env_agent agent --scene configs/scene.simulation.json --output-dir runs/my-parallel8 --epochs 60 --workers 8
```

요청 작업장 수는 8, 전체 시연은 9회다. 작업장은 독립 SO-101 한 팔 장면을 실행하며 다른 작업장과 충돌/통신하지 않는다. 8개 슬롯 중 먼저 맡은 첫 번째 슬롯은 seed0 이후 seed8을 실행한다. 시연은 seed순으로 모아 5/2/2로 분리한 뒤 기존 CPU 모방학습을 수행한다. `--workers`를 생략하면 이전처럼 순차 실행한다. `--skip-training`은 1회만 실행하므로 `--workers 8`과 함께 사용해도 유효 작업장 수는 1이다.

실행 중에는 `runs/my-parallel8/baseline/parallel_progress.json`, 실행 후에는 `workflow_report.json`의 `parallel_collection`과 `baseline/parallel_collection.json`에서 요청 수·유효 수·실행 구간의 최대 중첩·PID·수집 시간을 확인한다. 슬롯별 카메라 PNG와 시연 파일은 `baseline/seed-N/`에 있다. 전체 정책 성공·실패는 별도의 `policy_evaluation`으로 판단한다. [상세 경로·실패 처리](PARALLEL_GUIDE.md)를 확인한다.

## 결과를 읽는 순서

1. 장면/실행 manifest에서 simulation 설정·자산 SHA·seed·단위를 확인한다.
2. runtime trace에서 목표 분류→계획→등록 tool→결과 확인과 제한된 피드백을 확인한다.
3. scripted baseline의 관절·접촉·부품 trace와 카메라 PNG를 확인한다. scripted 성공과 학습 정책 성공은 별개다.
4. episode 분할·train-only 정규화·학습 보고서의 행동 오차를 확인한다.
5. 학습 정책의 실제 닫힌고리 평가에서 성공·실패·시행 수를 확인한다. loss 감소를 성공률로 바꾸지 않는다.
6. 응답 추정은 입력 execution_kind와 holdout 분리를 확인한다. synthetic 검증은 실측 보정이 아니다.

## 기존 정적·mock 코어

아래 명령은 물리 데모와 별개의 기초 검사다. Python 표준 라이브러리 코어를 사용한다.

```powershell
$env:PYTHONPATH = Join-Path (Get-Location) 'src'
python -m robot_env_agent validate --profile configs/robot_profile.draft.json --task configs/task.draft.json --output runs/validation.json
python -m robot_env_agent plan --profile configs/robot_profile.draft.json --task configs/task.draft.json --output runs/plan.json
python -m robot_env_agent build --profile configs/robot_profile.draft.json --task configs/task.draft.json --output runs/environment.draft.json
python -m robot_env_agent run-mock --bundle runs/environment.draft.json --output runs/mock_run.json
```

unknown/null이 남은 draft는 실제 장비 준비 완료가 아니다. mock 파일을 실제 MuJoCo 결과로 부르지 않는다. 승인된 보정 ZIP은 local_data에 둘 수 있으나 source ZIP에는 포함하지 않는다.

## 시험

장면 창을 직접 열고 실제 물리 실행을 MP4로 저장하는 절차는 [영상 실행 안내](VIDEO_GUIDE.md)에 있습니다. 기존 로컬 `.venv`에서는 `powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\record_video.ps1 -SkipInstall -Open`으로 새 scripted 실행을 녹화하고 열 수 있습니다.

```powershell
$env:PYTHONPATH = Join-Path (Get-Location) 'src'
.\.venv\Scripts\python.exe -m unittest discover -s tests -v
```

Ubuntu는 `.venv/bin/python`으로 바꾼다. 의존성 유무에 따라 선택 시험의 실행 여부가 달라질 수 있으므로 skipped/not_run도 확인한다. [0.2.0 검증 요약](VALIDATION_FINAL.json)은 당시 Windows CPU 시험 97건을 기록한다. 현재 0.2.2는 [8환경 검증](VALIDATION_PARALLEL8.json)의 backend121건·앱42건 결과를 확인한다. `docs/VALIDATION.json`의 초기 32건은 별도 역사 기록이다.

## GitHub 공개용 소스

소유자의 2026-10-06 요청에 따라 공개용 사본을 준비했습니다. 저장소와 다운로드 ZIP은 상위 README를 확인하세요. 이전 버전의 `publish_github.ps1`은 backend만 단독 게시하는 보조 스크립트이며 현재 backend+앱 ZIP 게시 절차와 구분합니다. 실제 업로드 완료·공개 상태는 원격 저장소에서 확인합니다.

## 소스 ZIP

Git의 추적 허용 소스만 담는다. 원본 보정·데이터·runs·가상환경·정책 weights·비밀파일은 제외하며, 공개 robot 자산과 원라이선스는 포함한다.

이전 0.2.0 backend source ZIP은 허용 소스69개와 manifest로 생성·검증했다. 이번 backend+앱 공개 ZIP의 파일별 hash와 목록은 ZIP 외부 공개본 검증 기록을 확인한다. 최종 ZIP의 SHA·바이트 수는 외부 release 기록에서 확인한다. `.gitattributes`로 자산의 bytes를 보존하며 Windows의 `core.autocrlf=true`인 별도 로컬 Git 복제에서도 `demo --skip-training`으로 모델 hash·baseline 1/1·응답 비교를 검증했다.

```powershell
python scripts/package_release.py --output ../so101-env-agent-source.zip
```

새 소스·자산·문서는 내용과 라이선스를 확인한 뒤 필요한 파일만 git add한다. 미추적 파일은 출력 JSON의 untracked_allowlisted_files_omitted에 표시한다. 모든 최종 변경 후 ZIP을 다시 생성한다.

ZIP 내부 RELEASE_MANIFEST.json에는 파일별 SHA256·바이트 수가 있으며 생성 직후 검증한다. 정렬·고정 timestamp로 동일 입력/동일 패키징 환경에서 재현한다. 기존 자체 release ZIP만 반복 생성할 수 있고, 다른 ZIP이나 보호된 사용자 자료 경로는 덮어쓰지 않는다. 이 source ZIP은 신청서·보고서·영상·발표자료가 모두 갖춰진 공식 대회 제출 ZIP과 별개다.

