# 독립 CPU 작업장 8개로 시연을 수집하기

기준일: 2026-10-06, 버전 0.2.2. 이 문서는 구현 계약과 실행 절차다. 실제 처리량·성공률은 아래 신규 run의 완료 보고서와 비교 기록에서 확인한다. 0.2.0/0.2.1 검증 JSON은 과거 기록으로 보존하며 이번 변경의 결과로 재분류하지 않는다.

## 무엇이 8개인가

하나의 SO-101, 한 부품, Source/Target 트레이가 있는 작업장 8개를 독립 프로세스에서 실행한다. 각 프로세스는 동일한 검증된 world를 읽지만 자체 MuJoCo model/data와 렌더러를 생성한다. 작업장끼리 접촉하거나 한 장면에서 8대가 협업하지 않는다. 사용자 보유 팔로워 2대의 실제 작동과도 별개다.

8은 동시에 시연을 수집할 수 있는 worker 수다. 전체 시연 수는 여전히 9회(seed0~8)이며, 고정된 학습 5회(seed0~4)·검증 2회(seed5~6)·시험 2회(seed7~8) 분리를 유지한다. 슬롯0이 seed0과 seed8을 순서대로 실행하고, 슬롯1~7이 각각 seed1~7을 맡는다. 결과는 완료 순서가 아니라 요청 seed순으로 정렬한다. 실패가 있으면 실패와 부분 파일을 보존하고, 성공 시연 9회가 완성되지 않았을 때 정책 학습을 생략한다.

정책은 기존 상태 기반 작은 행동 chunk Transformer 하나이며 scripted 시연에 대한 모방학습을 사용한다. 미니배치 64는 한 번의 모델 업데이트에서 묶는 학습 샘플 수다. 독립 작업장 8개와 다른 개념이며 강화학습, GPU/MJX 학습, 실물 전이를 추가하지 않는다. 초기 위치 변화도 기존 ±2mm 가정이며 자동으로 폭넓은 물리 랜덤화를 도입하지 않는다.

## 실행 명령

프로젝트 `.venv` 의존성이 준비된 Windows PowerShell에서:

```powershell
$env:PYTHONPATH = Join-Path (Get-Location) 'src'
.\.venv\Scripts\python.exe -m robot_env_agent agent --scene configs/scene.simulation.json --output-dir runs/my-parallel8 --epochs 60 --workers 8
```

`demo`도 동일한 `--workers` 인수를 받는다. 정수 1~8만 허용하며 CLI 기본값은 1이다. 새 실행마다 존재하지 않는 output-dir를 선택한다. 잘못된 workers/seed 또는 기존 증거 폴더를 검사할 때 실패를 반환한다. 기존 폴더를 지우거나 덮어써 결과를 합격시키지 않는다.

`--skip-training`은 기존 빠른 경로로 시연 한 건만 실행한다. workers8을 요청해도 `requested_workers=8`, `effective_workers=1`로 기록하고 순차 처리한다. 응답 보정 의도로 실행하면 tray 시연 수집은 실행하지 않는다. worker 수는 별도 정책 holdout 평가·응답 추정의 병렬화를 의미하지 않는다.

Ubuntu용 같은 계약의 명령은 아래와 같다. 이는 제공하는 실행 절차이며 사용자 Ubuntu 또는 CUDA 호스트에서 실제 실행을 확인한 기록이 아니다.

```bash
export PYTHONPATH=src
.venv/bin/python -m robot_env_agent agent --scene configs/scene.simulation.json --output-dir runs/my-parallel8 --epochs 60 --workers 8
```

## 어디에서 확인하는가

`runs/my-parallel8/`을 run 루트로 읽는다. 제한된 좌표 수정으로 재시도하면 `baseline` 대신 `baseline_retry`가 생성되며 최초 실패 근거를 함께 남긴다.

| 경로 | 확인하는 내용 |
|---|---|
| `workflow_state.json` | 환경 생성·수집·학습·평가 등 현재 도구 단계 |
| `baseline/parallel_progress.json` | 실행 중 요청/유효 worker 수, 완료/전체 시연 수, 슬롯의 seed/PID/상태/증거 경로 |
| `baseline/parallel_collection.json` | 수집 완료 후 worker 수·PID·실행 구간 중첩·수집 wall time·실행 모드 |
| `baseline/seed-N/parallel_execution.json` | episode 담당 PID·슬롯과 UTC 시작/종료 시각·Unix 초 |
| `baseline/seed-N/simulation_report.json` | 정상 반환된 물리 시행의 기준 제어 성공/실패·관절/접촉·시간·카메라 정보 |
| `baseline/seed-N/parallel_failure.json` | Python 예외·process crash·수집 시간 예산 등 수집 실패 기록. 부분 trace/PNG를 지우지 않음 |
| `baseline/seed-N/camera_initial.png`, `camera_close.png`, `camera_lift.png`, `camera_place.png`, `camera_hold.png` | 해당 시행의 실제 저장된 가상 카메라 장면. 렌더 실패·중단에는 일부가 없을 수 있음 |
| `baseline/seed-N/joint_trace.jsonl`, `demonstration.npz` | 시행별 물리 trace와 시연 샘플. 카메라는 학습 입력이 아님 |
| `workflow_report.json` | `parallel_collection`, `parallel_collection_attempts`, `baseline_attempts`, 고정 분할 dataset, 학습/정책 평가를 함께 확인 |
| `index.html` | 완료 보고서. 저장된 시행 이미지와 수집 정보를 읽음 |

진행 JSON은 부모 프로세스 한 곳에서 쓰며 `evidence_kind=simulation`, `requested_workers`, `effective_workers`, `completed`, `total`, `status`, `slots`를 포함한다. 슬롯은 `{slot, seed, pid, status, evidence_directory}`이며 pending→running→succeeded/failed 상태를 가진다. slot0이 seed8을 맡으면 해당 슬롯의 seed도 8로 갱신된다. 완료 횟수에는 실패도 포함한다. 따라서 `completed=9` 자체는 성공9/9를 뜻하지 않는다.

`parallel_collection.max_concurrent_observed`는 시작/종료 시각으로 계산한 episode 실행 구간의 최대 중첩이다. 여기에는 초기화·모델/자산 검사·물리 계산·증거 렌더/저장이 포함되며 물리 step만 동시에 실행한 수치는 아니다. `unique_worker_pids`로 실제 별도 프로세스를 확인한다. `wall_seconds`는 수집 단계의 실제 경과 시간이며 학습·정책 평가·응답 추정을 모두 포함한 workflow wall time과 구분한다.

## Windows 실행과 실패 처리

Windows `spawn`으로 프로세스를 만들며 CLI entry module은 `if __name__ == '__main__'` guard를 사용해 child가 CLI를 다시 실행하지 않는다. 병렬 child는 OMP/OPENBLAS/MKL 등 수치 라이브러리 thread 수를 1로 제한한다. 부모 프로세스·전역 환경·드라이버 설정은 변경하지 않는다. 시작 barrier는 30초로 제한하며 개별 기존 물리 시행의 55초 예산도 유지한다. 병렬 수집은 유한한 전체 시간 예산과 child 종료 처리를 사용한다.

브라우저가 진행 JSON을 읽는 순간 Windows가 파일 공유 잠금을 유지할 수 있다. atomic rename의 `PermissionError.winerror`가 5/32/33인 경우만 10ms 간격으로 최대 50회 재시도한다. 최대 대기 합계는 0.49초다. 지속되는 잠금이나 다른 권한 오류는 예외로 남기며 무한 재시도하거나 성공으로 바꾸지 않는다. worker 예외·예고 없는 process 종료는 맡은 시연의 실패로 남기고, 부분 출력은 보존한다. child를 중단해야 할 때는 종료/join 후 실패 파일을 기록해 부모·child의 파일 쓰기 경합을 피한다.

## 새 측정 기록

2026-10-06 검증 완료: `runs/parallel8-serial-20261006-retry1/`와 `runs/parallel8-20261006/`을 동일 조건으로 비교했다. 시연 수집은 순차10.000초·8-worker6.266초로 한 쌍 비교에서 약1.596배였다. 서로 다른 PID8개와 episode 호출 구간의 최대 중첩8을 확인했다. 같은 seed의 관측·명령·시간 배열은 절대오차1e-9 이내로 일치했고, 기준 제어는 각각9/9 성공했다. 학습 정책 폐루프는 두 실행 모두0/2였다. 백엔드121개·앱42개 검사 및 실제 브라우저 full+8 실행을 확인했다. `docs/VALIDATION_PARALLEL8.json`이 새 버전의 검증 기록이다. 초기 `runs/parallel8-serial-20261006/`의 Windows snapshot 공유 잠금 실패는 그대로 보존했다.

비교할 때에는 동일한 scene/seed/시연 수와 카메라 출력 조건을 유지한다. worker 수 8이 속도 8배를 보장하지 않는다. CPU 부하·렌더/저장·프로세스 시작 비용에 따라 달라지며, 병렬 수집이 학습 정책의 작업 성공이나 실제 전이를 자동으로 개선한다는 주장도 하지 않는다. baseline 성공, 학습 정책 성공, 실물 성공은 각각 별도로 검증한다.
