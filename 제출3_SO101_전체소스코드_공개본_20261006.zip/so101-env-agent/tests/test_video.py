"""Recording checks cover physics provenance, failed outcomes and output integrity."""
import importlib.util
import json
from pathlib import Path
import struct
import tempfile
import unittest
from unittest.mock import patch

from robot_env_agent.video import _AVIWriter, _validate_options, record_simulation_video
from robot_env_agent.simulation import ASSET_ROOT, build_world


class VideoOptionsTests(unittest.TestCase):
    def test_fps_and_explicit_encoder_are_validated(self):
        for fps in (0, 31, True, 15.0, "15", float("nan")):
            with self.subTest(fps=fps), self.assertRaises(ValueError):
                _validate_options(fps, None)
        with tempfile.TemporaryDirectory() as directory:
            with self.assertRaises(ValueError):
                _validate_options(15, Path(directory)/"missing-encoder.exe")

    @unittest.skipUnless(importlib.util.find_spec("PIL") and importlib.util.find_spec("numpy"),
                         "isolated imaging dependencies required")
    def test_streaming_avi_has_frame_count_index_and_no_overwrite(self):
        import numpy as np
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory)/"example.avi"
            writer = _AVIWriter(path, 15)
            for value in (30, 90, 180):
                writer.write(np.full((480, 640, 3), value, dtype=np.uint8))
            writer.close()
            writer.close()
            data = path.read_bytes()
            self.assertEqual(data[:4], b"RIFF")
            self.assertEqual(data[8:12], b"AVI ")
            self.assertEqual(struct.unpack("<I", data[4:8])[0], len(data)-8)
            self.assertEqual(struct.unpack("<I", data[48:52])[0], 3)
            self.assertEqual(struct.unpack("<I", data[140:144])[0], 3)
            self.assertIn(b"idx1", data)
            self.assertEqual(data.count(b"\xff\xd8\xff"), 3)
            with self.assertRaises(FileExistsError):
                _AVIWriter(path, 15)


@unittest.skipUnless(importlib.util.find_spec("mujoco") and importlib.util.find_spec("PIL")
                     and (ASSET_ROOT/"provenance.json").exists(),
                     "isolated MuJoCo dependencies and public model required")
class VideoPhysicsTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temporary = tempfile.TemporaryDirectory()
        cls.root = Path(cls.temporary.name)
        cls.world = Path(build_world(cls.root/"world", {})["world_path"])

    @classmethod
    def tearDownClass(cls):
        cls.temporary.cleanup()

    def test_source_and_existing_evidence_cannot_be_overwritten(self):
        existing = self.root/"existing"
        existing.mkdir()
        sentinel = existing/"important.txt"
        sentinel.write_text("preserve", encoding="utf-8")
        for output in (self.world.parent, self.world.parent/"robot", ASSET_ROOT, existing):
            with self.subTest(output=output), self.assertRaises(ValueError):
                record_simulation_video(self.world, output)
        self.assertEqual(sentinel.read_text(), "preserve")
        with self.assertRaises(ValueError):
            record_simulation_video(self.world, self.root/"missing-checkpoint", controller="learned")
        with self.assertRaises(ValueError):
            record_simulation_video(self.world, self.root/"wrong-controller", controller="ACT")
        with self.assertRaises(ValueError):
            record_simulation_video(self.world, self.root/"wrong-checkpoint", checkpoint_dir=self.root)

    def test_fresh_scripted_physics_produces_real_frames_and_timestamps(self):
        output = self.root/"recorded-baseline"
        # Explicitly exercise installation-free AVI fallback even when MP4 is available.
        with patch("robot_env_agent.video._validate_options", return_value=None):
            report = record_simulation_video(self.world, output, seed=1, fps=5)
        self.assertEqual(report["physical_status"], "not_run")
        self.assertFalse(report["ai_policy_used"])
        self.assertTrue(report["task_success"], report["task_failure_reason"])
        self.assertIsNone(report["execution_error"])
        video = report["video"]
        self.assertEqual(video["video_status"], "executed", video["video_error"])
        self.assertGreater(video["frame_count"], 60)
        self.assertLessEqual(video["frame_count"], 600)
        self.assertFalse(video["trajectory_replay_used"])
        self.assertFalse(video["teleportation_after_reset"])
        timeline = [json.loads(row) for row in (output/video["timeline_path"]).read_text().splitlines()]
        self.assertEqual(len(timeline), video["frame_count"])
        self.assertEqual(timeline[0]["actual_simulation_timestamp_s"], 0)
        for frame in timeline:
            self.assertGreaterEqual(frame["capture_lateness_s"], -1e-9)
            self.assertLess(frame["capture_lateness_s"], 0.04)
        self.assertAlmostEqual(video["video_duration_s"], report["simulated_seconds"], delta=0.2)
        self.assertGreater((output/video["video_path"]).stat().st_size, 1000)
        self.assertTrue((output/"simulation_report.json").exists())
        with self.assertRaises(ValueError):
            record_simulation_video(self.world, output)

    def test_encoder_failure_is_reported_separately_from_physics_verdict(self):
        output = self.root/"encoder-failed"
        with patch("robot_env_agent.video._FFmpegWriter", side_effect=RuntimeError("test encoder failure")), \
             patch("robot_env_agent.video._validate_options", return_value=Path("trusted-test-encoder")):
            report = record_simulation_video(self.world, output, seed=0)
        self.assertTrue(report["task_success"], "camera failure must not fabricate a physics failure")
        self.assertEqual(report["video"]["video_status"], "failed")
        self.assertIn("test encoder failure", report["video"]["video_error"])
        self.assertIsNone(report["video"]["video_sha256"])
        self.assertTrue((output/"video_report.json").exists())

    def test_failed_physics_episode_still_preserves_playable_failure_video(self):
        world = Path(build_world(self.root/"unreachable-world",
                                 {"source_center_m": [0.38, -0.07],
                                  "target_center_m": [0.38, 0.07]})["world_path"])
        output = self.root/"failed-task"
        with patch("robot_env_agent.video._validate_options", return_value=None):
            report = record_simulation_video(world, output, seed=2, fps=5)
        self.assertFalse(report["task_success"])
        self.assertIsNotNone(report["task_failure_reason"])
        self.assertEqual(report["video"]["video_status"], "executed")
        self.assertGreater(report["video"]["frame_count"], 60)

    def test_unloaded_learned_checkpoint_never_claims_ai_execution(self):
        checkpoint = self.root/"missing-policy"
        report = record_simulation_video(self.world, self.root/"policy-load-failed",
                                         controller="learned", checkpoint_dir=checkpoint)
        self.assertEqual(report["simulation_status"], "failed")
        self.assertFalse(report["ai_policy_used"])
        self.assertIsNone(report["task_success"])
        self.assertIsNotNone(report["execution_error"])
        self.assertEqual(report["video"]["frame_count"], 0)
        self.assertEqual(report["video"]["video_status"], "failed")

    @unittest.skipUnless(importlib.util.find_spec("imageio_ffmpeg"), "optional bundled FFmpeg required")
    def test_actual_mp4_encoder_creates_container_from_fresh_camera(self):
        output = self.root/"mp4"
        report = record_simulation_video(self.world, output, seed=2, fps=5)
        video = report["video"]
        self.assertEqual(video["container"], "mp4")
        self.assertEqual(video["video_status"], "executed", video["video_error"])
        self.assertTrue(report["task_success"])
        with (output/video["video_path"]).open("rb") as source:
            self.assertEqual(source.read(8)[4:], b"ftyp")


if __name__ == "__main__":
    unittest.main()
