import json
import tempfile
import unittest
from pathlib import Path

import numpy as np

from robot_env_agent.learning import load_chunk_dataset
from robot_env_agent.simulation import DEFAULT_SCENE, validate_scene
from robot_env_agent.workflow import aggregate_demonstrations, protected_evaluation, propose_layout_repair, resolve_run_directory


class WorkflowBoundaries(unittest.TestCase):
    def test_output_sources_and_prior_evidence_are_protected(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            for path in ("../escaped", "configs/new", ".git/new", "runs"):
                with self.assertRaises(PermissionError):
                    resolve_run_directory(root, path)
            target = resolve_run_directory(root, "runs/new")
            target.mkdir(parents=True)
            with self.assertRaises(ValueError):
                resolve_run_directory(root, "runs/new")

    def test_feedback_repair_cannot_change_fixed_criterion(self):
        scene = validate_scene({**DEFAULT_SCENE, "source_center_m": [0.38, -0.07], "target_center_m": [0.38, 0.07]})
        feedback = {"task_success": False, "max_ik_position_error_m": 0.12}
        repaired = propose_layout_repair(scene, feedback)
        self.assertEqual(protected_evaluation(scene), protected_evaluation(repaired))
        for key in scene.keys()-{"source_center_m", "target_center_m"}:
            self.assertEqual(scene[key], repaired[key])
        self.assertEqual(scene["source_center_m"], [0.38, -0.07])

    def test_contact_failure_does_not_trigger_unrelated_layout_changes(self):
        self.assertIsNone(propose_layout_repair(DEFAULT_SCENE, {"task_success": False, "max_ik_position_error_m": 0.001}))
        self.assertIsNone(propose_layout_repair(DEFAULT_SCENE, {"task_success": True, "max_ik_position_error_m": 0.1}))

    def make_episodes(self, root):
        metadata = {"schema_version": 1, "data_kind": "simulation", "label_source": "scripted_controller",
                    "action_unit": "rad", "action_semantics": "absolute_joint_position", "time_unit": "s",
                    "clock_domain": "simulation_episode_time", "observation_names": ["q"], "action_names": ["q"], "split": "unassigned"}
        paths = []
        for i in range(9):
            path = root/f"episode-{i}.npz"
            np.savez(path, observations=np.ones((6, 1))*i, actions=np.ones((6, 1))*i,
                     timestamps_s=np.arange(6)*0.034, metadata_json=np.asarray(json.dumps(metadata)))
            paths.append(path)
        return paths, metadata

    def test_aggregation_keeps_episodes_in_disjoint_splits(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            paths, _ = self.make_episodes(root)
            aggregate_demonstrations(paths, root/"data.npz")
            data = load_chunk_dataset(root/"data.npz")
            for episode in np.unique(data["episode_ids"]):
                self.assertEqual(len(set(data["splits"][data["episode_ids"] == episode])), 1)
            self.assertEqual(set(data["episode_ids"][data["splits"] == "test"]), {"seed-7", "seed-8"})

    def test_aggregation_rejects_mixed_action_units(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            paths, metadata = self.make_episodes(root)
            metadata["action_unit"] = "degree"
            np.savez(paths[-1], observations=np.ones((6, 1)), actions=np.ones((6, 1)),
                     timestamps_s=np.arange(6)*0.034, metadata_json=np.asarray(json.dumps(metadata)))
            with self.assertRaises(ValueError):
                aggregate_demonstrations(paths, root/"data.npz")
            self.assertFalse((root/"data.npz").exists())

    def test_duplicate_demonstration_paths_and_copies_are_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            paths, _ = self.make_episodes(root)
            with self.assertRaisesRegex(ValueError, "duplicate demonstration paths"):
                aggregate_demonstrations([paths[0]]*9, root/"data.npz")
            paths[-1].write_bytes(paths[0].read_bytes())
            with self.assertRaisesRegex(ValueError, "duplicate demonstration contents"):
                aggregate_demonstrations(paths, root/"data.npz")
            self.assertFalse((root/"data.npz").exists())
