import copy
import json
import tempfile
import unittest
from pathlib import Path

from robot_env_agent.contracts import parse_profile, parse_task, validate
from robot_env_agent.runtime import ToolExecutor, build_draft, plan, read_json, resolve_path, run_mock, validate_bundle


PROJECT = Path(__file__).resolve().parents[1]


class ContractRuntimeTests(unittest.TestCase):
    def setUp(self):
        self.profile_data = json.loads((PROJECT / "configs/robot_profile.draft.json").read_text())
        self.task_data = json.loads((PROJECT / "configs/task.draft.json").read_text())

    def values(self):
        return parse_profile(self.profile_data), parse_task(self.task_data)

    def test_unknowns_are_preserved_and_block_physics(self):
        profile, task = self.values()
        result = validate(profile, task).to_dict()
        self.assertEqual(result["draft_status"], "passed")
        self.assertEqual(result["simulation_readiness"], "blocked")
        self.assertIn("profile.use_degrees", result["missing"])
        self.assertIsNone(profile.use_degrees)
        self.assertEqual(plan(profile, task)["next_action"], "build_draft_and_collect_missing_inputs")

    def test_joint_order_mismatch_blocks_build(self):
        self.profile_data["joints"][0], self.profile_data["joints"][1] = self.profile_data["joints"][1], self.profile_data["joints"][0]
        profile, task = self.values()
        self.assertEqual(plan(profile, task)["next_action"], "correct_invalid_configuration")
        with self.assertRaises(ValueError):
            build_draft(profile, task)

    def test_degrees_and_normalized_actions_are_not_interchangeable(self):
        self.profile_data["use_degrees"] = False
        self.profile_data["joints"][0]["command_unit"] = "deg"
        result = validate(*self.values())
        self.assertTrue(any("incompatible" in error for error in result.errors))

    def test_gripper_units_are_checked_even_when_body_mode_is_unknown(self):
        self.profile_data["joints"][-1]["command_unit"] = "deg"
        self.assertTrue(any("gripper: incompatible" in error for error in validate(*self.values()).errors))

    def test_model_joint_mapping_is_one_to_one(self):
        for joint in self.profile_data["joints"]:
            joint["model_joint"] = "same_joint"
        self.assertTrue(any("duplicate model joint" in error for error in validate(*self.values()).errors))

    def test_huge_integer_measurements_fail_validation_without_overflow(self):
        self.task_data["hold_seconds"] = 10**1000
        self.task_data["target_tray_bounds_m"] = [0, 0, 0, 10**1000, 1, 1]
        result = validate(*self.values())
        self.assertIn("task.hold_seconds", result.errors)
        self.assertIn("task.target_tray_bounds_m", result.errors)

    def test_duplicate_camera_names_are_rejected(self):
        self.profile_data["cameras"] = [{"name": "top"}, {"name": "top"}]
        self.assertTrue(any("duplicate camera" in error for error in validate(*self.values()).errors))

    def test_bool_and_negative_measurements_are_rejected(self):
        self.profile_data["control_hz"] = True
        self.task_data["object_size_m"] = [-1, 1, 1]
        result = validate(*self.values())
        self.assertIn("profile.control_hz", result.errors)
        self.assertIn("task.object_size_m", result.errors)

    def test_transfer_requires_tray_bounds_and_not_lift_height(self):
        profile, task = self.values()
        result = validate(profile, task)
        self.assertIn("task.source_tray_bounds_m", result.missing)
        self.assertIn("task.target_tray_bounds_m", result.missing)
        self.assertNotIn("task.success_height_m", result.missing)
        self.task_data["target_tray_bounds_m"] = [1, 0, 0, 0, 1, 1]
        self.assertIn("task.target_tray_bounds_m", validate(*self.values()).errors)

    def test_draft_build_is_bounded_and_does_not_claim_physics(self):
        bundle, report = build_draft(*self.values())
        self.assertEqual(len(report["tool_trace"]), 3)
        self.assertFalse(bundle["physics_asset_included"])
        self.assertEqual(bundle["execution_kind"], "draft")
        self.assertEqual(bundle["physical_status"], "not_run")

    def test_evaluation_mutation_is_detected(self):
        bundle, _ = build_draft(*self.values())
        changed = copy.deepcopy(bundle)
        changed["task"]["hold_seconds"] = 0.01
        with self.assertRaisesRegex(ValueError, "integrity"):
            validate_bundle(changed)

    def test_fake_real_or_simulated_success_is_rejected(self):
        bundle, _ = build_draft(*self.values())
        bundle["physical_status"] = "passed"
        with self.assertRaisesRegex(ValueError, "cannot claim"):
            run_mock(bundle)

    def test_mock_does_not_invent_measurements_or_calibration_results(self):
        bundle, _ = build_draft(*self.values())
        result = run_mock(bundle)
        self.assertEqual(result["execution_kind"], "mock")
        self.assertIsNone(result["task_success"])
        self.assertIsNone(result["real_calibration_improvement"])
        self.assertTrue(all(row["transmitted_command"] is None and row["measured_joint_state"] is None
                            for row in result["records"]))

    def test_real_tool_cannot_be_enabled_by_boolean_flag(self):
        executor = ToolExecutor({"noop": lambda: None})
        with self.assertRaises(PermissionError):
            executor.call("run_real", approved=True)

    def test_tool_budget_and_path_boundaries(self):
        executor = ToolExecutor({"noop": lambda: None}, max_calls=1)
        executor.call("noop")
        with self.assertRaises(RuntimeError):
            executor.call("noop")
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            with self.assertRaises(PermissionError):
                resolve_path(root, "../outside.json")
            with self.assertRaises(PermissionError):
                resolve_path(root, ".git/config")

    def test_unknown_config_fields_and_duplicate_keys_are_rejected(self):
        self.profile_data["approved"] = True
        with self.assertRaises(ValueError):
            parse_profile(self.profile_data)
        with tempfile.TemporaryDirectory() as temp:
            source = Path(temp) / "duplicate.json"
            source.write_text('{"a":1,"a":2}')
            with self.assertRaisesRegex(ValueError, "duplicate JSON key"):
                read_json(source)


if __name__ == "__main__":
    unittest.main()
