"""A recording verdict must remain distinct from a robot-task verdict."""
import contextlib
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from robot_env_agent.cli import main


class RecordingExitStatusTests(unittest.TestCase):
    def invoke_recording(self, report):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            output = io.StringIO()
            with patch("robot_env_agent.video.record_simulation_video", return_value=report) as record, \
                 contextlib.redirect_stdout(output):
                status = main(["--project-root", str(root), "record-video",
                               "--world", "runs/world/scene.xml", "--controller", "learned",
                               "--checkpoint", "runs/checkpoint", "--output-dir", "runs/video"])
            self.assertEqual(record.call_args.kwargs["controller"], "learned")
            self.assertEqual(record.call_args.kwargs["checkpoint_dir"], root/"runs"/"checkpoint")
            return status, json.loads(output.getvalue())

    def test_valid_video_of_failed_task_exits_zero_and_keeps_failed_task_label(self):
        status, summary = self.invoke_recording({"execution_kind": "simulation", "task_success": False,
                                                "execution_error": None,
                                                "video": {"video_status": "executed"}})
        self.assertEqual(status, 0)
        self.assertEqual(summary["exit_status"], 0)
        self.assertEqual(summary["video_status"], "executed")
        self.assertIs(summary["task_success"], False)
        self.assertEqual(summary["status"], "executed")

    def test_encoder_or_camera_failure_exits_two_even_when_task_succeeded(self):
        status, summary = self.invoke_recording({"execution_kind": "simulation", "task_success": True,
                                                "execution_error": None,
                                                "video": {"video_status": "failed"}})
        self.assertEqual(status, 2)
        self.assertEqual(summary["exit_status"], 2)
        self.assertEqual(summary["status"], "failed")
        self.assertEqual(summary["video_status"], "failed")
        self.assertIs(summary["task_success"], True)

    def test_controller_load_execution_error_exits_two(self):
        for video_status in ("failed", "executed"):
            with self.subTest(video_status=video_status):
                status, summary = self.invoke_recording({"execution_kind": "simulation", "task_success": None,
                                                        "execution_error": "checkpoint load failed",
                                                        "video": {"video_status": video_status}})
                self.assertEqual(status, 2)
                self.assertEqual(summary["exit_status"], 2)
                self.assertEqual(summary["status"], "failed")
                self.assertIsNone(summary["task_success"])


if __name__ == "__main__":
    unittest.main()
