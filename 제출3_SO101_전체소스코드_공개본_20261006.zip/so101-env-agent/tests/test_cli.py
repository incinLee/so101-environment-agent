import contextlib
import io
import json
import tempfile
import unittest
import zipfile
from pathlib import Path

from robot_env_agent.cli import main
from robot_env_agent.contracts import JOINT_NAMES
from robot_env_agent.runtime import resolve_output


PROJECT = Path(__file__).resolve().parents[1]


class CliTests(unittest.TestCase):
    def invoke(self, *args):
        with contextlib.redirect_stdout(io.StringIO()):
            return main(list(args))

    def test_warning_only_calibration_is_not_failed(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "calibration.zip"
            data = {name: {"id": index, "drive_mode": 0, "homing_offset": 0,
                           "range_min": 100, "range_max": 103}
                    for index, name in enumerate(JOINT_NAMES, 1)}
            with zipfile.ZipFile(source, "w") as archive:
                archive.writestr("robots/so101_follower/example.json", json.dumps(data))
            status = self.invoke("--project-root", str(root), "inspect", "--archive", "calibration.zip",
                                 "--output", "runs/inspection.json")
            self.assertEqual(status, 0)
            report = json.loads((root / "runs/inspection.json").read_text())
            self.assertEqual(report["summary"]["passed"], 1)
            self.assertGreater(report["summary"]["candidate_warnings"], 0)

    def test_source_directories_cannot_be_output_targets(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            for target in ("configs/profile.json", "local_data/archive.json", "src/code.json"):
                with self.assertRaises(PermissionError):
                    resolve_output(root, target)

    def test_cli_draft_build_and_mock_round_trip(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "profile.json").write_bytes((PROJECT / "configs/robot_profile.draft.json").read_bytes())
            (root / "task.json").write_bytes((PROJECT / "configs/task.draft.json").read_bytes())
            base = ("--project-root", str(root))
            self.assertEqual(self.invoke(*base, "build", "--profile", "profile.json", "--task", "task.json",
                                         "--output", "runs/draft.json"), 0)
            self.assertEqual(self.invoke(*base, "run-mock", "--bundle", "runs/draft.json",
                                         "--output", "runs/mock.json"), 0)
            result = json.loads((root / "runs/mock.json").read_text())
            self.assertEqual(result["execution_kind"], "mock")
            self.assertEqual(result["simulation_status"], "not_run")


if __name__ == "__main__":
    unittest.main()
