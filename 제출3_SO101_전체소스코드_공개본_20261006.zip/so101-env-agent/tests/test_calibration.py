"""Synthetic archive checks; these fixtures contain no physical robot values."""

import json
from pathlib import Path
import stat
import tempfile
import unittest
import zipfile

from robot_env_agent.calibration import (
    CalibrationArchiveError, JOINTS, MAX_UNCOMPRESSED_BYTES, inspect_archive,
)


def synthetic_calibration():
    return {
        joint: {
            "id": index, "drive_mode": 0, "homing_offset": 0,
            "range_min": 100, "range_max": 1000,
        }
        for index, joint in enumerate(JOINTS, start=1)
    }


class CalibrationTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        self.path = Path(temporary.name) / "fixture.zip"

    def write_archive(self, entries):
        with zipfile.ZipFile(self.path, "w", compression=zipfile.ZIP_STORED) as archive:
            for name, content in entries:
                if isinstance(name, str) and "\\" in name:
                    # Preserve a deliberately unsafe raw name; ZipInfo normally
                    # normalizes Windows separators when constructed.
                    raw_info = zipfile.ZipInfo("fixture.json")
                    raw_info.filename = name
                    raw_info.orig_filename = name
                    name = raw_info
                archive.writestr(name, content)
        return self.path

    def test_valid_structure_without_device_selection(self):
        payload = json.dumps(synthetic_calibration())
        report = inspect_archive(self.write_archive([
            ("robots/so101_follower/arm_a.json", payload),
            ("README.txt", "This text is not executed or parsed as configuration."),
        ]))
        self.assertEqual(report["summary"]["passed"], 1)
        self.assertEqual(report["summary"]["followers"], 1)
        self.assertEqual(report["summary"]["ignored_files"], 1)
        self.assertEqual(len(report["source_sha256"]), 64)
        self.assertEqual(report["candidates"][0]["id"], "arm_a")
        self.assertIsNone(report["selected_candidate"])
        self.assertEqual(report["execution_kind"], "static")

    def test_reversed_range_is_failed_candidate(self):
        fixture = synthetic_calibration()
        fixture["elbow_flex"]["range_min"] = 1001
        report = inspect_archive(self.write_archive([("arm.json", json.dumps(fixture))]))
        self.assertEqual(report["summary"]["failed"], 1)
        self.assertTrue(any(issue["code"] == "encoder_range" for issue in report["candidates"][0]["issues"]))

    def test_duplicate_json_keys_are_rejected(self):
        payload = json.dumps(synthetic_calibration()).replace('"id": 1', '"id": 1, "id": 2', 1)
        report = inspect_archive(self.write_archive([("arm.json", payload)]))
        self.assertEqual(report["summary"]["failed"], 1)
        self.assertEqual(report["candidates"][0]["issues"][0]["code"], "duplicate_json_key")

    def test_unsafe_paths_reject_archive(self):
        for name in ("../arm.json", "/arm.json", "folder\\arm.json", "C:/arm.json"):
            with self.subTest(name=name):
                self.write_archive([(name, "{}")])
                with self.assertRaises(CalibrationArchiveError):
                    inspect_archive(self.path)

    def test_uncompressed_budget_includes_ignored_files(self):
        self.write_archive([("image.png", b"x" * (MAX_UNCOMPRESSED_BYTES + 1))])
        with self.assertRaises(CalibrationArchiveError):
            inspect_archive(self.path)

    def test_duplicate_contents_remain_unselected(self):
        payload = json.dumps(synthetic_calibration())
        report = inspect_archive(self.write_archive([
            ("robots/so101_follower/arm_a.json", payload),
            ("robots/so_follower/arm_a.json", payload),
        ]))
        self.assertEqual(report["summary"]["passed"], 2)
        self.assertEqual(len(report["duplicate_groups"]), 1)
        self.assertEqual(len(report["duplicate_groups"][0]["paths"]), 2)
        self.assertIsNone(report["selected_candidate"])

    def test_narrow_range_is_warning_only(self):
        fixture = synthetic_calibration()
        fixture["gripper"]["range_max"] = 102
        report = inspect_archive(self.write_archive([("arm.json", json.dumps(fixture))]))
        self.assertEqual(report["summary"]["passed"], 1)
        self.assertEqual(report["summary"]["candidate_warnings"], 1)

    def test_bool_is_not_an_integer_calibration_field(self):
        fixture = synthetic_calibration()
        fixture["gripper"]["drive_mode"] = True
        report = inspect_archive(self.write_archive([("arm.json", json.dumps(fixture))]))
        self.assertEqual(report["summary"]["failed"], 1)

    def test_direction_bit_one_is_structurally_accepted(self):
        fixture = synthetic_calibration()
        fixture["wrist_roll"]["drive_mode"] = 1
        report = inspect_archive(self.write_archive([("arm.json", json.dumps(fixture))]))
        self.assertEqual(report["summary"]["passed"], 1)

    def test_encrypted_flag_rejects_archive(self):
        self.write_archive([("arm.json", json.dumps(synthetic_calibration()))])
        raw = bytearray(self.path.read_bytes())
        raw[6] |= 1  # General-purpose bit flag in the local file header.
        central = raw.index(b"PK\x01\x02")
        raw[central + 8] |= 1
        self.path.write_bytes(raw)
        with self.assertRaises(CalibrationArchiveError):
            inspect_archive(self.path)

    def test_symlink_rejects_archive(self):
        link = zipfile.ZipInfo("link.json")
        link.create_system = 3
        link.external_attr = (stat.S_IFLNK | 0o777) << 16
        self.write_archive([(link, "elsewhere")])
        with self.assertRaises(CalibrationArchiveError):
            inspect_archive(self.path)

    def test_crc_failure_rejects_archive(self):
        payload = json.dumps(synthetic_calibration()).encode()
        self.write_archive([("arm.json", payload)])
        raw = bytearray(self.path.read_bytes())
        payload_offset = raw.index(payload)
        raw[payload_offset] ^= 1
        self.path.write_bytes(raw)
        with self.assertRaises(CalibrationArchiveError):
            inspect_archive(self.path)

    def test_conflicting_versions_are_reported(self):
        original = json.dumps(synthetic_calibration())
        changed = synthetic_calibration()
        changed["gripper"]["homing_offset"] = 1
        report = inspect_archive(self.write_archive([
            ("robots/so101_follower/arm_a.json", original),
            ("robots/so_follower/arm_a.json", json.dumps(changed)),
        ]))
        self.assertTrue(any(warning["code"] == "conflicting_id" for warning in report["warnings"]))
        self.assertIsNone(report["selected_candidate"])


if __name__ == "__main__":
    unittest.main()
