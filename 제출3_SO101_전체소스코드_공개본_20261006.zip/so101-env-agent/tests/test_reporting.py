import base64
import json
import tempfile
import unittest
from html.parser import HTMLParser
from pathlib import Path

from robot_env_agent.reporting import write_dashboard

ONE_PIXEL_PNG = base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+j3ZkAAAAASUVORK5CYII=')


class DashboardParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.tags = []
    def handle_starttag(self, tag, attrs):
        self.tags.append((tag, dict(attrs)))


class ReportingTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.run = self.root / 'run'
        self.run.mkdir()
        self.report = {'execution_kind': 'simulation', 'intent_result': {'intent': 'tray_transfer', 'confidence': 0.95},
                       'model_report': {'execution_kind': 'synthetic', 'evaluation_accuracy': 1.0, 'evaluation_examples': 16},
                       'scene_assumptions': {'measured': False}, 'baseline': {'episodes': [], 'successes': 0, 'trials': 1},
                       'training': {'execution_kind': 'simulation', 'backend': 'torch_tiny_chunk_transformer'},
                       'policy_evaluation': {'task_success': 'not_evaluated'}, 'response_fit': {'execution_kind': 'synthetic'},
                       'trace': [{'tool': 'build_environment', 'status': 'passed'}],
                       'limitations': ['실기 미검증'], 'physical_execution': 'not_run', 'image_paths': []}

    def test_self_contained_dashboard_with_actual_png(self):
        (self.run / 'frame.png').write_bytes(ONE_PIXEL_PNG)
        self.report['image_paths'] = ['frame.png']
        path = write_dashboard(self.run / 'dashboard.html', self.report)
        text = path.read_text(encoding='utf-8')
        self.assertIn('data:image/png;base64,', text)
        self.assertIn('실기 미검증', text)
        self.assertIn('0 / 1', text)
        self.assertIn('합성', text)
        parser = DashboardParser()
        parser.feed(text)
        images = [attrs['src'] for tag, attrs in parser.tags if tag == 'img']
        self.assertEqual(base64.b64decode(images[0].split(',', 1)[1]), ONE_PIXEL_PNG)
        self.assertFalse(any(tag == 'script' and 'src' in attrs for tag, attrs in parser.tags))
        self.assertFalse(any(tag == 'link' for tag, _ in parser.tags))

    def test_html_and_json_script_injection_is_inert(self):
        payload = '</script><script>alert(1)</script><img src=x onerror=alert(2)>'
        self.report['limitations'] = [payload]
        self.report['trace'][0]['tool'] = payload
        self.report['scene_assumptions']['unsafe_text'] = payload
        text = write_dashboard(self.run / 'dashboard.html', self.report).read_text(encoding='utf-8')
        parser = DashboardParser()
        parser.feed(text)
        scripts = [attrs for tag, attrs in parser.tags if tag == 'script']
        self.assertEqual(len(scripts), 1)
        self.assertEqual(scripts[0].get('type'), 'application/json')
        self.assertFalse(any('onerror' in attrs for _, attrs in parser.tags))
        self.assertIn('&lt;img', text)
        embedded = text.split('<script type="application/json" id="report-data">', 1)[1].split('</script>', 1)[0]
        self.assertNotIn('<', embedded)
        self.assertEqual(json.loads(embedded)['limitations'][0], payload)

    def test_image_path_cannot_escape_run_directory(self):
        (self.root / 'outside.png').write_bytes(ONE_PIXEL_PNG)
        self.report['image_paths'] = ['../outside.png']
        with self.assertRaisesRegex(ValueError, 'inside this run'):
            write_dashboard(self.run / 'dashboard.html', self.report)
        self.assertFalse((self.run / 'dashboard.html').exists())

    def test_active_image_formats_and_fake_png_are_rejected(self):
        (self.run / 'unsafe.svg').write_text('<svg onload="alert(1)"></svg>', encoding='utf-8')
        self.report['image_paths'] = ['unsafe.svg']
        with self.assertRaises(ValueError):
            write_dashboard(self.run / 'dashboard.html', self.report)
        (self.run / 'fake.png').write_text('<script>alert(1)</script>', encoding='utf-8')
        self.report['image_paths'] = ['fake.png']
        with self.assertRaisesRegex(ValueError, 'PNG signature'):
            write_dashboard(self.run / 'dashboard.html', self.report)

    def test_frame_count_is_bounded_to_eight(self):
        for index in range(10):
            (self.run / f'frame-{index}.png').write_bytes(ONE_PIXEL_PNG)
        self.report['image_paths'] = [f'frame-{index}.png' for index in range(10)]
        parser = DashboardParser()
        parser.feed(write_dashboard(self.run / 'dashboard.html', self.report).read_text(encoding='utf-8'))
        self.assertEqual(sum(tag == 'img' for tag, _ in parser.tags), 8)

    def test_nonfinite_metrics_and_invalid_output_are_rejected(self):
        self.report['training']['loss'] = float('nan')
        with self.assertRaises(ValueError):
            write_dashboard(self.run / 'dashboard.html', self.report)
        with self.assertRaises(ValueError):
            write_dashboard(self.run / 'source.py', {})

    def test_learned_task_failure_is_distinct_from_baseline_and_offline_error(self):
        self.report['baseline'].update(successes=1, trials=1)
        self.report['policy_evaluation'] = {'successes': 0, 'trials': 2, 'closed_loop': [],
                                           'offline_test': {'mae': 0.04385, 'metric_unit': 'rad', 'execution_kind': 'simulation'}}
        text = write_dashboard(self.run / 'dashboard.html', self.report).read_text(encoding='utf-8')
        self.assertIn('1 / 1', text)
        self.assertIn('0 / 2', text)
        self.assertIn('학습 정책 폐루프', text)
        self.assertIn('오프라인 행동 MAE', text)
        self.assertIn('0.04385', text)

    def test_parallel_collection_evidence_is_separate_and_frame_count_is_bounded(self):
        episodes = []
        for seed in range(9):
            directory = self.run / 'baseline' / f'seed-{seed}'
            directory.mkdir(parents=True)
            (directory / 'camera_hold.png').write_bytes(ONE_PIXEL_PNG)
            episodes.append({'evidence_directory': f'baseline/seed-{seed}'})
        self.report['baseline']['episodes'] = episodes
        self.report['parallel_collection'] = {'execution_kind': 'simulation', 'requested_workers': 8,
                                              'effective_workers': 8, 'max_concurrent_observed': 8}
        text = write_dashboard(self.run / 'dashboard.html', self.report).read_text(encoding='utf-8')
        parser = DashboardParser()
        parser.feed(text)
        self.assertEqual(sum(tag == 'img' for tag, _ in parser.tags), 8)
        self.assertIn('관측한 최대 동시 실행 8개', text)
        self.assertIn('신경망 학습 배치 크기와 다릅니다', text)
        self.assertIn('기준 제어의 시연 수집', text)

    def test_parallel_frame_path_cannot_escape_run(self):
        self.report['parallel_collection'] = {'requested_workers': 8}
        self.report['baseline']['episodes'] = [{'evidence_directory': '../outside'}]
        with self.assertRaisesRegex(ValueError, 'inside this run'):
            write_dashboard(self.run / 'dashboard.html', self.report)


if __name__ == '__main__':
    unittest.main()
