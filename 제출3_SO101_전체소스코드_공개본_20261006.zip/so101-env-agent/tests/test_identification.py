import json
import tempfile
import unittest
from pathlib import Path

from robot_env_agent.identification import compare_and_fit, create_synthetic_response_log


class IdentificationTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.log = create_synthetic_response_log(self.root / "response.json")

    def rewrite(self, mutate):
        data = json.loads(self.log.read_text(encoding="utf-8"))
        mutate(data)
        self.log.write_text(json.dumps(data), encoding="utf-8")

    def test_transmitted_command_fitted_with_independent_holdout(self):
        report = compare_and_fit(self.log, self.root / "fit")
        self.assertAlmostEqual(report["model"]["gain"], 1.12, places=5)
        self.assertAlmostEqual(report["model"]["delay_s"], 0.06, places=5)
        self.assertLess(report["holdout_after"]["mse"], report["holdout_before"]["mse"])
        self.assertFalse(report["holdout_used_for_fitting"])
        self.assertFalse(report["requested_target_used_for_fitting"])
        self.assertFalse(report["hardware_write_performed"])
        self.assertFalse(report["real_calibration_verified"])
        self.assertEqual(report["physical_status"], "not_run")
        self.assertEqual(report["execution_kind"], "synthetic")
        self.assertTrue((self.root / "fit" / "fitted_parameters.json").exists())

    def test_holdout_changes_do_not_change_fit(self):
        original = compare_and_fit(self.log, self.root / "fit1")
        def mutate(data):
            for row in data["sessions"]:
                if row["split"] == "holdout":
                    # An independent session now follows the unfitted baseline exactly.
                    # A fixed train fit should keep its parameters and report no improvement.
                    row["measured_state"] = list(row["transmitted_command"])
        self.rewrite(mutate)
        changed = compare_and_fit(self.log, self.root / "fit2")
        self.assertEqual(original["model"]["gain"], changed["model"]["gain"])
        self.assertEqual(original["model"]["delay_s"], changed["model"]["delay_s"])
        self.assertFalse(changed["holdout_improved"])

    def test_duplicate_session_ids_block_leakage(self):
        self.rewrite(lambda data: data["sessions"][2].update(session_id=data["sessions"][0]["session_id"]))
        with self.assertRaisesRegex(ValueError, "disjoint"):
            compare_and_fit(self.log, self.root / "fit")

    def test_missing_actual_transmission_is_not_replaced_by_target(self):
        self.rewrite(lambda data: data["sessions"][0].pop("transmitted_command"))
        with self.assertRaisesRegex(ValueError, "transmitted_command"):
            compare_and_fit(self.log, self.root / "fit")

    def test_unknown_or_mismatched_units_block_identification(self):
        self.rewrite(lambda data: data.update(command_unit=None))
        with self.assertRaisesRegex(ValueError, "units"):
            compare_and_fit(self.log, self.root / "fit")
        create_synthetic_response_log(self.log)
        self.rewrite(lambda data: data.update(measured_state_unit="deg"))
        with self.assertRaisesRegex(ValueError, "units"):
            compare_and_fit(self.log, self.root / "fit")

    def test_unexcited_command_is_not_identifiable(self):
        def mutate(data):
            for row in data["sessions"]:
                row["transmitted_command"] = [0.1] * len(row["timestamps_s"])
        self.rewrite(mutate)
        with self.assertRaisesRegex(ValueError, "not identifiable"):
            compare_and_fit(self.log, self.root / "fit")

    def test_nonfinite_or_clock_mismatch_blocks_fit(self):
        self.rewrite(lambda data: data["sessions"][0]["measured_state"].__setitem__(0, float("nan")))
        with self.assertRaisesRegex(ValueError, "nonfinite"):
            compare_and_fit(self.log, self.root / "fit")
        create_synthetic_response_log(self.log)
        self.rewrite(lambda data: data["sessions"][0].update(clock_domain="other_clock"))
        with self.assertRaisesRegex(ValueError, "clock"):
            compare_and_fit(self.log, self.root / "fit")

    def test_real_recorded_fit_is_not_hardware_validation(self):
        self.rewrite(lambda data: data.update(execution_kind="real_recorded"))
        report = compare_and_fit(self.log, self.root / "fit")
        self.assertTrue(report["recorded_real_fit_completed"])
        self.assertFalse(report["real_calibration_verified"])
        self.assertEqual(report["physical_status"], "not_run")

    def test_fit_does_not_replace_its_input_log(self):
        source = create_synthetic_response_log(self.root / "identification_report.json")
        with self.assertRaisesRegex(ValueError, "overwrite"):
            compare_and_fit(source, self.root)
        self.assertIn("sessions", json.loads(source.read_text(encoding="utf-8")))


if __name__ == "__main__":
    unittest.main()
