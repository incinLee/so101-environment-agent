"""Ordering, bounded inputs, independent spawn and honest failure collection."""
import contextlib
import io
import json
import os
from pathlib import Path
import runpy
import tempfile
import unittest
from unittest.mock import patch

from robot_env_agent.cli import main
from robot_env_agent.parallel import collect_parallel_baselines, validate_workers, _maximum_overlap, _atomic_json


def _abrupt_exit_fixture(*args):
    os._exit(7)


class ParallelCollectionTests(unittest.TestCase):
    def test_windows_snapshot_reader_lock_retries_then_replaces_complete_json(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "parallel_progress.json"
            path.write_text('{"completed": 0}', encoding="utf-8")
            original_replace = os.replace
            calls = []

            def replace(source, target):
                calls.append((source, target))
                if len(calls) == 1:
                    locked = PermissionError("brief Windows reader lock")
                    locked.winerror = 5
                    raise locked
                original_replace(source, target)

            with patch("robot_env_agent.parallel.os.replace", side_effect=replace), \
                 patch("robot_env_agent.parallel.time.sleep") as pause:
                _atomic_json(path, {"completed": 9, "slots": []})
            self.assertEqual(len(calls), 2)
            pause.assert_called_once_with(0.01)
            self.assertEqual(json.loads(path.read_text(encoding="utf-8")), {"completed": 9, "slots": []})
            self.assertFalse(path.with_name(path.name + ".tmp").exists())

    def test_persistent_windows_lock_and_unrelated_permission_failure_are_not_swallowed(self):
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "parallel_progress.json"
            for winerror, attempts, sleeps in ((32, 50, 49), (33, 50, 49), (None, 1, 0), (87, 1, 0)):
                failure = PermissionError("fixture permissions failure")
                if winerror is not None:
                    failure.winerror = winerror
                with self.subTest(winerror=winerror), \
                     patch("robot_env_agent.parallel.os.replace", side_effect=failure) as replacement, \
                     patch("robot_env_agent.parallel.time.sleep") as pause, \
                     self.assertRaises(PermissionError):
                    _atomic_json(path, {"completed": 0})
                self.assertEqual(replacement.call_count, attempts)
                self.assertEqual(pause.call_count, sleeps)

    def test_workers_and_seeds_fail_before_output_creation(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            for workers in (0, 9, -1, True, 2.0, "8", None):
                with self.subTest(workers=workers), self.assertRaises(ValueError):
                    collect_parallel_baselines(root / "missing.xml", root / "out", [0], workers=workers)
                self.assertFalse((root / "out").exists())
            for seeds in ([], [0, 0], list(range(10)), [True], [-1], [2**32], [{}]):
                with self.subTest(seeds=seeds), self.assertRaises(ValueError):
                    collect_parallel_baselines(root / "missing.xml", root / "out", seeds, workers=1)
                self.assertFalse((root / "out").exists())
        self.assertEqual(validate_workers(8), 8)

    def test_sequential_order_failure_and_partial_evidence_are_retained(self):
        def simulation(world, output_dir, *, seed):
            (output_dir / "partial.txt").write_text(f"seed={seed}", encoding="utf-8")
            if seed == 0:
                raise RuntimeError("fixture simulator interruption")
            return {"seed": seed, "task_success": seed != 5, "camera_frames": []}

        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            with patch("robot_env_agent.simulation.run_simulation", side_effect=simulation):
                episodes, metadata = collect_parallel_baselines(root / "scene.xml", root / "baseline",
                                                                [8, 0, 5], workers=1)
            self.assertEqual([row["seed"] for row in episodes], [8, 0, 5])
            self.assertEqual([row["task_success"] for row in episodes], [True, False, False])
            self.assertEqual(metadata["unique_worker_pids"], [os.getpid()])
            self.assertEqual(metadata["max_concurrent_observed"], 1)
            self.assertEqual(metadata["mode"], "sequential")
            self.assertEqual(metadata["episodes"], 3)
            self.assertIn("fixture simulator interruption", episodes[1]["execution_error"])
            self.assertEqual((root / "baseline/seed-0/partial.txt").read_text(), "seed=0")
            self.assertTrue((root / "baseline/seed-0/parallel_failure.json").exists())
            progress = json.loads((root / "baseline/parallel_progress.json").read_text(encoding="utf-8"))
            self.assertEqual(progress["completed"], 3)
            self.assertEqual(progress["status"], "completed_with_failures")
            self.assertEqual(progress["slots"][0]["seed"], 5)
            for row in episodes:
                execution = row["parallel_execution"]
                self.assertLessEqual(execution["started_at_unix_s"], execution["ended_at_unix_s"])
                self.assertEqual(row["evidence_directory"], f"baseline/seed-{row['seed']}")
            with self.assertRaisesRegex(ValueError, "already exists"):
                collect_parallel_baselines(root / "scene.xml", root / "baseline", [8, 0, 5])

    def test_requested_eight_workers_one_episode_runs_one_environment(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            with patch("robot_env_agent.simulation.run_simulation",
                       return_value={"seed": 0, "task_success": True, "camera_frames": []}):
                episodes, metadata = collect_parallel_baselines(root / "scene.xml", root / "baseline", [0], workers=8)
            self.assertEqual(len(episodes), 1)
            self.assertEqual(metadata["requested_workers"], 8)
            self.assertEqual(metadata["effective_workers"], 1)
            self.assertEqual(metadata["max_concurrent_observed"], 1)

    def test_real_spawn_uses_distinct_child_processes_and_preserves_load_failures(self):
        # Genuine spawn processes and their filesystem evidence are checked;
        # missing XML intentionally makes this a failure-path test, not physics.
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            episodes, metadata = collect_parallel_baselines(root / "missing.xml", root / "baseline",
                                                            [2, 0, 1], workers=2)
            self.assertEqual([row["seed"] for row in episodes], [2, 0, 1])
            self.assertEqual(len(metadata["unique_worker_pids"]), 2)
            self.assertNotIn(os.getpid(), metadata["unique_worker_pids"])
            self.assertTrue(all(row["task_success"] is False for row in episodes))
            self.assertTrue(all("FileNotFoundError" in row["execution_error"] for row in episodes))
            self.assertEqual(episodes[0]["parallel_execution"]["pid"], episodes[2]["parallel_execution"]["pid"])
            self.assertNotEqual(episodes[0]["parallel_execution"]["pid"], episodes[1]["parallel_execution"]["pid"])
            self.assertEqual(metadata["mode"], "spawn_processes")
            self.assertLessEqual(metadata["max_concurrent_observed"], 2)
            progress = json.loads((root / "baseline/parallel_progress.json").read_text(encoding="utf-8"))
            self.assertEqual(progress["completed"], 3)
            self.assertEqual([row["slot"] for row in progress["slots"]], [0, 1])
            self.assertTrue(all((root / row["evidence_directory"] / "parallel_failure.json").exists()
                                for row in episodes))

    def test_concurrency_uses_timestamps_not_number_of_pids(self):
        episodes = [{"parallel_execution": {"started_at_unix_s": begin, "ended_at_unix_s": end}}
                    for begin, end in ((1, 4), (2, 5), (3, 6), (7, 8))]
        self.assertEqual(_maximum_overlap(episodes), 3)
        adjacent = [{"parallel_execution": {"started_at_unix_s": begin, "ended_at_unix_s": end}}
                    for begin, end in ((1, 2), (2, 3))]
        self.assertEqual(_maximum_overlap(adjacent), 1)

    def test_abrupt_worker_exit_keeps_every_scheduled_episode_as_failure(self):
        # Actual process exits without sending any event, exercising parent
        # recovery rather than the worker's normal Python exception handler.
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            with patch("robot_env_agent.parallel._run_slot", _abrupt_exit_fixture):
                episodes, metadata = collect_parallel_baselines(root / "scene.xml", root / "baseline",
                                                                [0, 1, 2], workers=2)
            self.assertEqual(len(episodes), 3)
            self.assertEqual([row["seed"] for row in episodes], [0, 1, 2])
            self.assertTrue(all(row["task_success"] is False for row in episodes))
            self.assertTrue(all("code 7" in row["execution_error"] for row in episodes))
            self.assertEqual(metadata["max_concurrent_observed"], 0)
            self.assertEqual(len(metadata["unique_worker_pids"]), 2)
            self.assertTrue(all((root / row["evidence_directory"] / "parallel_failure.json").exists()
                                for row in episodes))

    def test_nine_collected_episodes_still_split_five_two_two(self):
        import numpy as np
        from robot_env_agent.learning import load_chunk_dataset
        from robot_env_agent.workflow import aggregate_demonstrations

        contract = {"schema_version": 1, "data_kind": "simulation", "label_source": "scripted_controller",
                    "action_unit": "rad", "action_semantics": "absolute_joint_position", "time_unit": "s",
                    "clock_domain": "simulation_episode_time", "observation_names": ["q"],
                    "action_names": ["q"], "split": "unassigned"}

        def simulation(world, output_dir, *, seed):
            np.savez(output_dir / "demonstration.npz", observations=np.full((6, 1), seed),
                     actions=np.full((6, 1), seed), timestamps_s=np.arange(6) * 0.034,
                     metadata_json=np.asarray(json.dumps(contract)))
            return {"seed": seed, "task_success": True, "camera_frames": []}

        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            with patch("robot_env_agent.simulation.run_simulation", side_effect=simulation):
                episodes, metadata = collect_parallel_baselines(root / "scene.xml", root / "baseline", range(9))
            report = aggregate_demonstrations([root / row["evidence_directory"] / "demonstration.npz"
                                               for row in episodes], root / "dataset.npz")
            data = load_chunk_dataset(root / "dataset.npz")
            self.assertEqual(metadata["episodes"], 9)
            self.assertEqual((report["train_episodes"], report["validation_episodes"], report["test_episodes"]), (5, 2, 2))
            self.assertEqual(set(data["episode_ids"][data["splits"] == "train"]), {f"seed-{seed}" for seed in range(5)})
            self.assertEqual(set(data["episode_ids"][data["splits"] == "test"]), {"seed-7", "seed-8"})

    def test_cli_workers_propagate_and_default_stays_sequential(self):
        for extra, expected in (([], 1), (["--workers", "8"], 8)):
            with self.subTest(expected=expected), tempfile.TemporaryDirectory() as temporary:
                root = Path(temporary)
                (root / "scene.json").write_text("{}", encoding="utf-8")
                with patch("robot_env_agent.workflow.run_workflow", return_value={"status": "passed"}) as workflow, \
                     contextlib.redirect_stdout(io.StringIO()):
                    status = main(["--project-root", str(root), "agent", "--scene", "scene.json",
                                   "--output-dir", "runs/test", *extra])
                self.assertEqual(status, 0)
                self.assertEqual(workflow.call_args.kwargs["workers"], expected)

    def test_spawn_import_does_not_execute_main(self):
        with patch("robot_env_agent.cli.main") as entry:
            runpy.run_module("robot_env_agent.__main__", run_name="spawn_import_fixture")
        entry.assert_not_called()


if __name__ == "__main__":
    unittest.main()
