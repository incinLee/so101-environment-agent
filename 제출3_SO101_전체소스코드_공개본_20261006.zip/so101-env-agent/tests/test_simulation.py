"""Meaningful task-contract and real-physics checks; no motor interfaces."""
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from robot_env_agent.simulation import (ASSET_ROOT, DEFAULT_SCENE, MuJoCoBackend, build_world,
                                        _gripper_part_contacts, _ik, _inside_target, _released_inside_target,
                                        collect_simulation_response_log, evaluate_policy_in_simulation,
                                        run_simulation, validate_scene)


class SceneContractTests(unittest.TestCase):
    def test_defaults_are_explicit_assumptions(self):
        resolved = validate_scene({})
        self.assertEqual(resolved["task_id"], "tray_transfer")
        self.assertEqual(resolved["object_size_m"], [0.03]*3)
        self.assertEqual(DEFAULT_SCENE["object_size_m"], [0.03]*3)

    def test_invalid_or_unknown_geometry_is_rejected(self):
        for override in ({"object_size_m": None}, {"object_mass_kg": True}, {"timestep_s": 10**1000},
                         {"source_center_m": [0, float("nan")]}, {"target_center_m": [0.20, -0.07]},
                         {"robot_port": "port"}, {"object_size_m": [0.2, 0.03, 0.03]},
                         {"target_center_m": [0.49, 0.07]}, {"control_hz": 1, "timestep_s": 0.001}):
            with self.subTest(override=override), self.assertRaises((ValueError, OverflowError)):
                validate_scene(override)


@unittest.skipUnless(importlib.util.find_spec("mujoco") and (ASSET_ROOT/"provenance.json").exists(),
                     "isolated MuJoCo dependencies and verified public model required")
class PhysicsTests(unittest.TestCase):
    def test_build_reset_step_and_gravity_without_forced_grasp(self):
        with tempfile.TemporaryDirectory() as directory:
            result = build_world(Path(directory)/"world", {})
            self.assertFalse(result["real_robot_match_verified"])
            self.assertEqual(result["physical_status"], "not_run")
            backend = MuJoCoBackend(Path(result["world_path"]))
            reset = backend.reset()
            # Raise only the free part during TEST initialization, then verify gravity/contact.
            part_joint = backend.mujoco.mj_name2id(backend.model, backend.mujoco.mjtObj.mjOBJ_JOINT, "part_free")
            address = backend.model.jnt_qposadr[part_joint]
            backend.data.qpos[address+2] = 0.10
            backend.mujoco.mj_forward(backend.model, backend.data)
            for _ in range(10):
                observed = backend.step(reset["joint_position_rad"], 20)
            self.assertGreater(observed["timestamp_s"], 0)
            self.assertLess(observed["part_position_m"][2], 0.04)
            self.assertGreater(observed["contacts_count"], 0)
            self.assertEqual(backend.model.neq, 0, "model must not use hidden weld/equality grasps")

    def test_asset_and_control_integrity(self):
        with tempfile.TemporaryDirectory() as directory:
            result = build_world(Path(directory)/"world", {})
            backend = MuJoCoBackend(Path(result["world_path"]))
            backend.reset()
            with self.assertRaises(ValueError):
                backend.step([100]*6)
            with self.assertRaises(ValueError):
                backend.step([0]*5)
            with self.assertRaises(ValueError):
                build_world(Path(directory)/"world", {})
            manifest = json.loads(Path(result["manifest_path"]).read_text(encoding="utf-8"))
            self.assertEqual(manifest["measurement_source"], "simulation_assumptions")
            self.assertTrue((Path(directory)/"world"/"robot"/"LICENSE").exists())

    def test_scripted_contact_transfer_and_camera_evidence(self):
        with tempfile.TemporaryDirectory() as directory:
            result = build_world(Path(directory)/"world", {})
            report = run_simulation(Path(result["world_path"]), Path(directory)/"evidence", seed=1)
            self.assertTrue(report["task_success"], report["failure_reason"])
            self.assertGreater(report["gripper_part_contact_samples"], 0)
            self.assertGreater(report["max_part_height_m"], 0.05)
            self.assertEqual(report["physical_status"], "not_run")
            self.assertFalse(report["ai_policy_used"])
            self.assertFalse(report["evaluation"]["forced_grasp"])
            self.assertFalse(report["evaluation"]["teleportation_after_reset"])
            self.assertTrue(report["evaluation"]["final_released_inside_target"])
            self.assertEqual(report["evaluation"]["gripper_open_threshold_rad"], 0.5)
            records = [json.loads(row) for row in (Path(directory)/"evidence"/"joint_trace.jsonl").read_text().splitlines()]
            self.assertGreaterEqual(records[-1]["consecutive_release_hold_s"], 1.0)
            self.assertTrue(records[-1]["released"])
            self.assertEqual(records[-1]["gripper_part_contacts"], 0)
            if report["camera_status"] == "executed":
                self.assertGreaterEqual(len(report["camera_frames"]), 4)
                first = Path(directory)/"evidence"/report["camera_frames"][0]["path"]
                self.assertEqual(first.read_bytes()[:8], b"\x89PNG\r\n\x1a\n")
            else:
                self.assertTrue(report["camera_error"], "render failures must remain explicit")
            import numpy as np
            with np.load(Path(directory)/"evidence"/"demonstration.npz", allow_pickle=False) as dataset:
                self.assertEqual(dataset["observations"].shape[1], 12)
                self.assertEqual(dataset["actions"].shape[1], 6)
                self.assertTrue((np.diff(dataset["timestamps_s"]) > 0).all())
                metadata = json.loads(str(dataset["metadata_json"]))
                self.assertEqual(metadata["label_source"], "scripted_controller")

    def test_unreachable_layout_is_a_failed_task_not_a_forced_success(self):
        with tempfile.TemporaryDirectory() as directory:
            result = build_world(Path(directory)/"world", {"source_center_m": [0.38, -0.07],
                                                          "target_center_m": [0.38, 0.07]})
            report = run_simulation(Path(result["world_path"]), Path(directory)/"evidence", seed=2)
            self.assertFalse(report["task_success"])
            self.assertIsNotNone(report["failure_reason"])
            self.assertEqual(report["simulation_status"], "executed")
            self.assertFalse(report["evaluation"]["final_object_fully_inside_target_and_settled"])

    def test_changed_copied_assets_are_rejected_before_execution(self):
        with tempfile.TemporaryDirectory() as directory:
            result = build_world(Path(directory)/"world", {})
            original = Path(directory)/"world"/"robot"/"so101.xml"
            original.write_text(original.read_text(encoding="utf-8")+"\n", encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "asset hash mismatch"):
                run_simulation(Path(result["world_path"]), Path(directory)/"evidence")

    def test_inside_target_with_closed_gripper_does_not_count_as_released(self):
        with tempfile.TemporaryDirectory() as directory:
            result = build_world(Path(directory)/"world", {})
            backend = MuJoCoBackend(Path(result["world_path"]))
            backend.reset()
            mj = backend.mujoco
            part_joint = mj.mj_name2id(backend.model, mj.mjtObj.mjOBJ_JOINT, "part_free")
            part_address = backend.model.jnt_qposadr[part_joint]
            # Rule-validation initial state, not a recorded transfer trajectory.
            backend.data.qpos[part_address:part_address+3] = [0.20, 0.07, 0.018]
            backend.data.qpos[backend.addresses[-1]] = 0.0
            mj.mj_forward(backend.model, backend.data)
            self.assertTrue(_inside_target(backend, DEFAULT_SCENE))
            self.assertFalse(_released_inside_target(backend, DEFAULT_SCENE))
            backend.data.qpos[backend.addresses[-1]] = 0.9
            mj.mj_forward(backend.model, backend.data)
            self.assertEqual(_gripper_part_contacts(backend), 0)
            self.assertTrue(_released_inside_target(backend, DEFAULT_SCENE))

    def test_open_gripper_contacting_inside_part_does_not_count_as_released(self):
        with tempfile.TemporaryDirectory() as directory:
            result = build_world(Path(directory)/"world", {})
            backend = MuJoCoBackend(Path(result["world_path"]))
            backend.reset()
            mj = backend.mujoco
            q, error = _ik(backend, [0.20, 0.07, 0.018], backend.data.qpos[backend.addresses].copy(),
                            mj.MjData(backend.model), iterations=120)
            self.assertLess(error, 0.002)
            q[-1] = 0.9
            backend.data.qpos[backend.addresses] = q
            mj.mj_forward(backend.model, backend.data)
            fingertip = mj.mj_name2id(backend.model, mj.mjtObj.mjOBJ_GEOM, "fixed_jaw_sph_tip1")
            position = backend.data.geom_xpos[fingertip].copy()
            part_joint = mj.mj_name2id(backend.model, mj.mjtObj.mjOBJ_JOINT, "part_free")
            part_address = backend.model.jnt_qposadr[part_joint]
            # A geometric contact fixture checks release independently of jaw opening.
            backend.data.qpos[part_address:part_address+3] = [position[0], position[1], 0.018]
            mj.mj_forward(backend.model, backend.data)
            self.assertTrue(_inside_target(backend, DEFAULT_SCENE))
            self.assertGreater(_gripper_part_contacts(backend), 0)
            self.assertGreaterEqual(backend.data.qpos[backend.addresses[-1]], 0.5)
            self.assertFalse(_released_inside_target(backend, DEFAULT_SCENE))


@unittest.skipUnless(importlib.util.find_spec("mujoco") and (ASSET_ROOT/"provenance.json").exists(),
                     "isolated MuJoCo dependencies and verified public model required")
class LearnedAndResponsePhysicsTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import numpy as np
        from robot_env_agent.learning import train_chunk_policy, write_chunk_dataset
        cls.temporary = tempfile.TemporaryDirectory()
        cls.root = Path(cls.temporary.name)
        cls.world = Path(build_world(cls.root/"world", {})["world_path"])
        observations, actions, ids, splits, timestamps = [], [], [], [], []
        for episode, split in enumerate(("train", "validation", "test")):
            directory = cls.root/f"demonstration_{episode}"
            run_simulation(cls.world, directory, seed=episode)
            with np.load(directory/"demonstration.npz", allow_pickle=False) as raw:
                observations.extend(raw["observations"].tolist())
                actions.extend(raw["actions"].tolist())
                timestamps.extend(raw["timestamps_s"].tolist())
                ids.extend([f"episode-{episode}"]*len(raw["actions"]))
                splits.extend([split]*len(raw["actions"]))
                metadata = json.loads(str(raw["metadata_json"]))
        dataset = write_chunk_dataset(cls.root/"dataset.npz", observations=observations, actions=actions,
                                     episode_ids=ids, splits=splits, timestamps_s=timestamps, metadata=metadata)
        cls.checkpoint = cls.root/"policy"
        train_chunk_policy(dataset, cls.checkpoint, backend="numpy", chunk_size=4)

    @classmethod
    def tearDownClass(cls):
        cls.temporary.cleanup()

    def test_real_learned_closed_loop_has_no_script_fallback_and_updates_observation(self):
        with tempfile.TemporaryDirectory() as directory:
            # This real trained ridge policy can fail the task; that does not justify an oracle fallback.
            with patch("robot_env_agent.simulation._ik", side_effect=AssertionError("IK leakage")):
                report = evaluate_policy_in_simulation(self.world, self.checkpoint, Path(directory),
                                                       seed=123, episode_seconds=1.0)
            self.assertEqual(report["simulation_status"], "executed")
            self.assertTrue(report["ai_policy_used"])
            self.assertFalse(report["scripted_actions_used"])
            self.assertFalse(report["demonstration_labels_read_during_execution"])
            self.assertEqual(report["policy_prediction_calls"], report["control_steps"])
            self.assertEqual(report["action_chunk_consumption"], "first_action_receding_horizon")
            records = [json.loads(row) for row in (Path(directory)/"policy_trace.jsonl").read_text().splitlines()]
            self.assertGreater(len(records), 2)
            self.assertEqual(records[1]["observation_before"][:6], records[0]["joint_position_rad"])
            self.assertNotEqual(records[0]["observation_before"][:6], records[1]["observation_before"][:6])
            for row in records:
                self.assertEqual(len(row["requested_action_rad"]), 6)
                self.assertEqual(len(row["transmitted_command_rad"]), 6)
                self.assertTrue(row["timestamp_s"] > row["observation_timestamp_s"])
            self.assertFalse(report["task_success"], "one-second episode must not fabricate a completed transfer")
            with self.assertRaisesRegex(ValueError, "already exists"):
                evaluate_policy_in_simulation(self.world, self.checkpoint, Path(directory), seed=123)

    def test_policy_timing_or_unit_mismatch_is_rejected_before_execution(self):
        import shutil
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            for label, key, value in (("timing", "sample_period_s_verified", 0.05), ("unit", "action_unit", "deg")):
                checkpoint = root/label
                shutil.copytree(self.checkpoint, checkpoint)
                manifest_path = checkpoint/"policy_manifest.json"
                manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
                if label == "unit":
                    manifest["contract"][key] = value
                else:
                    manifest[key] = value
                manifest_path.write_text(json.dumps(manifest), encoding="utf-8")
                output = root/f"output_{label}"
                with self.subTest(label=label), self.assertRaises(ValueError):
                    evaluate_policy_in_simulation(self.world, checkpoint, output, seed=5)
                self.assertFalse(output.exists())

    def test_response_uses_physics_and_disjoint_reset_sessions(self):
        import hashlib
        import numpy as np
        from robot_env_agent.identification import compare_and_fit
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            path = collect_simulation_response_log(self.world, root/"response.json")
            before_hash = hashlib.sha256(path.read_bytes()).hexdigest()
            data = json.loads(path.read_text(encoding="utf-8"))
            self.assertEqual(data["execution_kind"], "simulation")
            self.assertEqual([row["split"] for row in data["sessions"]], ["calibration"]*2+["holdout"]*2)
            self.assertEqual(len({row["session_id"] for row in data["sessions"]}), 4)
            for row in data["sessions"]:
                self.assertTrue(row["reset_performed"])
                self.assertEqual(len(row["timestamps_s"]), 400)
                self.assertTrue((np.diff(row["timestamps_s"]) > 0).all())
                self.assertGreater(np.max(np.abs(np.asarray(row["measured_state"])-row["transmitted_command"])), 1e-4)
                self.assertLessEqual(max(map(abs, row["transmitted_command"])), 0.105)
            report = compare_and_fit(path, root/"fit")
            self.assertEqual(report["execution_kind"], "simulation")
            self.assertFalse(report["holdout_used_for_fitting"])
            self.assertFalse(report["real_calibration_verified"])
            self.assertTrue(set(report["model"]["fit_sessions"]).isdisjoint(report["holdout_session_ids"]))
            self.assertEqual(hashlib.sha256(path.read_bytes()).hexdigest(), before_hash)


if __name__ == "__main__":
    unittest.main()
