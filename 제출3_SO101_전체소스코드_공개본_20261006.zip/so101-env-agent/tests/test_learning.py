import importlib.util
import io
import json
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest import mock

from robot_env_agent import learning

from robot_env_agent.learning import (create_synthetic_chunk_dataset, create_synthetic_demonstrations,
                                       evaluate_chunk_policy, load_chunk_dataset, load_chunk_policy,
                                       train_chunk_policy, write_chunk_dataset)


@unittest.skipUnless(importlib.util.find_spec("numpy"), "numpy optional dependency is not installed")
class LearningTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.dataset = create_synthetic_chunk_dataset(self.root / "fixture.npz")

    def rewrite(self, mutate):
        data = load_chunk_dataset(self.dataset)
        mutate(data)
        return write_chunk_dataset(self.root / "modified.npz", observations=data["observations"],
                                   actions=data["actions"], episode_ids=data["episode_ids"],
                                   splits=data["splits"], timestamps_s=data["timestamps_s"], metadata=data["metadata"])

    def test_numpy_training_roundtrip_and_heldout_labels(self):
        report = train_chunk_policy(self.dataset, self.root / "model", backend="numpy")
        self.assertEqual(report["backend"], "numpy_ridge_chunk")
        self.assertEqual(report["execution_kind"], "synthetic")
        self.assertFalse(report["final_test_used_for_training"])
        self.assertEqual(report["task_success"], "not_evaluated")
        heldout = evaluate_chunk_policy(self.root / "model", self.dataset)
        self.assertLess(heldout["mae"], 1e-3)
        self.assertEqual(heldout["split"], "test")
        model = load_chunk_policy(self.root / "model")
        self.assertEqual(model.predict([0.1, -0.2, 0.4, 1.0]).shape, (4, 2))
        self.assertTrue((self.root / "model" / "test_evaluation.json").is_file())

    def test_episode_cannot_leak_between_splits(self):
        def mutate(data):
            data["splits"][0] = "test"
        with self.assertRaisesRegex(ValueError, "episode cannot cross"):
            self.rewrite(mutate)

    def test_random_action_labels_are_rejected(self):
        def mutate(data):
            data["metadata"]["label_source"] = "random_actions"
        with self.assertRaisesRegex(ValueError, "random actions"):
            self.rewrite(mutate)

    def test_normalization_uses_train_only(self):
        import numpy as np
        def mutate(data):
            data["observations"][data["splits"] != "train"] += 1000.0
        modified = self.rewrite(mutate)
        report = train_chunk_policy(modified, self.root / "model", backend="numpy")
        data = load_chunk_dataset(modified)
        model = load_chunk_policy(self.root / "model")
        expected = data["observations"][data["splits"] == "train"].mean(axis=0)
        np.testing.assert_allclose(model.weights["obs_mean"], expected)
        self.assertEqual(report["normalization_fit_split"], "train")

    def test_unknown_action_unit_blocks_training(self):
        def mutate(data):
            data["metadata"]["action_unit"] = None
        with self.assertRaisesRegex(ValueError, "unit and semantics"):
            self.rewrite(mutate)

    def test_nonfinite_or_repeated_timestamp_blocks_dataset(self):
        def repeated(data):
            data["timestamps_s"][1] = data["timestamps_s"][0]
        with self.assertRaisesRegex(ValueError, "timestamps"):
            self.rewrite(repeated)
        def nonfinite(data):
            data["actions"][0, 0] = float("nan")
        with self.assertRaisesRegex(ValueError, "finite"):
            self.rewrite(nonfinite)

    def test_irregular_action_chunk_sampling_requires_explicit_resampling(self):
        def mutate(data):
            data["timestamps_s"][2] += 0.01
        with self.assertRaisesRegex(ValueError, "fixed sampling"):
            self.rewrite(mutate)

    def test_checkpoint_checksum_protects_weights(self):
        train_chunk_policy(self.dataset, self.root / "model", backend="numpy")
        weights = self.root / "model" / "weights.npz"
        weights.write_bytes(weights.read_bytes() + b"tampered")
        with self.assertRaisesRegex(ValueError, "checksum"):
            load_chunk_policy(self.root / "model")

    def test_policy_evaluation_rejects_changed_joint_order(self):
        train_chunk_policy(self.dataset, self.root / "model", backend="numpy")
        def mutate(data):
            data["metadata"]["action_names"] = list(reversed(data["metadata"]["action_names"]))
        modified = self.rewrite(mutate)
        with self.assertRaisesRegex(ValueError, "contract"):
            evaluate_chunk_policy(self.root / "model", modified)

    def test_final_evaluation_rejects_training_episode_ids(self):
        train_chunk_policy(self.dataset, self.root / "model", backend="numpy")
        def mutate(data):
            train = data["episode_ids"] == "synthetic-0"
            test = data["episode_ids"] == "synthetic-7"
            data["episode_ids"][train] = "temporary-0"
            data["episode_ids"][test] = "synthetic-0"
        modified = self.rewrite(mutate)
        with self.assertRaisesRegex(ValueError, "leakage"):
            evaluate_chunk_policy(self.root / "model", modified)

    def test_fixture_helper_is_explicitly_not_physical(self):
        report = create_synthetic_demonstrations(self.root / "other.npz")
        self.assertEqual(report["execution_kind"], "synthetic")
        self.assertFalse(report["physical_trajectory"])

    def test_training_refuses_to_overwrite_input_dataset(self):
        source = create_synthetic_chunk_dataset(self.root / "weights.npz")
        with self.assertRaisesRegex(ValueError, "overwrite"):
            train_chunk_policy(source, self.root, backend="numpy")
        self.assertEqual(load_chunk_dataset(source)["metadata"]["data_kind"], "synthetic")

    def malicious_archive(self, *, shape=(100000000,), dtype="<f8", payload=b"\0" * 8, version=1):
        import numpy as np
        buffer = io.BytesIO()
        writer = np.lib.format.write_array_header_1_0 if version == 1 else np.lib.format.write_array_header_2_0
        writer(buffer, {"descr": dtype, "fortran_order": False, "shape": shape})
        buffer.write(payload)
        path = self.root / "hostile.npz"
        with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
            archive.writestr("observations.npy", buffer.getvalue())
        return path

    def test_huge_declared_npy_shape_rejected_before_numpy_data_loading(self):
        # A <1 KiB ZIP claiming an 800 MB ndarray must never allocate that array.
        path = self.malicious_archive()
        self.assertLess(path.stat().st_size, 1024)
        with mock.patch("numpy.load", side_effect=AssertionError("unsafe array loader called")), \
                mock.patch("numpy.frombuffer", side_effect=AssertionError("array constructed before shape check")):
            with self.assertRaisesRegex(ValueError, "shape dimensions"):
                learning._load_npz(path)

    def test_npy_shape_payload_mismatch_rejected_before_array_view(self):
        path = self.malicious_archive(shape=(16,))
        with mock.patch("numpy.frombuffer", side_effect=AssertionError("array constructed before payload check")):
            with self.assertRaisesRegex(ValueError, "exactly match payload"):
                learning._load_npz(path)

    def test_object_npy_header_rejected_before_array_view(self):
        path = self.malicious_archive(shape=(1,), dtype="|O")
        with mock.patch("numpy.frombuffer", side_effect=AssertionError("object view constructed")):
            with self.assertRaisesRegex(ValueError, "object arrays"):
                learning._load_npz(path)

    def test_declared_giant_npy_header_is_bounded(self):
        path = self.root / "giant_header.npz"
        prefix = b"\x93NUMPY\x02\x00" + (0xFFFFFFFF).to_bytes(4, "little") + b"{}"
        with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
            archive.writestr("observations.npy", prefix)
        with self.assertRaisesRegex(ValueError, "header exceeds"):
            learning._load_npz(path)

    def test_valid_v2_header_and_fortran_data_roundtrip(self):
        import numpy as np
        source = np.asfortranarray(np.arange(12, dtype="float64").reshape(3, 4))
        buffer = io.BytesIO()
        np.lib.format.write_array(buffer, source, version=(2, 0), allow_pickle=False)
        path = self.root / "valid_v2.npz"
        with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
            archive.writestr("values.npy", buffer.getvalue())
        np.testing.assert_array_equal(learning._load_npz(path)["values"], source)

    def test_window_count_budget_precedes_output_allocation(self):
        data = load_chunk_dataset(self.dataset)
        with mock.patch.object(learning, "MAX_WINDOWS", 2), \
                mock.patch.object(learning, "_allocate_windows", side_effect=AssertionError("output allocated too early")):
            with self.assertRaisesRegex(ValueError, "window count budget"):
                learning._windows(data, 4, "train")

    def test_window_byte_budget_precedes_output_allocation(self):
        data = load_chunk_dataset(self.dataset)
        with mock.patch.object(learning, "MAX_ARCHIVE_BYTES", 100), \
                mock.patch.object(learning, "_allocate_windows", side_effect=AssertionError("output allocated too early")):
            with self.assertRaisesRegex(ValueError, "window output exceeds"):
                learning._windows(data, 4, "train")

    def test_training_update_budget_precedes_window_materialization(self):
        with mock.patch.object(learning, "MAX_TRAIN_UPDATES", 1), \
                mock.patch.object(learning, "_windows", side_effect=AssertionError("windows materialized too early")):
            with self.assertRaisesRegex(ValueError, "update budget exceeded before window allocation"):
                train_chunk_policy(self.dataset, self.root / "model", epochs=2, backend="numpy")

    def test_combined_split_bytes_precede_all_window_allocations(self):
        data = load_chunk_dataset(self.dataset)
        with mock.patch.object(learning, "load_chunk_dataset", return_value=data), \
                mock.patch.object(learning, "MAX_ARCHIVE_BYTES", 15000), \
                mock.patch.object(learning, "_windows", side_effect=AssertionError("windows materialized too early")):
            with self.assertRaisesRegex(ValueError, "combined action window output exceeds"):
                train_chunk_policy(self.dataset, self.root / "model", backend="numpy")

    def test_stable_episode_groups_preserve_interleaved_chronological_chunks(self):
        import numpy as np
        original = load_chunk_dataset(self.dataset)
        expected_x, expected_y = learning._windows(original, 4, "train")
        def mutate(data):
            order = np.arange(216).reshape(9, 24).T.reshape(-1)
            for key in ("observations", "actions", "episode_ids", "splits", "timestamps_s"):
                data[key] = data[key][order]
        interleaved = load_chunk_dataset(self.rewrite(mutate))
        actual_x, actual_y = learning._windows(interleaved, 4, "train")
        np.testing.assert_array_equal(actual_x, expected_x)
        np.testing.assert_array_equal(actual_y, expected_y)

    @unittest.skipUnless(importlib.util.find_spec("torch"), "PyTorch optional dependency is not installed")
    def test_actual_tiny_transformer_training_and_reload(self):
        import numpy as np
        report = train_chunk_policy(self.dataset, self.root / "torch_model", epochs=3, backend="torch")
        self.assertEqual(report["backend"], "torch_tiny_chunk_transformer")
        self.assertEqual(report["epochs_completed"], 3)
        self.assertEqual(len(report["normalized_epoch_mse"]), 3)
        self.assertIn("not original ACT", report["model_scope"])
        policy = load_chunk_policy(self.root / "torch_model")
        value = policy.predict([0.1, 0.2, 0.3, 1.0])
        self.assertEqual(value.shape, (4, 2))
        self.assertTrue(np.isfinite(value).all())
        heldout = evaluate_chunk_policy(self.root / "torch_model", self.dataset)
        self.assertTrue(np.isfinite(heldout["mae"]))
        self.assertEqual(heldout["task_success"], "not_evaluated")


if __name__ == "__main__":
    unittest.main()
