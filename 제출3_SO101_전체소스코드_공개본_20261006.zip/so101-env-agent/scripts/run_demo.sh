#!/usr/bin/env bash
set -euo pipefail

demo_project_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
demo_python_command=""
demo_skip_install=0
demo_skip_policy=0
demo_gl_backend="${MUJOCO_GL:-}"

while (($#)); do
    case "$1" in
        --python) [[ $# -ge 2 ]] || { echo '--python requires a path' >&2; exit 2; }; demo_python_command="$2"; shift 2 ;;
        --skip-install) demo_skip_install=1; shift ;;
        --skip-policy) demo_skip_policy=1; shift ;;
        --gl) [[ $# -ge 2 ]] || { echo '--gl requires egl, osmesa or glfw' >&2; exit 2; }; demo_gl_backend="$2"; shift 2 ;;
        --help) echo 'bash scripts/run_demo.sh [--python PATH] [--skip-install] [--skip-policy] [--gl egl|osmesa|glfw]'; exit 0 ;;
        *) echo "Unknown option: $1" >&2; exit 2 ;;
    esac
done

if [[ -n "$demo_gl_backend" && "$demo_gl_backend" != 'egl' && "$demo_gl_backend" != 'osmesa' && "$demo_gl_backend" != 'glfw' ]]; then
    echo 'MUJOCO_GL / --gl must be egl, osmesa or glfw' >&2
    exit 2
fi
cd -- "$demo_project_root"
demo_venv_python="$demo_project_root/.venv/bin/python"
if [[ ! -x "$demo_venv_python" ]]; then
    if [[ -z "$demo_python_command" ]]; then
        for demo_candidate in python3.12 python3 python; do
            if command -v "$demo_candidate" >/dev/null 2>&1; then
                demo_python_command="$demo_candidate"
                break
            fi
        done
    fi
    [[ -n "$demo_python_command" ]] || { echo 'Python >=3.10 is required; Python 3.12 is recommended.' >&2; exit 2; }
    "$demo_python_command" -c 'import sys; raise SystemExit(0 if sys.version_info >= (3,10) else 1)'
    "$demo_python_command" -m venv "$demo_project_root/.venv"
fi
"$demo_venv_python" -c 'import sys; raise SystemExit(0 if sys.version_info >= (3,10) else 1)'
if (( !demo_skip_install )); then
    "$demo_venv_python" -m pip install -r "$demo_project_root/requirements-sim.txt"
    if (( !demo_skip_policy )); then
        "$demo_venv_python" -m pip install -r "$demo_project_root/requirements-policy.txt"
    fi
fi

# Select only libraries discoverable on this host. No drivers/system packages are
# installed. Library presence is not proof of a working GPU rendering context.
if [[ -z "$demo_gl_backend" && -z "${DISPLAY:-}" ]]; then
    demo_gl_backend="$("$demo_venv_python" -c 'import ctypes.util; print("egl" if ctypes.util.find_library("EGL") else ("osmesa" if ctypes.util.find_library("OSMesa") else ""))')"
    if [[ -z "$demo_gl_backend" ]]; then
        echo 'No EGL/OSMesa library detected; rendering may be unavailable. Set --gl only for a configured backend.' >&2
    fi
fi
if [[ -n "$demo_gl_backend" ]]; then
    export MUJOCO_GL="$demo_gl_backend"
fi
export PYTHONPATH="$demo_project_root/src"
demo_run_directory="runs/demo-$(date -u +%Y%m%d-%H%M%S)Z-$$"
echo "Result directory: $demo_run_directory"
demo_arguments=(-m robot_env_agent demo --output-dir "$demo_run_directory")
if (( demo_skip_policy )); then
    demo_arguments+=(--skip-training)
fi
"$demo_venv_python" "${demo_arguments[@]}"
