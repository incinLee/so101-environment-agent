[CmdletBinding()]
param(
    [string]$PythonExecutable,
    [switch]$SkipInstall,
    [switch]$SkipPolicy
)

$ErrorActionPreference = 'Stop'
$demoProjectRoot = Split-Path -Parent $PSScriptRoot
$demoVenvPython = Join-Path $demoProjectRoot '.venv/Scripts/python.exe'
$demoPreviousPythonPath = $env:PYTHONPATH
Push-Location -LiteralPath $demoProjectRoot
try {
    if (-not (Test-Path -LiteralPath $demoVenvPython)) {
        $demoPythonCommand = $null
        $demoPythonPrefix = @()
        if ($PythonExecutable) {
            $demoPythonCommand = $PythonExecutable
        } elseif (Get-Command py -ErrorAction SilentlyContinue) {
            try {
                & py -3.12 -c 'import sys; raise SystemExit(0 if sys.version_info >= (3,10) else 1)' 2>$null
                if ($LASTEXITCODE -eq 0) {
                    $demoPythonCommand = 'py'
                    $demoPythonPrefix = @('-3.12')
                }
            } catch {
                # A launcher without Python 3.12 falls back to python below.
            }
        }
        if (-not $demoPythonCommand -and (Get-Command python -ErrorAction SilentlyContinue)) {
            $demoPythonCommand = 'python'
        }
        if (-not $demoPythonCommand) {
            throw 'Python 3.10 이상이 필요합니다. Python 3.12를 권장하며 -PythonExecutable 경로를 지정할 수 있습니다.'
        }
        & $demoPythonCommand @demoPythonPrefix -c 'import sys; raise SystemExit(0 if sys.version_info >= (3,10) else 1)'
        if ($LASTEXITCODE -ne 0) { throw '선택한 Python은 3.10 이상이어야 합니다.' }
        & $demoPythonCommand @demoPythonPrefix -m venv (Join-Path $demoProjectRoot '.venv')
        if ($LASTEXITCODE -ne 0) { throw '프로젝트 전용 .venv 생성에 실패했습니다.' }
    }
    & $demoVenvPython -c 'import sys; raise SystemExit(0 if sys.version_info >= (3,10) else 1)'
    if ($LASTEXITCODE -ne 0) { throw '.venv의 Python 버전이 지원 범위에 맞지 않습니다.' }
    if (-not $SkipInstall) {
        & $demoVenvPython -m pip install -r (Join-Path $demoProjectRoot 'requirements-sim.txt')
        if ($LASTEXITCODE -ne 0) { throw '시뮬레이션 의존성 설치에 실패했습니다. 글로벌 환경은 변경하지 않았습니다.' }
        if (-not $SkipPolicy) {
            & $demoVenvPython -m pip install -r (Join-Path $demoProjectRoot 'requirements-policy.txt')
            if ($LASTEXITCODE -ne 0) { throw 'CPU 정책 의존성 설치에 실패했습니다. -SkipPolicy는 이 설치를 생략합니다.' }
        }
    }
    $env:PYTHONPATH = Join-Path $demoProjectRoot 'src'
    $demoRunDirectory = 'runs/demo-' + [DateTime]::UtcNow.ToString('yyyyMMdd-HHmmssfff') + 'Z'
    Write-Host ('결과 폴더: ' + $demoRunDirectory)
    $demoArguments = @('-m', 'robot_env_agent', 'demo', '--output-dir', $demoRunDirectory)
    if ($SkipPolicy) { $demoArguments += '--skip-training' }
    & $demoVenvPython @demoArguments
    if ($LASTEXITCODE -ne 0) { throw ('데모가 실패 또는 차단 상태로 종료되었습니다. 결과 폴더를 확인하세요: ' + $demoRunDirectory) }
} finally {
    if ($null -eq $demoPreviousPythonPath) {
        Remove-Item -LiteralPath 'Env:PYTHONPATH' -ErrorAction SilentlyContinue
    } else {
        $env:PYTHONPATH = $demoPreviousPythonPath
    }
    Pop-Location
}
