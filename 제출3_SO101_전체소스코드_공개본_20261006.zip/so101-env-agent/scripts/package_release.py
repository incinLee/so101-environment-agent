"""Build a reproducible, allowlisted source ZIP; never package raw user data.

Run from any directory: python scripts/package_release.py --output /path/release.zip
New source files must be staged with Git before they can enter a release.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import subprocess
import tempfile
import zipfile


ROOT = Path(__file__).resolve().parents[1]
PREFIX = "so101-env-agent/"
MANIFEST_NAME = PREFIX + "RELEASE_MANIFEST.json"
ALLOWED_DIRECTORIES = {"src", "assets", "configs", "docs", "scripts", "tests"}
ALLOWED_ROOT_FILES = {
    "README.md", "AGENTS.md", "LICENSE", "LICENSE.txt", "LICENSE.md",
    "NOTICE", "NOTICE.md", "pyproject.toml", "requirements.txt",
    "requirements-sim.txt", "requirements-policy.txt", "requirements-video.txt", "requirements-lock.txt",
    ".gitignore", ".gitattributes",
}
ALLOWED_SUFFIXES = {
    ".py", ".md", ".json", ".toml", ".yaml", ".yml", ".txt",
    ".xml", ".urdf", ".mjcf", ".obj", ".stl", ".mtl",
    ".png", ".jpg", ".jpeg", ".svg", ".html", ".css", ".js",
    ".sh", ".ps1", ".csv",
}
EXCLUDED_PARTS = {
    ".git", ".venv", "venv", "env", "envs", "local_data", "runs",
    "data", "datasets", "checkpoints", "checkpoint", "weights", "secrets",
    "credentials", "__pycache__", ".pytest_cache", ".mypy_cache",
    ".ruff_cache", "node_modules", "build", "dist", ".idea", ".vscode",
}
EXCLUDED_SUFFIXES = {
    ".zip", ".pt", ".pth", ".ckpt", ".safetensors", ".onnx", ".pkl",
    ".pickle", ".h5", ".hdf5", ".npz", ".npy", ".pem", ".key",
    ".pfx", ".p12", ".pyc", ".pyo", ".mp4", ".webm", ".avi",
}
MAX_FILE_BYTES = 100 * 1024 * 1024
MAX_TOTAL_BYTES = 500 * 1024 * 1024
SECRET_PATTERNS = (
    re.compile(rb"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"),
    re.compile(rb"\bgh[pousr]_[A-Za-z0-9]{20,}\b"),
    re.compile(rb"\bgithub_pat_[A-Za-z0-9_]{30,}\b"),
    re.compile(rb"\bsk-(?:proj-)?[A-Za-z0-9_-]{32,}\b"),
    re.compile(rb"\bAKIA[0-9A-Z]{16}\b"),
)


def git_paths(*arguments: str) -> list[str]:
    completed = subprocess.run(
        ["git", "-C", str(ROOT), "ls-files", "-z", *arguments],
        check=True, capture_output=True, timeout=30,
    )
    return [part.decode("utf-8", errors="strict")
            for part in completed.stdout.split(b"\0") if part]


def allowed_path(name: str) -> bool:
    path = PurePosixPath(name)
    if path.is_absolute() or ".." in path.parts or "\\" in name or not path.parts:
        return False
    lower_parts = tuple(part.lower() for part in path.parts)
    if any(part in EXCLUDED_PARTS or part.endswith(".egg-info") for part in lower_parts):
        return False
    leaf = lower_parts[-1]
    if leaf.startswith(".env") or leaf.startswith(("credentials", "secret")):
        return False
    if path.suffix.lower() in EXCLUDED_SUFFIXES:
        return False
    # Calibration source code may be packaged; user calibration JSON may not.
    if "calibration" in leaf and path.suffix.lower() == ".json":
        return False
    if len(path.parts) == 1:
        return name in ALLOWED_ROOT_FILES
    return (path.parts[0] in ALLOWED_DIRECTORIES
            and (path.suffix.lower() in ALLOWED_SUFFIXES
                 or leaf in {"license", "notice"}))


def safe_source(name: str) -> Path:
    source = ROOT.joinpath(*PurePosixPath(name).parts)
    for ancestor in (source, *source.parents):
        if ancestor == ROOT:
            break
        if ancestor.is_symlink() or getattr(ancestor, "is_junction", lambda: False)():
            raise ValueError(f"release source cannot be a link or junction: {name}")
    source.resolve(strict=True).relative_to(ROOT)
    if not source.is_file():
        raise ValueError(f"release source is not a regular file: {name}")
    return source


def canonical_json(value: object) -> bytes:
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2)
            + "\n").encode("utf-8")


def archive_entry(name: str, payload: bytes, archive: zipfile.ZipFile) -> None:
    entry = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
    entry.create_system = 3
    entry.external_attr = 0o100644 << 16
    entry.compress_type = zipfile.ZIP_DEFLATED
    archive.writestr(entry, payload, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)


def verify_release(output: Path) -> dict:
    with zipfile.ZipFile(output, "r") as archive:
        names = archive.namelist()
        if len(set(names)) != len(names):
            raise ValueError("release ZIP contains duplicate entries")
        manifest = json.loads(archive.read(MANIFEST_NAME))
        expected = {MANIFEST_NAME}
        for record in manifest["files"]:
            name = record["path"]
            if not allowed_path(name):
                raise ValueError(f"release manifest includes forbidden path: {name}")
            archive_name = PREFIX + name
            expected.add(archive_name)
            payload = archive.read(archive_name)
            if len(payload) != record["size_bytes"]:
                raise ValueError(f"release entry size mismatch: {name}")
            if hashlib.sha256(payload).hexdigest() != record["sha256"]:
                raise ValueError(f"release entry hash mismatch: {name}")
        if set(names) != expected:
            raise ValueError("release ZIP entry list differs from the manifest")
        return manifest


def package_release(output: Path) -> dict:
    if output.suffix.lower() != ".zip":
        raise ValueError("--output must name a .zip file")
    try:
        output_parts = output.resolve().relative_to(ROOT).parts
    except ValueError:
        output_parts = ()
    if any(part.lower() in EXCLUDED_PARTS - {"build", "dist"} for part in output_parts):
        raise ValueError("release output cannot be written inside protected project data/environment paths")
    if output.exists():
        # Rerunning may replace our verified release, but never an unrelated ZIP.
        try:
            previous = verify_release(output)
        except (OSError, ValueError, KeyError, TypeError, zipfile.BadZipFile) as error:
            raise ValueError("release output already exists and is not a verified source release") from error
        if previous.get("package_kind") != "tracked_source_release":
            raise ValueError("release output already exists and is not our source release")
    tracked = sorted(set(git_paths("--cached")))
    untracked = sorted(name for name in git_paths("--others", "--exclude-standard")
                       if allowed_path(name))
    payloads = {}
    records = []
    total_bytes = 0
    for name in tracked:
        if not allowed_path(name):
            continue
        source = safe_source(name)
        if source.resolve() == output.resolve():
            raise ValueError("release output cannot overwrite a packaged source")
        if source.stat().st_size > MAX_FILE_BYTES:
            raise ValueError(f"release source exceeds the file budget: {name}")
        payload = source.read_bytes()
        if len(payload) > MAX_FILE_BYTES:
            raise ValueError(f"release source exceeds the file budget: {name}")
        total_bytes += len(payload)
        if total_bytes > MAX_TOTAL_BYTES:
            raise ValueError("release source exceeds the total size budget")
        if any(pattern.search(payload) for pattern in SECRET_PATTERNS):
            raise ValueError(f"credential-like content detected; review this file: {name}")
        payloads[PREFIX + name] = payload
        records.append({"path": name, "size_bytes": len(payload),
                        "sha256": hashlib.sha256(payload).hexdigest()})
    if not records:
        raise ValueError("no tracked allowlisted source files to package")
    manifest = {
        "schema_version": 1,
        "package_kind": "tracked_source_release",
        "root_directory": PREFIX.rstrip("/"),
        "file_count": len(records),
        "total_source_bytes": total_bytes,
        "reproducibility": "sorted paths, fixed ZIP timestamps, canonical manifest, SHA256 per file",
        "source_content": "current working-tree bytes of tracked allowlisted files",
        "excluded_categories": ["git metadata", "raw calibration and user data", "run artifacts",
                                "virtual environments", "credentials", "checkpoints"],
        "credential_check": "common token and private-key patterns; not a full security audit",
        "files": records,
    }
    payloads[MANIFEST_NAME] = canonical_json(manifest)
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(dir=output.parent, prefix=output.name + ".",
                                         suffix=".tmp", delete=False) as stream:
            temporary = Path(stream.name)
        with zipfile.ZipFile(temporary, "w", compression=zipfile.ZIP_DEFLATED,
                             compresslevel=9) as archive:
            for name in sorted(payloads):
                archive_entry(name, payloads[name], archive)
        verify_release(temporary)
        os.replace(temporary, output)
        temporary = None
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)
    return {
        "status": "passed",
        "output": str(output),
        "file_count": len(records),
        "size_bytes": output.stat().st_size,
        "sha256": hashlib.sha256(output.read_bytes()).hexdigest(),
        "manifest_sha256": hashlib.sha256(payloads[MANIFEST_NAME]).hexdigest(),
        "untracked_allowlisted_files_omitted": untracked,
        "next_step": "stage intended source files and rerun if any omitted file belongs in the release",
    }


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args(argv)
    output = args.output if args.output.is_absolute() else ROOT / args.output
    try:
        report = package_release(output.resolve())
    except (OSError, ValueError, KeyError, TypeError, subprocess.SubprocessError,
            zipfile.BadZipFile) as error:
        print(json.dumps({"status": "failed", "error": str(error)}, ensure_ascii=False))
        return 2
    print(json.dumps(report, ensure_ascii=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
