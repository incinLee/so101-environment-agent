[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
$publishRoot = Split-Path -Parent $PSScriptRoot
$publishRemote = 'https://github.com/incinLee/so101-environment-agent.git'
Push-Location -LiteralPath $publishRoot
try {
    if (-not (Get-Command git -ErrorAction SilentlyContinue)) { throw 'Git for Windows가 필요합니다.' }
    if (-not (Test-Path -LiteralPath (Join-Path $publishRoot '.git'))) {
        & git init -b main
        if ($LASTEXITCODE -ne 0) { throw '이 소스 폴더에 Git 저장소를 만들지 못했습니다.' }
    }
    $publishGitRoot = (& git rev-parse --show-toplevel).Trim()
    if ([IO.Path]::GetFullPath($publishGitRoot).TrimEnd('/','\') -ne [IO.Path]::GetFullPath($publishRoot).TrimEnd('/','\')) {
        throw '다른 저장소를 가리키고 있습니다. 소스 폴더의 독립 저장소만 허용합니다.'
    }
    $publishBranch = (& git branch --show-current).Trim()
    if ($publishBranch -ne 'main') { throw 'main 브랜치에서만 실행하세요. 기존 브랜치를 자동 변경하지 않습니다.' }
    # Generated source and reviewed public assets only. Raw input/run folders are
    # never staged, and an already-tracked sensitive folder makes this fail closed.
    & git add -- .gitignore .gitattributes AGENTS.md README.md LICENSE NOTICE pyproject.toml requirements-sim.txt requirements-policy.txt requirements-video.txt src tests assets configs docs scripts
    if ($LASTEXITCODE -ne 0) { throw '소스 준비에 실패했습니다.' }
    $publishTracked = & git ls-files
    foreach ($publishName in $publishTracked) {
        if ($publishName -match '(^|/)(local_data|runs|datasets|data|checkpoints|weights|secrets|credentials|\.venv)/|(^|/)\.env(\.|$)|\.(pt|pth|npz|zip|pkl|pickle|pem|key|mp4)$|(^|/)[^/]*calibration[^/]*\.json$') {
            throw ('비공개 데이터 또는 비밀파일이 추적되어 업로드를 중단합니다: ' + $publishName)
        }
        $publishFullPath = Join-Path $publishRoot $publishName
        if ([IO.Path]::GetExtension($publishName) -in @('.py','.md','.json','.toml','.txt','.ps1','.sh')) {
            $publishContent = [IO.File]::ReadAllText($publishFullPath)
            if ($publishContent -match '-----BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY-----|\bgh[pousr]_[A-Za-z0-9]{20,}\b|\bgithub_pat_[A-Za-z0-9_]{30,}\b|\bsk-(proj-)?[A-Za-z0-9_-]{32,}\b|\bAKIA[0-9A-Z]{16}\b') {
                throw ('비밀정보 패턴이 발견되어 업로드를 중단합니다: ' + $publishName)
            }
        }
    }
    & git diff --cached --quiet
    if ($LASTEXITCODE -eq 1) {
        & git -c user.name=incinLee -c user.email=incinLee@users.noreply.github.com commit -m 'Add validated local SO-101 environment agent prototype'
        if ($LASTEXITCODE -ne 0) { throw '로컬 커밋에 실패했습니다.' }
    } elseif ($LASTEXITCODE -ne 0) { throw '변경 확인에 실패했습니다.' }
    $publishRemotes = & git remote
    if ($publishRemotes -contains 'origin') {
        $publishExisting = (& git remote get-url origin).Trim()
        if ($publishExisting -ne $publishRemote) { throw 'origin이 다른 저장소입니다. 자동 변경하지 않습니다.' }
    } else {
        & git remote add origin $publishRemote
        if ($LASTEXITCODE -ne 0) { throw '원격 저장소 설정에 실패했습니다.' }
    }
    Write-Host '설정된 GitHub 저장소에 backend 소스를 전송합니다. 이 스크립트는 backend 단독 게시용입니다. Git 로그인 창은 사용자가 직접 완료하세요.'
    & git -c http.sslBackend=openssl push -u origin main
    if ($LASTEXITCODE -ne 0) { throw 'GitHub 전송 미완료입니다. Git 인증을 확인한 뒤 이 스크립트를 다시 실행하세요.' }
    Write-Host ('GitHub 전송 완료: ' + $publishRemote)
} finally {
    Pop-Location
}
