[CmdletBinding()]
param(
    [ValidateSet('scripted','learned')][string]$Controller='scripted',
    [string]$World,
    [string]$Checkpoint,
    [int]$Seed=0,
    [switch]$SkipInstall,
    [switch]$Open
)

$ErrorActionPreference = 'Stop'
$videoProjectRoot = Split-Path -Parent $PSScriptRoot
$videoPython = Join-Path $videoProjectRoot '.venv/Scripts/python.exe'
$videoPreviousPythonPath = $env:PYTHONPATH
Push-Location -LiteralPath $videoProjectRoot
try {
    if (-not (Test-Path -LiteralPath $videoPython)) {
        throw '먼저 scripts/run_demo.ps1 -SkipPolicy 를 실행해 프로젝트 전용 환경을 준비하세요.'
    }
    if (-not $SkipInstall) {
        & $videoPython -m pip install -r requirements-video.txt
        if ($LASTEXITCODE -ne 0) { throw '영상 인코더 설치에 실패했습니다.' }
    }
    $env:PYTHONPATH=Join-Path $videoProjectRoot 'src'
    $videoStamp=[DateTime]::UtcNow.ToString('yyyyMMdd-HHmmssfff')+'Z'
    if (-not $World) {
        if ($Controller -eq 'learned') { throw '학습 정책 녹화는 같은 환경의 -World 와 -Checkpoint를 지정하세요.' }
        $videoWorldDirectory='runs/video-world-'+$videoStamp
        & $videoPython -m robot_env_agent build-sim --output-dir $videoWorldDirectory
        if ($LASTEXITCODE -ne 0) { throw '녹화용 시뮬레이션 환경 생성에 실패했습니다.' }
        $World=$videoWorldDirectory+'/scene.xml'
    }
    $videoRunDirectory='runs/video-'+$Controller+'-'+$videoStamp
    $videoArguments=@('-m','robot_env_agent','record-video','--world',$World,'--controller',$Controller,
                      '--seed',"$Seed",'--fps','15','--output-dir',$videoRunDirectory)
    if ($Checkpoint) { $videoArguments+=@('--checkpoint',$Checkpoint) }
    & $videoPython @videoArguments
    if ($LASTEXITCODE -ne 0) { throw ('녹화 미완료. 실행 기록을 확인하세요: '+$videoRunDirectory) }
    $videoReport=Get-Content -LiteralPath (Join-Path $videoRunDirectory 'video_report.json') -Raw | ConvertFrom-Json
    if ($videoReport.video.video_status -ne 'executed' -or -not $videoReport.video.video_path) {
        throw ('영상 저장에 실패했습니다. video_report.json을 확인하세요: '+$videoRunDirectory)
    }
    $videoFile=Join-Path $videoProjectRoot (Join-Path $videoRunDirectory $videoReport.video.video_path)
    Write-Host ('영상: '+$videoFile)
    Write-Host ('작업 성공 여부: '+$videoReport.task_success)
    if ($Open) { Start-Process -FilePath $videoFile }
} finally {
    if ($null -eq $videoPreviousPythonPath) { Remove-Item -LiteralPath 'Env:PYTHONPATH' -ErrorAction SilentlyContinue }
    else { $env:PYTHONPATH=$videoPreviousPythonPath }
    Pop-Location
}
