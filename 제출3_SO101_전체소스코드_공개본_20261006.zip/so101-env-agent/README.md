# SO-101 환경 구축·검증 에이전트 0.2.2

SO-101의 트레이 간 부품 이송 환경을 생성하고 검사하며, 실제 MuJoCo 물리 실행과 시연 데이터·작은 행동 chunk 정책 학습을 연결하는 로컬 프로젝트입니다. 제품 런타임은 학습된 두 종류의 목표 분류기와 허용된 도구를 사용합니다. Codex는 이 프로젝트를 개발하는 도구이며 제품 런타임 모델과 별개입니다.

0.2.0의 Windows CPU 전체 CLI 기록에서 최종 장면의 scripted 접촉 baseline은 9/9건 성공했고, **학습 정책의 holdout 이송은 0/2건으로 실패했습니다.** 환경 생성·도구 연결·학습·평가를 재현하는 개발 버전이며 학습된 움직임 정책은 개선이 필요합니다. 당시 통합 시험 97건을 18.346초에 통과했고 skip은 없습니다. 현재 0.2.2 backend 시험은 121건, 앱 시험은 42건이 통과했습니다. 상세 기록은 [전달 상태](docs/DELIVERY_STATUS.md)에 있습니다. 실제 로봇·Ubuntu/CUDA 실행, 실측 보정과 기존 ACT 통합은 수행하지 않았습니다.

0.2.1에서는 MuJoCo 장면 탐색 창과 실제 물리 실행의 연속 MP4 녹화를 추가했습니다. 새 전체 시험 108건을 29.500초에 통과했고 skip은 없습니다. 별도 녹화 시행은 scripted seed 0 이송 성공, learned seed 7 실패이며 기존 holdout 0/2 기록을 유지합니다. [장면 열기·검증·영상 저장 안내](docs/VIDEO_GUIDE.md)와 [영상 추가 검증](docs/VALIDATION_VIDEO.json)에 명령과 결과를 기록했습니다.

0.2.2에서는 `demo/agent --workers 8`로 최대 8개 독립 CPU MuJoCo 작업장의 시연을 병렬 수집합니다. 각 작업장에는 SO-101 한 팔이 있으며 동일한 world를 별도 프로세스의 model/data로 읽습니다. 전체 시연은 기존과 같이 9회, 학습/검증/시험은 5/2/2회입니다. 강화학습이나 GPU 학습을 추가한 것이 아니며, 기존 모방학습 정책의 성공을 보장하지 않습니다. 진행 상태·실행 구간·PID·실패 근거는 새 run에 기록합니다. [8개 작업장 실행·결과 확인](docs/PARALLEL_GUIDE.md)에 명령과 측정 대상 경로를 설명했습니다. 위 0.2.0/0.2.1 결과는 이번 병렬 실행 결과와 구분합니다.

## 실행

Python 3.12를 권장하며 실제 검증은 3.12.14에서 했습니다. 코어의 최소 버전은 3.10입니다. 이 버전은 source 폴더와 `PYTHONPATH=src`로 실행합니다. wheel 배포에는 robot 자산·configs가 포함되지 않아 지원하지 않습니다. 실행 스크립트는 프로젝트 `.venv`와 명시된 의존성을 사용합니다. 첫 설치에는 Python 패키지 다운로드가 필요하며 글로벌 환경·드라이버를 변경하지 않습니다.

Windows PowerShell에서 프로젝트 폴더를 열고:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\run_demo.ps1
```

Ubuntu에서 프로젝트 폴더를 열고:

```bash
bash scripts/run_demo.sh
```

데모의 직접 CLI 계약은 다음과 같습니다. Windows는 `.venv\Scripts\python.exe`, Ubuntu는 `.venv/bin/python`을 사용합니다.

```powershell
$env:PYTHONPATH = Join-Path (Get-Location) 'src'
.\.venv\Scripts\python.exe -m robot_env_agent demo --goal "부품을 한 트레이에서 다른 트레이로 옮기는 환경을 구성하고 검증해줘" --scene configs/scene.simulation.json --output-dir runs/my-demo --epochs 60
```

8개 독립 작업장에서 수집하려면 위 명령에 `--workers 8`을 추가합니다. CLI 기본값은 `--workers 1`입니다. `--skip-training` 경로는 시연 한 건만 실행하므로 8을 요청해도 유효 작업장 수가 1이며, 요청 수와 실제 수를 모두 기록합니다. 학습 데이터의 미니배치 64와 작업장 수 8은 서로 다른 설정입니다.

실행 결과를 보존하도록 매번 새로운 출력 폴더를 사용합니다. `exit0`은 도구 흐름 실행 완료를 뜻하며 정책의 이송 성공을 뜻하지 않습니다. 스크립트·CLI·시뮬레이터가 실제 로봇을 연결하거나 움직이지 않습니다. 세부 명령과 패키징은 [빠른 실행 안내](docs/QUICKSTART.md)에 기록합니다.

## 구현 범위와 해석

| 기능 | 현재 범위 | 해석 경계 |
|---|---|---|
| 환경 구축 | 공개 SO-101 MJCF/mesh와 선언형 작업 설정으로 MuJoCo world 생성·검사 | 임의 로봇 복원·실측 디지털 트윈 아님 |
| 런타임 AI | 문자 n-gram TF-IDF와 학습된 softmax로 tray_transfer/response_calibration 분류 | 36개 합성 개발 예제·16개 별도 fixture 범위. 일반 LLM 아님 |
| 실행·피드백 | 등록 도구·구조화 상태·검사 결과에 따른 제한된 실행/재시도 | 보호된 평가 기준·안전 설정을 변경해 합격시키지 않음 |
| 물리 실행 | MuJoCo 3.3.7에서 실제 관절·접촉·부품 이동·카메라 출력 | scripted IK baseline과 학습 정책을 별도로 평가 |
| 병렬 시연 수집 | Windows spawn 독립 프로세스 1~8개, 시연 9회 고정·순서 보존·실패 보존 | 작업장 복제이며 두 팔 협동·강화학습·GPU/MJX 구현 아님. 속도 개선은 새 실행 근거로 판단 |
| 시연·학습 | episode 분할과 train-only 정규화, CPU Torch 행동 chunk 학습 | 12차원 상태→6차원 행동, chunk 4, 32차원 2층/4-head Transformer. 원본 ACT의 이미지/CVAE는 미구현 |
| 응답 비교·보정 | 시간·단위가 명시된 로그에서 제한된 scalar gain/delay 추정, 별도 holdout 비교 | 합성 검증은 실측 보정 효과가 아님. 질량·관성·마찰·모터 동역학을 복원하지 않음 |
| 정적·mock 도구 | 보정 ZIP 검사, unknown 보존 draft, 계획·manifest·CPU mock | 이전 mock 기록을 실제 물리 증거로 재분류하지 않음 |

첫 작업은 사용자가 선택한 `tray_transfer`입니다. 한 대의 SO-101을 먼저 활성화하고 다른 follower 프로필은 보류합니다. **30mm 정육면체, 120×100×20mm 트레이, 600×400mm 작업면은 시뮬레이션 제안값**입니다. 실제 부품·트레이 치수, 두 팔의 보정 대응·LeRobot 단위는 미확인으로 유지합니다.

## 검증·출처

실제 완료 범위·명령·실패·제한은 [전달 상태](docs/DELIVERY_STATUS.md), 선택과 가정은 [설계 결정](docs/DECISIONS.md), 기존자산·신규 기여는 [출처 기록](docs/PROVENANCE.md), AI 도구와 제품 모델의 구분은 [AI 사용 기록](docs/AI_USAGE.md)에 있습니다. [최종 검증 요약](docs/VALIDATION_FINAL.json)은 0.2.0의 실제 실행 기록입니다. `docs/VALIDATION.json`은 10월 5일 초기 32건 시험 결과로 별도 보존합니다.

실제 source ZIP 생성·manifest 검증을 완료했습니다. Windows 줄바꿈 변환이 켜진 별도 로컬 Git 복제에서도 공개 자산 hash를 보존하고 `demo --skip-training`으로 baseline 1/1·응답 비교를 실행했습니다. 최종 ZIP의 SHA와 바이트 수는 외부 release 기록에 남깁니다.

SO-101 모델은 [MuJoCo Menagerie](https://github.com/google-deepmind/mujoco_menagerie/tree/3abca2e302625cec9429c49806121ea2855cef81/robotstudio_so101)의 고정 커밋에서 가져왔으며 자산별 SHA256·출처·Apache-2.0 라이선스를 보존합니다. 자체 코드/문서는 [Proprietary / All rights reserved](LICENSE)를 유지합니다. 소유자가 이번 저장소 공개를 승인했으며, 저장소 열람 가능성이 수령자의 무제한 재배포 권한을 뜻하지 않습니다. 제3자 자산은 해당 라이선스가 적용됩니다. [NOTICE](NOTICE)를 함께 확인하세요.

## 저장소·대회

원본 보정·개인 데이터·실행 산출물·가상환경·체크포인트는 공개 소스에서 제외합니다. 이번 공개용 사본은 사용자의 명시적 요청으로 준비했습니다. [incinLee/so101-environment-agent](https://github.com/incinLee/so101-environment-agent)의 실제 공개·게시 상태는 저장소에서 확인합니다. ZIP에는 학습 weights가 없고 demo가 시뮬레이션 시연과 정책을 다시 생성합니다.

대회 신청 완료·스마트팩토리 분야는 확인됐습니다. 최종 제출 마감은 **2026-10-06 낮 12:00 KST**이며, 소스 데모와 대회 최종 신청서·보고서·영상·발표자료는 별개입니다. [규정 대응](docs/RULE_COMPLIANCE.md)에 요구 사항과 현재 증거 범위를 구분했습니다. 소규모 합성·시뮬레이션 결과를 실제 장비 전이·산업 신뢰성·전체 플랫폼 완성으로 주장하지 않습니다.
