"""Local AI routing and bounded environment construction/evaluation workflow.

All actions are registered Python tools. The intent model selects a supported
workflow; feedback can alter assumed tray layout once, never evaluation rules.
"""

import copy
import hashlib
import json
import platform
import sys
import time
from pathlib import Path

from .intent import classify_goal, get_intent_model_report
from .runtime import ToolExecutor, fingerprint, resolve_path, write_json

DEFAULT_GOAL = "부품을 한 트레이에서 다른 트레이로 옮겨줘"
EVALUATION_RULES = {
    "criterion": "entire_rotated_part_inside_target_and_settled_after_release",
    "settled_speed_limit_m_s": 0.03,
    "gripper_open_threshold_rad": 0.5,
    "gripper_part_contact_required_absent": True,
    "forced_grasp": False,
    "teleportation_after_reset": False,
}


def resolve_run_directory(root: Path, path: str) -> Path:
    candidate = resolve_path(root, path)
    parts = candidate.relative_to(root.resolve()).parts
    if len(parts) < 2 or parts[0] != "runs":
        raise PermissionError("execution output must be a new directory inside runs")
    if candidate.exists():
        raise ValueError("output already exists; choose a new run directory to preserve evidence")
    return candidate


def protected_evaluation(scene: dict) -> str:
    return fingerprint({**EVALUATION_RULES, "hold_seconds": scene["hold_seconds"],
                        "object_size_m": scene["object_size_m"], "tray_size_m": scene["tray_size_m"]})


def propose_layout_repair(scene: dict, feedback: dict) -> dict | None:
    """Only a large IK residual permits one known assumed layout retry."""
    from .simulation import DEFAULT_SCENE, validate_scene
    if feedback["task_success"] or feedback.get("max_ik_position_error_m", 0) <= 0.03:
        return None
    repaired = copy.deepcopy(scene)
    for key in ("source_center_m", "target_center_m"):
        repaired[key] = list(DEFAULT_SCENE[key])
    if repaired == scene:
        return None
    repaired = validate_scene(repaired)
    if protected_evaluation(repaired) != protected_evaluation(scene):
        raise ValueError("repair attempted to change protected evaluation rules")
    return repaired


def aggregate_demonstrations(paths: list[Path], destination: Path) -> dict:
    """Nine independent resets; episode-level 5/2/2 split fixed before training."""
    import numpy as np
    from .learning import write_chunk_dataset
    if len(paths) != 9:
        raise ValueError("demo dataset requires nine independent episodes")
    resolved_paths = [path.resolve() for path in paths]
    if len(set(resolved_paths)) != len(paths):
        raise ValueError("duplicate demonstration paths would leak an episode across splits")
    hashes = set()
    for path in paths:
        if path.stat().st_size > 10_000_000:
            raise ValueError("demonstration exceeds file budget")
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        if digest in hashes:
            raise ValueError("duplicate demonstration contents would leak an episode across splits")
        hashes.add(digest)
    arrays = {key: [] for key in ("observations", "actions", "timestamps_s", "episode_ids", "splits")}
    reference = None
    for index, path in enumerate(paths):
        if path.stat().st_size > 10_000_000:
            raise ValueError("demonstration exceeds file budget")
        with np.load(path, allow_pickle=False) as data:
            metadata = json.loads(str(data["metadata_json"].item()))
            if reference is None:
                reference = metadata
            elif metadata != reference:
                raise ValueError("demonstration contracts or scenes differ")
            n = len(data["actions"])
            for key in ("observations", "actions", "timestamps_s"):
                arrays[key].append(data[key].copy())
            arrays["episode_ids"].append(np.full(n, f"seed-{index}"))
            split = "train" if index < 5 else ("validation" if index < 7 else "test")
            arrays["splits"].append(np.full(n, split))
    reference = dict(reference)
    reference.pop("split", None)
    reference["split_policy"] = "reset_seeds_0_to_4_train_5_to_6_validation_7_to_8_test"
    reference["demonstration_quality_verified"] = False
    joined = {key: np.concatenate(value) for key, value in arrays.items()}
    write_chunk_dataset(destination, **joined, metadata=reference)
    return {"execution_kind": "simulation", "episodes": 9, "samples": len(joined["actions"]),
            "train_episodes": 5, "validation_episodes": 2, "test_episodes": 2,
            "label_source": "scripted_controller", "camera_is_training_input": False,
            "distinct_source_files_and_contents": True, "initial_xy_jitter_m": 0.002}


def run_workflow(root: Path, output_dir: Path, *, goal=DEFAULT_GOAL, scene=None,
                 epochs=60, train=True, workers=1) -> dict:
    from .simulation import DEFAULT_SCENE, build_world, validate_scene
    from .parallel import collect_parallel_baselines, validate_workers
    if type(epochs) is not int or not 1 <= epochs <= 90:
        raise ValueError("workflow epochs must be 1 through 90")
    validate_workers(workers)
    output_dir = resolve_run_directory(root, str(output_dir))
    started = time.monotonic()
    intent_result = classify_goal(goal)
    report = {"schema_version": 1, "execution_kind": "simulation", "goal": goal,
              "status": "started", "physical_execution": "not_run", "hardware_access": False,
              "runtime_llm_used": False, "external_model_calls": 0,
              "intent_result": intent_result, "model_report": get_intent_model_report(),
              "host": {"os": platform.system(), "python": sys.version.split()[0],
                       "execution_device": "CPU", "ubuntu_or_cuda_validation": "not_run"},
              "training": {"status": "not_run"}, "policy_evaluation": {"status": "not_run"},
              "response_fit": {"status": "not_run"}, "image_paths": [], "repairs": [],
              "parallel_collection": {"status": "not_run", "requested_workers": workers},
              "parallel_collection_attempts": [],
              "baseline_attempts": [], "state_history": [], "limitations": [
                  "시뮬레이션용 설계 가정이며 보유한 두 팔의 실측 모델과 일치 검증하지 않았습니다.",
                  "첫 구현은 SO-101 한 팔과 한 작업입니다. 두 팔 동시 작업은 구현하지 않았습니다.",
                  "로컬 목표 분류기는 두 의도만 지원합니다. LLM이나 일반 자연어 설계기가 아닙니다.",
                  "작은 상태 기반 chunk Transformer입니다. 기존 ACT의 영상/CVAE 구현은 연동하지 않았습니다.",
                  "가상 부품의 정확한 위치를 관측합니다. USB 카메라 인식 및 실물 전이는 미검증입니다.",
                  "9회, ±2mm 초기 변화의 좁은 시연입니다. 산업 신뢰성이나 일반화를 입증하지 않습니다."]}
    output_dir.mkdir(parents=True)

    def state(name):
        report["state_history"].append({"state": name, "wall_elapsed_s": time.monotonic()-started})
        write_json(output_dir/"workflow_state.json", {"status": name, "physical_execution": "not_run"})

    def collect_baseline(world, seeds, prefix):
        episodes, metadata = collect_parallel_baselines(world, output_dir/prefix, seeds, workers=workers)
        report["parallel_collection"] = metadata
        report["parallel_collection_attempts"].append(metadata)
        for result in episodes:
            if result["seed"] == 0:
                run_dir = output_dir/result["evidence_directory"]
                report["image_paths"].extend(str((run_dir/frame["path"]).relative_to(output_dir))
                                             for frame in result["camera_frames"])
        return episodes

    def fit_response(world):
        from .simulation import collect_simulation_response_log
        from .identification import compare_and_fit
        source = collect_simulation_response_log(world, output_dir/"response_log.json")
        return compare_and_fit(source, output_dir/"response_fit")

    def train_policy(dataset):
        from .learning import train_chunk_policy
        return train_chunk_policy(dataset, output_dir/"policy", epochs=epochs, chunk_size=4, backend="torch", seed=7)

    def evaluate_policy(dataset, world):
        from .learning import evaluate_chunk_policy
        from .simulation import evaluate_policy_in_simulation
        offline = evaluate_chunk_policy(output_dir/"policy", dataset, split="test")
        rollouts = [evaluate_policy_in_simulation(world, output_dir/"policy", output_dir/"policy_rollouts"/f"seed-{seed}", seed=seed)
                    for seed in (7, 8)]
        return {"status": "executed", "offline_test": offline, "closed_loop": rollouts,
                "successes": sum(row["task_success"] for row in rollouts), "trials": len(rollouts),
                "heldout_initial_seeds": [7, 8], "final_test_used_for_tuning": False}

    executor = ToolExecutor({"validate_scene": validate_scene, "build_world": build_world,
                             "run_baseline": collect_baseline, "repair_layout": propose_layout_repair,
                             "collect_dataset": aggregate_demonstrations, "train_policy": train_policy,
                             "evaluate_policy": evaluate_policy, "fit_response": fit_response}, max_calls=10)
    try:
        if intent_result["intent"] == "unsupported":
            report["status"] = "unsupported"
            state("unsupported_goal")
        else:
            state("validate_assumed_scene")
            resolved = executor.call("validate_scene", scene=DEFAULT_SCENE if scene is None else scene)
            report["scene_assumptions"] = resolved
            evaluation_hash = protected_evaluation(resolved)
            report["protected_evaluation_sha256"] = evaluation_hash
            report["evaluation_rules"] = {**EVALUATION_RULES, "hold_seconds": resolved["hold_seconds"]}
            state("construct_environment")
            world_dir = output_dir/"environment"
            manifest = executor.call("build_world", output_dir=world_dir, scene=resolved)
            world = world_dir/"scene.xml"
            report["environment_manifest"] = manifest
            if intent_result["intent"] == "tray_transfer":
                state("physics_feedback")
                episodes = executor.call("run_baseline", world=world, seeds=range(9) if train else [0], prefix="baseline")
                report["baseline_attempts"].append({"attempt": 0, "episodes": episodes,
                                                    "successes": sum(row["task_success"] for row in episodes), "trials": len(episodes)})
                if not episodes[0]["task_success"]:
                    state("consider_bounded_layout_repair")
                    repaired = executor.call("repair_layout", scene=resolved, feedback=episodes[0])
                    if repaired is not None:
                        report["repairs"].append({"reason": "large_ik_residual", "before": resolved,
                                                   "after": repaired, "physical_measurement": False,
                                                   "protected_evaluation_unchanged": protected_evaluation(repaired) == evaluation_hash})
                        state("reconstruct_assumed_layout_once")
                        world_dir = output_dir/"environment_retry"
                        manifest = executor.call("build_world", output_dir=world_dir, scene=repaired)
                        world = world_dir/"scene.xml"
                        resolved = repaired
                        report["final_scene_assumptions"] = resolved
                        report["environment_manifest"] = manifest
                        episodes = executor.call("run_baseline", world=world, seeds=range(9) if train else [0], prefix="baseline_retry")
                        report["baseline_attempts"].append({"attempt": 1, "episodes": episodes,
                                                            "successes": sum(row["task_success"] for row in episodes), "trials": len(episodes)})
                report["baseline"] = {"episodes": episodes, "successes": sum(row["task_success"] for row in episodes),
                                      "trials": len(episodes), "ai_policy_used": False}
                if train and len(episodes) == 9 and all(row["task_success"] for row in episodes):
                    state("collect_episode_split_demonstrations")
                    dataset = output_dir/"demonstrations.npz"
                    report["dataset"] = executor.call("collect_dataset", paths=[output_dir/row["evidence_directory"]/"demonstration.npz" for row in episodes], destination=dataset)
                    state("train_chunk_transformer")
                    report["training"] = executor.call("train_policy", dataset=dataset)
                    state("evaluate_frozen_policy")
                    report["policy_evaluation"] = executor.call("evaluate_policy", dataset=dataset, world=world)
                else:
                    report["training"]["reason"] = "disabled_or_incomplete_successful_demonstrations; failures_preserved"
                report["status"] = "passed" if all(row["task_success"] for row in episodes) else "failed"
            else:
                report["status"] = "passed"
            # Response fitting is a separate model, never a hardware setting write.
            if len(executor.trace) < executor.max_calls:
                state("fit_simulated_response")
                report["response_fit"] = executor.call("fit_response", world=world)
            else:
                report["response_fit"]["reason"] = "bounded_tool_budget_exhausted_after_layout_retry"
            if protected_evaluation(resolved) != evaluation_hash:
                raise ValueError("protected evaluation changed during workflow")
            state("complete_with_evidence")
    except Exception as exc:
        report["status"] = "failed"
        report["error"] = f"{type(exc).__name__}: {exc}"
        state("failed_preserving_partial_evidence")
    report["trace"] = executor.trace
    report["tool_calls"] = len(executor.trace)
    report["tool_call_budget"] = executor.max_calls
    report["workflow_execution"] = report["status"]
    report["policy_task_status"] = ("passed" if report["policy_evaluation"].get("successes") == report["policy_evaluation"].get("trials")
                                     and report["policy_evaluation"].get("trials", 0) > 0 else
                                     "failed" if report["policy_evaluation"].get("trials", 0) > 0 else "not_run")
    report["wall_seconds"] = time.monotonic()-started
    write_json(output_dir/"workflow_report.json", report)
    from .reporting import write_dashboard
    write_dashboard(output_dir/"index.html", report)
    return report
