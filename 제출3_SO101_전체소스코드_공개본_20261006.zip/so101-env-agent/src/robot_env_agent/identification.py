"""Bounded scalar gain/transport-delay identification from explicit timestamp logs.

This toy response model is not motor dynamics, mass/inertia calibration, or a
real-device write. Fitting is limited to calibration sessions; holdout stays fixed.
"""

import hashlib
import json
import math
from pathlib import Path

GAIN_BOUNDS = (0.5, 1.5)
MAX_DELAY_S = 0.2
DELAY_GRID_STEP_S = 0.005


def _write_json(path: Path, payload: dict):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def _read_log(log_path: Path) -> dict:
    path = Path(log_path)
    if path.stat().st_size > 8 * 1024 * 1024:
        raise ValueError("response log exceeds 8 MiB budget")
    def pairs(items):
        out = {}
        for key, value in items:
            if key in out:
                raise ValueError("duplicate response log key")
            out[key] = value
        return out
    data = json.loads(path.read_text(encoding="utf-8-sig"), object_pairs_hook=pairs,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError("nonfinite log value")))
    if not isinstance(data, dict) or type(data.get("schema_version")) is not int or data.get("schema_version") != 1:
        raise ValueError("unsupported response log schema")
    if data.get("execution_kind") not in {"synthetic", "simulation", "real_recorded"}:
        raise ValueError("response log must declare execution_kind")
    if data.get("time_unit") != "s" or data.get("command_unit") not in {"rad", "deg", "m", "normalized"}:
        raise ValueError("known timestamp and command units are required")
    if not isinstance(data.get("clock_domain"), str) or not data["clock_domain"]:
        raise ValueError("one explicit clock domain is required")
    if data.get("measured_state_unit", data["command_unit"]) != data["command_unit"]:
        raise ValueError("measured and command units must match before fitting")
    sessions = data.get("sessions")
    if not isinstance(sessions, list) or not 2 <= len(sessions) <= 100:
        raise ValueError("calibration and holdout sessions are required")
    seen, count = set(), 0
    for session in sessions:
        if not isinstance(session, dict):
            raise ValueError("session must be an object")
        sid = session.get("session_id")
        if not isinstance(sid, str) or not sid or sid in seen:
            raise ValueError("session IDs must be nonempty and disjoint")
        seen.add(sid)
        if session.get("split") not in {"calibration", "holdout"}:
            raise ValueError("session split must be calibration or holdout")
        if session.get("clock_domain", data["clock_domain"]) != data["clock_domain"]:
            raise ValueError("clock domains must be aligned before identification")
        fields = ("timestamps_s", "requested_target", "transmitted_command", "measured_state")
        for name in fields:
            values = session.get(name)
            if not isinstance(values, list) or any(type(value) not in (int, float) or not math.isfinite(value) for value in values):
                raise ValueError(f"{name} must contain finite scalar values, not mixed command/state namespaces")
        n = len(session["timestamps_s"])
        if n < 12 or any(len(session[name]) != n for name in fields):
            raise ValueError("aligned sessions require at least 12 scalar samples")
        times = session["timestamps_s"]
        if any(right <= left for left, right in zip(times, times[1:])):
            raise ValueError("timestamps must strictly increase")
        if times[-1] - times[0] <= MAX_DELAY_S * 2:
            raise ValueError("session must exceed response delay horizon")
        count += n
    if count > 100000:
        raise ValueError("response sample budget exceeded")
    if {session["split"] for session in sessions} != {"calibration", "holdout"}:
        raise ValueError("calibration and holdout sessions must be separated")
    return data


def _interpolate(times: list, values: list, query: float) -> float:
    from bisect import bisect_right
    index = min(max(bisect_right(times, query) - 1, 0), len(times) - 2)
    fraction = (query - times[index]) / (times[index + 1] - times[index])
    return values[index] + fraction * (values[index + 1] - values[index])


def _pairs(sessions: list, delay_s: float) -> list:
    pairs = []
    for session in sessions:
        times, sent, measured = session["timestamps_s"], session["transmitted_command"], session["measured_state"]
        # Same samples at every grid delay: do not reward a fit by dropping hard samples.
        for time, state in zip(times, measured):
            if time >= times[0] + MAX_DELAY_S:
                pairs.append((_interpolate(times, sent, time - delay_s), state))
    return pairs


def _metrics(pairs: list, gain: float) -> dict:
    errors = [gain * command - state for command, state in pairs]
    if not errors:
        raise ValueError("no aligned response samples")
    return {"samples": len(errors), "mae": sum(abs(value) for value in errors) / len(errors),
            "mse": sum(value * value for value in errors) / len(errors)}


def compare_and_fit(log_path: Path, output_dir: Path) -> dict:
    """Fit bounded gain/delay on transmitted command, then compare held-out state."""
    path = Path(log_path)
    if path.resolve() in {(Path(output_dir) / name).resolve() for name in ("fitted_parameters.json", "identification_report.json")}:
        raise ValueError("identification output must not overwrite source response log")
    data = _read_log(path)
    calibration = [session for session in data["sessions"] if session["split"] == "calibration"]
    holdout = [session for session in data["sessions"] if session["split"] == "holdout"]
    zero_pairs = _pairs(calibration, 0.0)
    commands = [command for command, _ in zero_pairs]
    mean = sum(commands) / len(commands)
    variance = sum((value - mean) ** 2 for value in commands) / len(commands)
    if variance < 1e-8:
        raise ValueError("gain/delay are not identifiable from an unexcited constant command")
    candidates = []
    for index in range(round(MAX_DELAY_S / DELAY_GRID_STEP_S) + 1):
        delay_s = index * DELAY_GRID_STEP_S
        pairs = _pairs(calibration, delay_s)
        denominator = sum(command * command for command, _ in pairs)
        if denominator < 1e-10:
            continue
        raw_gain = sum(command * state for command, state in pairs) / denominator
        gain = min(max(raw_gain, GAIN_BOUNDS[0]), GAIN_BOUNDS[1])
        candidates.append((_metrics(pairs, gain)["mse"], delay_s, gain))
    if not candidates:
        raise ValueError("insufficient identifiable response excitation")
    candidates.sort()
    best_mse, delay_s, gain = candidates[0]
    # A flat delay objective cannot identify latency, even if one candidate is selected.
    if len(candidates) < 2 or max(item[0] for item in candidates) - best_mse < 1e-10:
        raise ValueError("delay objective is flat; transport delay is not identifiable")
    calibration_before = _metrics(_pairs(calibration, 0.0), 1.0)
    calibration_after = _metrics(_pairs(calibration, delay_s), gain)
    holdout_before = _metrics(_pairs(holdout, 0.0), 1.0)
    holdout_after = _metrics(_pairs(holdout, delay_s), gain)
    model = {"model_kind": "scalar_static_gain_plus_transport_delay", "gain": gain, "delay_s": delay_s,
             "gain_bounds": list(GAIN_BOUNDS), "delay_bounds_s": [0.0, MAX_DELAY_S],
             "delay_grid_step_s": DELAY_GRID_STEP_S, "command_unit": data["command_unit"],
             "clock_domain": data["clock_domain"], "fit_input_namespace": "transmitted_command",
             "estimate_at_search_boundary": gain in GAIN_BOUNDS or delay_s in (0.0, MAX_DELAY_S),
             "fit_output_namespace": "measured_state", "fit_sessions": [row["session_id"] for row in calibration],
             "alignment_assumption": "command and state share the supplied common time grid",
             "source_sha256": hashlib.sha256(path.read_bytes()).hexdigest(), "applied_to_hardware": False}
    report = {"status": "passed", "execution_kind": data["execution_kind"], "model": model,
              "metric_unit": data["command_unit"], "calibration_before": calibration_before,
              "calibration_after": calibration_after, "holdout_before": holdout_before,
              "holdout_after": holdout_after, "holdout_improved": holdout_after["mse"] < holdout_before["mse"],
              "holdout_used_for_fitting": False, "holdout_session_ids": [row["session_id"] for row in holdout],
              "requested_target_used_for_fitting": False, "hardware_write_performed": False,
              "recorded_real_fit_completed": data["execution_kind"] == "real_recorded",
              "physical_status": "not_run", "real_calibration_verified": False,
              "limitations": ["Only scalar static gain and bounded delay in the declared clock/unit contract are fitted.",
                              "Model does not identify motor dynamics, mass, inertia, friction or contact parameters.",
                              "Recorded real response fit does not establish safe hardware deployment.",
                              "Synthetic/simulation improvement is not real calibration evidence."]}
    out = Path(output_dir)
    _write_json(out / "fitted_parameters.json", model)
    _write_json(out / "identification_report.json", report)
    return report


def create_synthetic_response_log(log_path: Path, *, gain=1.12, delay_s=0.06) -> Path:
    """Toy response fixture with analytical commands and independent holdout."""
    if type(gain) not in (int, float) or type(delay_s) not in (int, float) or not math.isfinite(gain) or not math.isfinite(delay_s):
        raise ValueError("fixture parameters must be finite")
    if not GAIN_BOUNDS[0] <= gain <= GAIN_BOUNDS[1] or not 0 <= delay_s <= MAX_DELAY_S:
        raise ValueError("fixture parameters outside bounds")
    sessions = []
    for index, phase in enumerate((0.0, 0.4, 0.9)):
        times = [step * 0.01 for step in range(240)]
        def command(t):
            return 0.3 * math.sin(3.1 * t + phase) + 0.12 * math.cos(6.7 * t + phase)
        sent = [command(t) for t in times]
        measured = [gain * command(t - delay_s) if t < delay_s else gain * _interpolate(times, sent, t - delay_s) for t in times]
        sessions.append({"session_id": f"synthetic-session-{index}",
                         "split": "calibration" if index < 2 else "holdout", "timestamps_s": times,
                         # Requested target intentionally differs from actually transmitted command.
                         "requested_target": [value * 1.7 + 0.2 for value in sent],
                         "transmitted_command": sent, "measured_state": measured})
    path = Path(log_path)
    _write_json(path, {"schema_version": 1, "execution_kind": "synthetic", "time_unit": "s",
                      "command_unit": "rad", "measured_state_unit": "rad",
                      "clock_domain": "synthetic_episode_time", "sessions": sessions,
                      "provenance": "analytical toy model fixture; no real robot log or hardware measurement"})
    return path
