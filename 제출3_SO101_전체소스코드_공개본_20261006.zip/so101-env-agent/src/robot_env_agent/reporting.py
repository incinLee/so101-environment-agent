"""Offline evidence dashboard. All report data is escaped; no external assets."""

import base64
import html
import json
import math
from pathlib import Path

MAX_FRAMES = 8
MAX_FRAME_BYTES = 4 * 1024 * 1024
MAX_TOTAL_FRAME_BYTES = 16 * 1024 * 1024


def _escape(value) -> str:
    return html.escape(str(value), quote=True)


def _pre(value) -> str:
    return "<pre>" + _escape(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False)) + "</pre>"


def _script_json(value) -> str:
    return (json.dumps(value, ensure_ascii=False, allow_nan=False).replace("&", "\\u0026")
            .replace("<", "\\u003c").replace(">", "\\u003e")
            .replace("\u2028", "\\u2028").replace("\u2029", "\\u2029"))


def _percent(value) -> str:
    if type(value) in (int, float) and math.isfinite(value) and 0 <= value <= 1:
        return f"{value * 100:.1f}%"
    return "미확인"


def _count(value):
    return value if type(value) is int and value >= 0 else None


def _kind_badge(data) -> str:
    kind = "범위 확인 필요"
    if isinstance(data, dict):
        if "execution_kind" in data:
            kind = data["execution_kind"]
        elif isinstance(data.get("status"), str) and data["status"] in {"not_run", "blocked", "unsupported"}:
            kind = data["status"]
        else:
            nested = []
            for key in ("episodes", "closed_loop"):
                if isinstance(data.get(key), list):
                    nested.extend(item for item in data[key] if isinstance(item, dict))
            if isinstance(data.get("offline_test"), dict):
                nested.append(data["offline_test"])
            kinds = sorted({str(item["execution_kind"]) for item in nested if "execution_kind" in item})
            if kinds:
                kind = " + ".join(kinds)
    return '<span class="badge">' + _escape(kind) + '</span>'


def _section(title: str, content: str, data=None) -> str:
    badge = _kind_badge(data) if data is not None else ""
    return '<section><div class="section-heading"><h2>' + _escape(title) + '</h2>' + badge + '</div>' + content + '</section>'


def _images(output_path: Path, entries) -> str:
    if not isinstance(entries, list):
        raise ValueError("image_paths must be a list of local PNG paths")
    root = output_path.parent.resolve()
    figures, total = [], 0
    for entry in entries[:MAX_FRAMES]:
        if not isinstance(entry, str):
            raise ValueError("image_paths entries must be strings")
        raw = Path(entry)
        path = (raw if raw.is_absolute() else root / raw).resolve()
        if not path.is_relative_to(root) or path.suffix.lower() != ".png":
            raise ValueError("dashboard images must be PNG files inside this run directory")
        length = path.stat().st_size
        if length > MAX_FRAME_BYTES or total + length > MAX_TOTAL_FRAME_BYTES:
            raise ValueError("dashboard image budget exceeded")
        payload = path.read_bytes()
        if not payload.startswith(b"\x89PNG\r\n\x1a\n"):
            raise ValueError("dashboard image does not have a PNG signature")
        total += length
        name = str(path.relative_to(root))
        encoded = base64.b64encode(payload).decode("ascii")
        figures.append('<figure><img loading="lazy" alt="' + _escape(name) + '" src="data:image/png;base64,'
                       + encoded + '"><figcaption>' + _escape(name) + '</figcaption></figure>')
    if not figures:
        return '<p class="muted">이 실행에는 표시할 PNG 프레임이 없습니다. 렌더링 상태는 실행 결과에서 확인하세요.</p>'
    suffix = '<p class="muted">최대 8개 프레임을 표시합니다.</p>' if len(entries) > MAX_FRAMES else ""
    return '<div class="frames">' + ''.join(figures) + '</div>' + suffix


def _parallel_frames(output_path: Path, report: dict) -> str:
    collection = report.get("parallel_collection")
    if not isinstance(collection, dict):
        return ""
    root = output_path.parent.resolve()
    rows = report.get("baseline", {}).get("episodes", [])
    entries = []
    for row in rows[:8]:
        if not isinstance(row, dict) or not isinstance(row.get("evidence_directory"), str):
            continue
        candidate = (root / row["evidence_directory"] / "camera_hold.png").resolve()
        if not candidate.is_relative_to(root):
            raise ValueError("parallel images must remain inside this run directory")
        if candidate.is_file():
            entries.append(str(candidate.relative_to(root)))
    summary = ("요청 작업장 " + _escape(collection.get("requested_workers", "미확인"))
               + "개 · 유효 작업장 " + _escape(collection.get("effective_workers", "미확인"))
               + "개 · 관측한 최대 동시 실행 " + _escape(collection.get("max_concurrent_observed", "미확인")) + "개")
    content = '<p>' + summary + '</p>'
    content += '<p>각 작업장은 독립 프로세스의 물리 상태를 사용합니다. 아래는 최대 8개 시연의 완료 장면 기록이며, 기준 제어의 시연 수집과 학습 정책의 성공을 구분합니다. 병렬 작업장 수는 신경망 학습 배치 크기와 다릅니다.</p>'
    content += _images(output_path, entries)
    content += '<details><summary>프로세스와 동시 실행 근거</summary>' + _pre(collection) + '</details>'
    return _section("독립 작업장 실행과 시연 기록", content, collection)


def write_dashboard(output_path: Path, report: dict) -> Path:
    """Render fixed workflow evidence without scripts interpreting report values."""
    path = Path(output_path)
    if path.suffix.lower() != ".html" or not isinstance(report, dict):
        raise ValueError("dashboard requires an HTML output path and object report")
    serialized = _script_json(report)  # Enforces JSON values and finite numbers first.
    intent = report.get("intent_result", {})
    model_report = report.get("model_report", {})
    baseline = report.get("baseline", {})
    training = report.get("training", {})
    policy_evaluation = report.get("policy_evaluation", {})
    response_fit = report.get("response_fit", {})
    if not isinstance(intent, dict) or not isinstance(model_report, dict) or not isinstance(baseline, dict):
        raise ValueError("intent/model/baseline report sections must be objects")
    successes, trials = _count(baseline.get("successes")), _count(baseline.get("trials"))
    baseline_text = f"{successes} / {trials}" if successes is not None and trials is not None else "미확인"
    confidence = _percent(intent.get("confidence"))
    fixture_accuracy = _percent(model_report.get("evaluation_accuracy"))
    if isinstance(policy_evaluation, dict):
        policy_successes, policy_trials = _count(policy_evaluation.get("successes")), _count(policy_evaluation.get("trials"))
        learned_text = f"{policy_successes} / {policy_trials}" if policy_successes is not None and policy_trials is not None else "미실행"
        offline = policy_evaluation.get("offline_test", {})
        mae = offline.get("mae") if isinstance(offline, dict) else None
        mae_text = f"{mae:.5g}" if type(mae) in (int, float) and math.isfinite(mae) else "미실행"
        mae_unit = offline.get("metric_unit", "단위 확인 필요") if isinstance(offline, dict) else "단위 확인 필요"
    else:
        learned_text, mae_text, mae_unit = "미실행", "미실행", "단위 확인 필요"
    cards = (
        ("워크플로 상태", report.get("status", "미확인"), "실행 상태 · 작업 성공은 각 평가 결과로 확인"),
        ("목표 분류", intent.get("intent", "미확인"), "학습 모델 점수 " + confidence),
        ("스크립트 baseline", baseline_text, "시뮬레이션에서 확인한 성공 / 시험 수"),
        ("학습 정책 폐루프", learned_text, "별도 초기 조건의 성공 / 시험 수 · baseline과 구분"),
        ("오프라인 행동 MAE", mae_text, str(mae_unit) + " · 행동 오차는 작업 성공과 다른 지표"),
        ("목표 분류 예시 평가", fixture_accuracy, str(model_report.get("evaluation_examples", "미확인")) + "개 고정 합성 예시 · 일반 성능 아님"),
        ("실기 실행", report.get("physical_execution", "not_run"), "장비 연결·모터 쓰기·실제 이동을 수행하지 않음"),
    )
    card_html = '<div class="cards">' + ''.join(
        '<article><p class="card-label">' + _escape(label) + '</p><strong>' + _escape(value)
        + '</strong><p class="muted">' + _escape(note) + '</p></article>' for label, value, note in cards) + '</div>'
    intent_html = '<p>목표 해석은 로컬에서 학습한 제한된 분류 모델을 사용합니다. 런타임 LLM과 범용 자연어 실행기는 아닙니다.</p>'
    intent_html += '<details open><summary>목표 해석 결과</summary>' + _pre(intent) + '</details>'
    intent_html += '<details><summary>모델 학습과 별도 합성 예시 평가</summary>' + _pre(model_report) + '</details>'
    scene_html = '<p>아래 치수·자산·물리 설정의 제안값은 사용자 장비의 실측값과 구분합니다.</p>' + _pre(report.get("scene_assumptions", {}))
    baseline_html = '<p>baseline은 등록된 스크립트 제어 경로입니다. 학습 정책의 성공으로 해석하지 않습니다.</p>' + _pre(baseline)
    training_html = '<p>행동 라벨을 사용하는 작은 action-chunk 학습 경로입니다. 원 ACT 구현·사용자 checkpoint·실기 전이가 모두 검증되었다는 뜻이 아닙니다.</p>' + _pre(training)
    policy_html = '<p>오프라인 MAE와 폐루프 작업 성공은 다른 지표입니다. 각 실행의 성공·실패·미실행 상태를 확인하세요.</p>' + _pre(policy_evaluation)
    response_html = '<p>합성·시뮬레이션 응답 보정은 해당 데이터에서의 수치 검증입니다. 실제 측정 로그가 없는 상태에서 실제 로봇 보정 성과로 보고하지 않습니다.</p>' + _pre(response_fit)
    trace = report.get("trace", [])
    if not isinstance(trace, list):
        raise ValueError("trace must be a list")
    rows = []
    for index, item in enumerate(trace[:100], start=1):
        if isinstance(item, dict):
            name = item.get("tool", item.get("action", "단계"))
            status = item.get("status", "미확인")
            detail = json.dumps(item, ensure_ascii=False, allow_nan=False)
        else:
            name, status, detail = "단계", "미확인", str(item)
        rows.append('<tr><td>' + str(index) + '</td><td>' + _escape(name) + '</td><td>' + _escape(status)
                    + '</td><td><code>' + _escape(detail) + '</code></td></tr>')
    trace_html = ('<div class="table-scroll"><table><thead><tr><th>순서</th><th>등록 도구</th><th>상태</th><th>근거</th></tr></thead>'
                  + '<tbody>' + ''.join(rows) + '</tbody></table></div>')
    if len(trace) > 100:
        trace_html += '<p class="muted">100개 단계까지 표시합니다. 전체 이력은 아래 원본 JSON에서 확인하세요.</p>'
    limitations = report.get("limitations", [])
    if not isinstance(limitations, list):
        raise ValueError("limitations must be a list")
    limitations_html = '<ul>' + ''.join('<li>' + _escape(value) + '</li>' for value in limitations) + '</ul>'
    body = card_html
    body += _section("목표 해석과 AI 근거", intent_html, model_report)
    body += _section("환경 구성과 가정", scene_html)
    body += _section("등록 도구 실행 이력", trace_html)
    body += _parallel_frames(path, report)
    body += _section("스크립트 baseline 결과", baseline_html, baseline)
    body += _section("행동 정책 학습", training_html, training)
    body += _section("학습 정책 평가", policy_html, policy_evaluation)
    body += _section("제한된 응답 보정", response_html, response_fit)
    body += _section("실제 생성 프레임", _images(path, report.get("image_paths", [])))
    body += _section("현재 한계", limitations_html)
    body += _section("전체 실행 결과", '<details><summary>원본 JSON 보기</summary>' + _pre(report) + '</details>')
    document = '''<!doctype html>
<html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; img-src data:; style-src 'unsafe-inline'; script-src 'none'; base-uri 'none'; form-action 'none'">
<title>SO-101 환경 에이전트 실행 결과</title><style>
:root{color-scheme:dark;--bg:#101620;--panel:#192331;--line:#334358;--text:#edf2f7;--muted:#afbdcf;--accent:#7adebb}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--text);font-family:system-ui,"Malgun Gothic",sans-serif;line-height:1.65}
main{max-width:1160px;margin:auto;padding:40px 24px 64px}header{padding-bottom:24px}header p{max-width:850px;color:var(--muted)}
h1{margin:8px 0;font-size:clamp(25px,4vw,38px);line-height:1.35}h2{font-size:20px;margin:0}p{margin:12px 0}
.eyebrow{color:var(--accent);font-weight:700;letter-spacing:.03em}.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:14px}
article,section{border:1px solid var(--line);background:var(--panel);border-radius:14px;padding:22px}article strong{display:block;font-size:25px;overflow-wrap:anywhere}
section{margin-top:20px}.card-label{margin:0 0 8px;color:var(--muted);font-size:13px}.muted{color:var(--muted);font-size:13px}
.section-heading{display:flex;align-items:center;justify-content:space-between;gap:16px}.badge{border:1px solid #517466;color:var(--accent);border-radius:999px;padding:2px 10px;font-size:12px}
pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#111924;border-radius:8px;padding:16px;max-height:560px;overflow:auto;font-size:12px;line-height:1.65}
summary{cursor:pointer;color:var(--accent);padding:10px 0}code{font-size:12px;overflow-wrap:anywhere}.table-scroll{overflow:auto;margin-top:16px}
table{width:100%;border-collapse:collapse;font-size:13px}th,td{text-align:left;padding:11px;vertical-align:top;border-bottom:1px solid var(--line)}th{color:var(--muted)}
.frames{display:grid;grid-template-columns:repeat(auto-fit,minmax(270px,1fr));gap:14px;margin-top:16px}figure{margin:0}img{display:block;width:100%;height:auto;background:#111924;border-radius:9px}figcaption{font-size:12px;color:var(--muted);margin-top:7px;overflow-wrap:anywhere}
li{margin:8px 0}@media(max-width:600px){main{padding:24px 14px}article,section{padding:16px}.section-heading{align-items:flex-start}.cards{grid-template-columns:1fr 1fr}}
</style></head><body><main><header><div class="eyebrow">SO-101 · 로컬 실행 증거</div><h1>환경 구성에서 실행 결과까지</h1>
<p>시뮬레이션, 합성 데이터, 학습 지표와 실기 검증을 구분해 표시합니다. 이 파일은 외부 자산이나 네트워크 연결 없이 열 수 있습니다.</p></header>'''
    document += body + '</main><script type="application/json" id="report-data">' + serialized + '</script></body></html>\n'
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(document, encoding="utf-8")
    return path
