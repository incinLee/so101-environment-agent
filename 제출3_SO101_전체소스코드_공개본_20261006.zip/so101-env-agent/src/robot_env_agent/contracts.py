"""Explicit draft contracts. Missing measurements remain unknown."""

import math
from dataclasses import asdict, dataclass, field
from typing import Any

JOINT_NAMES = ("shoulder_pan", "shoulder_lift", "elbow_flex", "wrist_flex", "wrist_roll", "gripper")
UNITS = {"deg", "rad", "range_m100_100", "range_0_100"}


@dataclass(frozen=True)
class JointSpec:
    name: str
    command_unit: str | None = None
    model_joint: str | None = None


@dataclass(frozen=True)
class CameraSpec:
    name: str
    device: str | None = None
    width: int | None = None
    height: int | None = None
    fps: float | None = None
    pose: list[float] | None = None


@dataclass(frozen=True)
class RobotInstance:
    label: str
    robot_id: str | None = None
    calibration_ref: str | None = None


@dataclass(frozen=True)
class RobotProfile:
    schema_version: int
    robot_type: str
    instances: tuple[RobotInstance, ...]
    joints: tuple[JointSpec, ...]
    cameras: tuple[CameraSpec, ...]
    use_degrees: bool | None = None
    control_mode: str | None = None
    control_hz: float | None = None
    asset_id: str | None = None
    asset_sha256: str | None = None
    proposed_backend: str | None = None


@dataclass(frozen=True)
class TaskSpec:
    schema_version: int
    task_id: str | None
    object_size_m: list[float] | None = None
    workspace_size_m: list[float] | None = None
    success_height_m: float | None = None
    hold_seconds: float | None = None
    source_tray_bounds_m: list[float] | None = None
    target_tray_bounds_m: list[float] | None = None
    proposal: str | None = None


@dataclass
class ValidationResult:
    execution_kind: str = "static"
    errors: list[str] = field(default_factory=list)
    missing: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {**asdict(self), "draft_status": "failed" if self.errors else "passed",
                "simulation_readiness": "blocked" if self.errors or self.missing else "unsupported",
                "physical_readiness": "unsupported"}


def _strict_fields(data: dict, allowed: set[str], required: set[str], label: str):
    if not isinstance(data, dict):
        raise ValueError(f"{label}: expected object")
    extra, absent = set(data) - allowed, required - set(data)
    if extra or absent:
        raise ValueError(f"{label}: unknown fields {sorted(extra)}, missing fields {sorted(absent)}")


def parse_profile(data: dict) -> RobotProfile:
    _strict_fields(data, set(RobotProfile.__dataclass_fields__),
                   {"schema_version", "robot_type", "instances", "joints", "cameras"}, "profile")
    parsed = dict(data)
    for key, cls in (("instances", RobotInstance), ("joints", JointSpec), ("cameras", CameraSpec)):
        if not isinstance(data[key], list):
            raise ValueError(f"profile.{key}: expected array")
        rows = []
        for row in data[key]:
            required = {"label"} if key == "instances" else {"name"}
            _strict_fields(row, set(cls.__dataclass_fields__), required, f"profile.{key}")
            rows.append(cls(**row))
        parsed[key] = tuple(rows)
    return RobotProfile(**parsed)


def parse_task(data: dict) -> TaskSpec:
    _strict_fields(data, set(TaskSpec.__dataclass_fields__), {"schema_version", "task_id"}, "task")
    return TaskSpec(**data)


def _finite(value: Any) -> bool:
    if type(value) not in (int, float):
        return False
    try:
        return math.isfinite(value)
    except OverflowError:
        return False


def _positive(value: Any) -> bool:
    return _finite(value) and value > 0


def _bounds(value: Any) -> bool:
    return (isinstance(value, list) and len(value) == 6
            and all(_finite(item) for item in value)
            and all(value[index] < value[index + 3] for index in range(3)))


def validate(profile: RobotProfile, task: TaskSpec) -> ValidationResult:
    result = ValidationResult()
    def optional(path, value, condition):
        if value is None:
            result.missing.append(path)
        elif not condition(value):
            result.errors.append(path)
    if type(profile.schema_version) is not int or profile.schema_version != 1:
        result.errors.append("profile.schema_version")
    if type(task.schema_version) is not int or task.schema_version != 1:
        result.errors.append("task.schema_version")
    if profile.robot_type != "so101_follower":
        result.errors.append("profile.robot_type: unsupported robot")
    names = [joint.name for joint in profile.joints]
    if tuple(names) != JOINT_NAMES:
        result.errors.append("profile.joints: joint names/order must match the SO-101 contract")
    mapped_joints = [joint.model_joint for joint in profile.joints if isinstance(joint.model_joint, str)]
    if len(mapped_joints) != len(set(mapped_joints)):
        result.errors.append("profile.joints: duplicate model joint mapping")
    if not profile.instances:
        result.errors.append("profile.instances: at least one instance required")
    labels = [instance.label for instance in profile.instances]
    if any(not isinstance(label, str) or not label for label in labels) or len(set(map(str, labels))) != len(labels):
        result.errors.append("profile.instances: invalid or duplicate labels")
    for instance in profile.instances:
        optional(f"instances.{instance.label}.robot_id", instance.robot_id,
                 lambda value: isinstance(value, str) and bool(value))
        optional(f"instances.{instance.label}.calibration_ref", instance.calibration_ref,
                 lambda value: isinstance(value, str) and bool(value))
    optional("profile.use_degrees", profile.use_degrees, lambda value: type(value) is bool)
    optional("profile.control_mode", profile.control_mode, lambda value: value == "absolute_joint_position")
    optional("profile.control_hz", profile.control_hz, _positive)
    for joint in profile.joints:
        optional(f"joints.{joint.name}.command_unit", joint.command_unit,
                 lambda value: isinstance(value, str) and value in UNITS)
        optional(f"joints.{joint.name}.model_joint", joint.model_joint,
                 lambda value: isinstance(value, str) and bool(value))
        if joint.command_unit is not None:
            expected = "range_0_100" if joint.name == "gripper" else (
                "deg" if profile.use_degrees is True else "range_m100_100")
            if (joint.name == "gripper" or profile.use_degrees is not None) and joint.command_unit != expected:
                result.errors.append(f"joints.{joint.name}: incompatible LeRobot command unit")
    camera_names = [camera.name for camera in profile.cameras]
    if any(not isinstance(name, str) or not name for name in camera_names) or len(set(map(str, camera_names))) != len(camera_names):
        result.errors.append("profile.cameras: invalid or duplicate camera names")
    if not profile.cameras:
        result.missing.append("profile.cameras")
    for camera in profile.cameras:
        optional(f"cameras.{camera.name}.device", camera.device, lambda value: isinstance(value, str) and bool(value))
        for name in ("width", "height"):
            optional(f"cameras.{camera.name}.{name}", getattr(camera, name),
                     lambda value: type(value) is int and value > 0)
        optional(f"cameras.{camera.name}.fps", camera.fps, _positive)
        optional(f"cameras.{camera.name}.pose", camera.pose,
                 lambda value: isinstance(value, list) and len(value) == 6
                 and all(_finite(item) for item in value))
    optional("profile.asset_id", profile.asset_id, lambda value: isinstance(value, str) and bool(value))
    optional("profile.asset_sha256", profile.asset_sha256,
             lambda value: isinstance(value, str) and len(value) == 64
             and all(char in "0123456789abcdef" for char in value))
    optional("task.task_id", task.task_id, lambda value: value in ("block_lift", "tray_transfer"))
    for name in ("object_size_m", "workspace_size_m"):
        optional(f"task.{name}", getattr(task, name),
                 lambda value: isinstance(value, list) and len(value) == 3 and all(_positive(item) for item in value))
    if task.task_id == "block_lift":
        optional("task.success_height_m", task.success_height_m, _positive)
    elif task.success_height_m is not None and not _positive(task.success_height_m):
        result.errors.append("task.success_height_m")
    if task.task_id == "tray_transfer":
        optional("task.source_tray_bounds_m", task.source_tray_bounds_m, _bounds)
        optional("task.target_tray_bounds_m", task.target_tray_bounds_m, _bounds)
    optional("task.hold_seconds", task.hold_seconds, _positive)
    return result
