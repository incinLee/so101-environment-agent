from .cli import main

if __name__ == "__main__":
    # Spawned Windows workers import the entry module without re-running CLI.
    import multiprocessing
    multiprocessing.freeze_support()
    raise SystemExit(main())
