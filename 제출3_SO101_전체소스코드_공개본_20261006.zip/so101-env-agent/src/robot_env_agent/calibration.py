"""Read-only calibration ZIP inspection, without device or simulator imports.

The accepted JSON shape matches LeRobot's MotorCalibration fields. drive_mode
accepts 0 and 1 as direction-bit values; its physical meaning is not verified.
Ranges contain encoder counts, not a declaration of runtime angle units.
Only JSON members are read, with ZIP CRC verification during each read. Other
members are ignored, although their declared sizes count toward the budget.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path, PurePosixPath
import stat
import zipfile
import zlib


MAX_UNCOMPRESSED_BYTES = 2 * 1024 * 1024
MAX_ARCHIVE_MEMBERS = 1024
NARROW_RANGE_COUNTS = 200
JOINTS = (
    "shoulder_pan", "shoulder_lift", "elbow_flex",
    "wrist_flex", "wrist_roll", "gripper",
)
FIELDS = {"id", "drive_mode", "homing_offset", "range_min", "range_max"}


class CalibrationArchiveError(ValueError):
    """An archive cannot safely be inspected; no candidate is selected."""


class _DuplicateJSONKey(ValueError):
    pass


def _unique_object(pairs: list[tuple[str, object]]) -> dict:
    result = {}
    for key, value in pairs:
        if key in result:
            raise _DuplicateJSONKey("Duplicate JSON object key")
        result[key] = value
    return result


def _validate_member(info: zipfile.ZipInfo) -> None:
    # ZipInfo normalizes backslashes on Windows and truncates embedded NULs.
    # Validate the original archive name, not that normalized presentation.
    name = info.orig_filename
    clean = name[:-1] if name.endswith("/") else name
    if (
        not clean or "\\" in name or ":" in name or "\x00" in name
        or PurePosixPath(name).is_absolute()
        or any(part in {"", ".", ".."} for part in clean.split("/"))
    ):
        raise CalibrationArchiveError("Archive contains an unsafe member path")
    if info.flag_bits & 1:
        raise CalibrationArchiveError("Encrypted archive members are unsupported")
    if stat.S_ISLNK(info.external_attr >> 16):
        raise CalibrationArchiveError("Symbolic-link archive members are unsupported")


def _role(member: str) -> str:
    parts = set(PurePosixPath(member).parts[:-1])
    follower = bool(parts & {"so101_follower", "so100_follower", "so_follower"})
    leader = bool(parts & {"so101_leader", "so100_leader", "so_leader"})
    if follower and not leader:
        return "follower"
    if leader and not follower:
        return "leader"
    return "unknown"


def _issue(severity: str, code: str, message: str, joint: str | None = None) -> dict:
    result = {"severity": severity, "code": code, "message": message}
    if joint is not None:
        result["joint"] = joint
    return result


def _validate_calibration(data: object) -> tuple[list[dict], dict]:
    issues: list[dict] = []
    spans: dict[str, int] = {}
    if not isinstance(data, dict):
        return [_issue("error", "invalid_root", "Calibration must be an object")], spans
    if set(data) != set(JOINTS):
        issues.append(_issue("error", "joint_set", "Exactly six SO-101 joint keys are required"))
    for expected_id, joint in enumerate(JOINTS, start=1):
        if joint not in data:
            continue
        entry = data[joint]
        if not isinstance(entry, dict) or set(entry) != FIELDS:
            issues.append(_issue("error", "field_set", "Exactly five calibration fields are required", joint))
            continue
        if any(type(value) is not int for value in entry.values()):
            issues.append(_issue("error", "integer_fields", "All fields must be integers; Boolean values are invalid", joint))
            continue
        if entry["id"] != expected_id:
            issues.append(_issue("error", "motor_id", "Motor ID does not match the SO-101 joint mapping", joint))
        if entry["drive_mode"] not in (0, 1):
            issues.append(_issue("error", "drive_mode", "drive_mode must be the direction bit 0 or 1", joint))
        lower, upper = entry["range_min"], entry["range_max"]
        spans[joint] = upper - lower
        if not 0 <= lower < upper <= 4095:
            issues.append(_issue("error", "encoder_range", "Required encoder range: 0 <= min < max <= 4095", joint))
        elif upper - lower <= NARROW_RANGE_COUNTS:
            issues.append(_issue("warning", "narrow_range", "Narrow recorded range needs context; it is not automatically invalid", joint))
        elif lower == 0 and upper == 4095 and joint != "wrist_roll":
            issues.append(_issue("warning", "full_encoder_span", "Full encoder span on this joint needs physical context", joint))
    return issues, spans


def inspect_archive(path: Path) -> dict:
    """Inspect a ZIP; return evidence without extracting or selecting a robot.

    Malformed JSON/schema produces a failed candidate. Unsafe archives, excessive
    sizes, encryption, symlinks and JSON-member CRC failures raise
    CalibrationArchiveError. A passed candidate is structurally valid only.
    Candidate ``role`` comes from folder names, and ``id`` is the filename stem;
    neither proves the current device identity or its role.
    """
    candidates: list[dict] = []
    warnings = [
        _issue("warning", "physical_state_unverified", "File inspection does not verify physical calibration or motion"),
        _issue("warning", "normalization_unverified", "Runtime use_degrees and normalization cannot be inferred from calibration fields"),
        _issue("warning", "arm_mapping_unverified", "Current physical arm A/B mapping requires separate evidence; no candidate is automatically selected"),
    ]
    try:
        with Path(path).open("rb") as source:
            digest = hashlib.sha256()
            for chunk in iter(lambda: source.read(65536), b""):
                digest.update(chunk)
            source.seek(0)
            with zipfile.ZipFile(source) as archive:
                members = archive.infolist()
                if len(members) > MAX_ARCHIVE_MEMBERS:
                    raise CalibrationArchiveError("Archive member-count budget exceeded")
                for member in members:
                    _validate_member(member)
                total_bytes = sum(member.file_size for member in members)
                if total_bytes > MAX_UNCOMPRESSED_BYTES:
                    raise CalibrationArchiveError("Archive exceeds the 2 MiB uncompressed budget")
                names = [member.filename for member in members]
                if len(names) != len(set(names)):
                    raise CalibrationArchiveError("Archive contains duplicate member paths")
                for member in members:
                    if member.is_dir() or PurePosixPath(member.filename).suffix.lower() != ".json":
                        continue
                    raw = archive.read(member)  # ZipFile verifies this member's CRC.
                    if len(raw) != member.file_size:
                        raise CalibrationArchiveError("Archive member size does not match metadata")
                    candidate = {
                        "path": member.filename,
                        "role": _role(member.filename),
                        "id": PurePosixPath(member.filename).stem,
                        "sha256": hashlib.sha256(raw).hexdigest(),
                        "issues": [],
                        "range_spans": {},
                    }
                    try:
                        decoded = json.loads(raw.decode("utf-8-sig"), object_pairs_hook=_unique_object)
                        candidate["issues"], candidate["range_spans"] = _validate_calibration(decoded)
                    except _DuplicateJSONKey:
                        candidate["issues"] = [_issue("error", "duplicate_json_key", "Duplicate JSON object keys are rejected")]
                    except (ValueError, RecursionError):
                        candidate["issues"] = [_issue("error", "invalid_json", "Member is not a supported UTF-8 JSON document")]
                    candidate["validation_status"] = (
                        "failed" if any(issue["severity"] == "error" for issue in candidate["issues"]) else "passed"
                    )
                    candidates.append(candidate)
    except CalibrationArchiveError:
        raise
    except (OSError, zipfile.BadZipFile, RuntimeError, NotImplementedError, EOFError, zlib.error) as exc:
        raise CalibrationArchiveError("Archive read or CRC verification failed") from exc

    by_hash: dict[str, list[str]] = {}
    by_id: dict[tuple[str, str], list[dict]] = {}
    for candidate in candidates:
        by_hash.setdefault(candidate["sha256"], []).append(candidate["path"])
        by_id.setdefault((candidate["role"], candidate["id"]), []).append(candidate)
    duplicate_groups = [
        {"sha256": checksum, "paths": paths}
        for checksum, paths in by_hash.items() if len(paths) > 1
    ]
    for entries in by_id.values():
        if len({entry["sha256"] for entry in entries}) > 1:
            warnings.append({
                **_issue("warning", "conflicting_id", "The same folder-derived role and filename ID have different calibration contents"),
                "paths": [entry["path"] for entry in entries],
            })
    if not candidates:
        warnings.append(_issue("warning", "no_json_candidates", "Archive contains no JSON calibration candidates"))
    if any(candidate["role"] == "leader" for candidate in candidates):
        warnings.append(_issue("warning", "leader_candidates", "Leader-folder files do not establish that a physical leader is available"))
    summary = {
        "total": len(candidates),
        "passed": sum(candidate["validation_status"] == "passed" for candidate in candidates),
        "failed": sum(candidate["validation_status"] == "failed" for candidate in candidates),
        "followers": sum(candidate["role"] == "follower" for candidate in candidates),
        "leaders": sum(candidate["role"] == "leader" for candidate in candidates),
        "unknown_roles": sum(candidate["role"] == "unknown" for candidate in candidates),
        "archive_members": len(members),
        "directories": sum(member.is_dir() for member in members),
        "ignored_files": sum(not member.is_dir() and PurePosixPath(member.filename).suffix.lower() != ".json" for member in members),
        "total_uncompressed_bytes": total_bytes,
        "candidate_warnings": sum(issue["severity"] == "warning" for candidate in candidates for issue in candidate["issues"]),
    }
    return {
        "source_sha256": digest.hexdigest(),
        "summary": summary,
        "candidates": candidates,
        "duplicate_groups": duplicate_groups,
        "warnings": warnings,
        "selected_candidate": None,
        "execution_kind": "static",
    }
