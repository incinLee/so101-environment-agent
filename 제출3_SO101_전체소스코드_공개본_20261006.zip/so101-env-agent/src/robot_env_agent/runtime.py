"""Bounded development workflow and an explicitly synthetic backend."""

import hashlib
import json
from dataclasses import asdict
from pathlib import Path
from typing import Any, Protocol

from .contracts import RobotProfile, TaskSpec, parse_profile, parse_task, validate


def fingerprint(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                    allow_nan=False, separators=(",", ":")).encode()).hexdigest()


class SimulationBackend(Protocol):
    def reset(self) -> dict: ...
    def step(self, requested_action: dict) -> dict: ...


class PolicyAdapter(Protocol):
    def predict(self, observation: dict) -> dict: ...


class ToolExecutor:
    """Only registered in-process functions can run; no shell or device adapter."""
    def __init__(self, tools: dict, max_calls: int = 3):
        if type(max_calls) is not int or not 1 <= max_calls <= 10:
            raise ValueError("tool budget must be 1 through 10")
        self.tools, self.max_calls, self.trace = tools, max_calls, []

    def call(self, name: str, **kwargs):
        if name not in self.tools:
            raise PermissionError(f"unregistered tool: {name}")
        if len(self.trace) >= self.max_calls:
            raise RuntimeError("tool budget exhausted")
        self.trace.append({"tool": name, "status": "started"})
        try:
            result = self.tools[name](**kwargs)
        except Exception:
            self.trace[-1]["status"] = "failed"
            raise
        self.trace[-1]["status"] = "passed"
        return result


def resolve_path(root: Path, path: str) -> Path:
    root = root.resolve()
    raw = Path(path)
    candidate = (raw if raw.is_absolute() else root / raw).resolve()
    if not candidate.is_relative_to(root) or ".git" in candidate.relative_to(root).parts:
        raise PermissionError("path must stay inside the project and outside .git")
    return candidate


def resolve_output(root: Path, path: str) -> Path:
    candidate = resolve_path(root, path)
    parts = candidate.relative_to(root.resolve()).parts
    if len(parts) < 2 or parts[0] != "runs" or candidate.suffix.lower() != ".json":
        raise PermissionError("outputs must be JSON files inside runs; source files remain read-only")
    return candidate


def _duplicate_safe(pairs):
    data = {}
    for key, value in pairs:
        if key in data:
            raise ValueError(f"duplicate JSON key: {key}")
        data[key] = value
    return data


def read_json(path: Path) -> dict:
    if path.stat().st_size > 1_048_576:
        raise ValueError("JSON file exceeds the 1MiB budget")
    data = json.loads(path.read_text(encoding="utf-8-sig"), object_pairs_hook=_duplicate_safe,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError(f"invalid number: {value}")))
    if not isinstance(data, dict):
        raise ValueError("expected JSON object")
    return data


def write_json(path: Path, value: dict):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def plan(profile: RobotProfile, task: TaskSpec) -> dict:
    validation = validate(profile, task).to_dict()
    if validation["errors"]:
        next_action = "correct_invalid_configuration"
    elif validation["missing"]:
        next_action = "build_draft_and_collect_missing_inputs"
    else:
        next_action = "verify_physical_mapping_before_simulator_profile_integration"
    return {"execution_kind": "static", "planner_kind": "deterministic_development_planner",
            "llm_used": False, "goal": "construct_validate_calibrate_environment",
            "next_action": next_action, "validation": validation,
            "allowed_tools": ["validate_inputs", "build_draft", "validate_bundle"],
            "command_scope": "physical_profile_intake_and_declarative_draft; use demo for assumed MuJoCo execution",
            "not_implemented": ["runtime_llm", "original_act_image_cvae", "physical_runner"],
            "measurement_tasks": ["map_physical_arms_to_calibration_files", "confirm_command_units",
                                  "measure_task_and_camera_configuration", "collect_timestamped_motion_logs"]}


def _build(profile: RobotProfile, task: TaskSpec) -> dict:
    # Dataclass tuples become JSON arrays before both in-memory and disk checks.
    p = json.loads(json.dumps(asdict(profile), allow_nan=False))
    t = json.loads(json.dumps(asdict(task), allow_nan=False))
    return {"schema_version": 1, "execution_kind": "draft", "robot_profile": p, "task": t,
            "profile_sha256": fingerprint(p), "task_sha256": fingerprint(t),
            "evaluation_sha256": fingerprint(t),
            "simulation_status": "not_run", "physical_status": "not_run",
            "physics_asset_included": False,
            "limitations": ["declarative draft only", "no generated or verified robot geometry",
                            "no physics, ACT or physical execution"]}


def validate_bundle(bundle: dict) -> dict:
    expected_keys = {"schema_version", "execution_kind", "robot_profile", "task",
                     "profile_sha256", "task_sha256", "evaluation_sha256", "simulation_status",
                     "physical_status", "physics_asset_included", "limitations"}
    if set(bundle) != expected_keys or type(bundle["schema_version"]) is not int or bundle["schema_version"] != 1:
        raise ValueError("unexpected bundle schema")
    if bundle["execution_kind"] != "draft" or bundle["physics_asset_included"] is not False:
        raise ValueError("this backend only accepts drafts without physical assets")
    for data_key, hash_key in (("robot_profile", "profile_sha256"), ("task", "task_sha256"), ("task", "evaluation_sha256")):
        if fingerprint(bundle[data_key]) != bundle[hash_key]:
            raise ValueError(f"bundle integrity mismatch: {hash_key}")
    if bundle["simulation_status"] != "not_run" or bundle["physical_status"] != "not_run":
        raise ValueError("draft cannot claim executed simulation or physical results")
    return validate(parse_profile(bundle["robot_profile"]), parse_task(bundle["task"])).to_dict()


def build_draft(profile: RobotProfile, task: TaskSpec) -> tuple[dict, dict]:
    executor = ToolExecutor({"validate_inputs": validate, "build_draft": _build,
                             "validate_bundle": validate_bundle})
    validation = executor.call("validate_inputs", profile=profile, task=task)
    if validation.errors:
        raise ValueError("invalid draft: " + "; ".join(validation.errors))
    bundle = executor.call("build_draft", profile=profile, task=task)
    report = executor.call("validate_bundle", bundle=bundle)
    return bundle, {"execution_kind": "static", "validation": report, "tool_trace": executor.trace}


class MockBackend:
    """Tests reset/step orchestration only; it computes no physical trajectories."""
    def __init__(self):
        self.step_count = 0

    def reset(self):
        self.step_count = 0
        return {"execution_kind": "mock", "step": 0, "measured_joint_state": None}

    def step(self, requested_action: dict):
        if requested_action != {"operation": "noop"}:
            raise ValueError("mock only accepts noop; no motor commands")
        self.step_count += 1
        return {"execution_kind": "mock", "step": self.step_count,
                "requested_action": requested_action, "transmitted_command": None,
                "measured_joint_state": None, "task_success": None}


def run_mock(bundle: dict, steps: int = 3) -> dict:
    if type(steps) is not int or not 1 <= steps <= 20:
        raise ValueError("mock steps must be 1 through 20")
    validation = validate_bundle(bundle)
    if validation["errors"]:
        raise ValueError("invalid draft configuration")
    backend = MockBackend()
    initial = backend.reset()
    records = [backend.step({"operation": "noop"}) for _ in range(steps)]
    return {"execution_kind": "mock", "status": "passed", "initial_observation": initial,
            "records": records, "scope": "synthetic reset/step control flow only",
            "simulation_status": "not_run", "physical_status": "not_run",
            "task_success": None, "real_calibration_improvement": None,
            "evaluation_sha256": bundle["evaluation_sha256"], "validation": validation}
