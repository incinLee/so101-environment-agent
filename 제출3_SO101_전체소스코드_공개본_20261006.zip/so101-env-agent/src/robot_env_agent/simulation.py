"""Actual MuJoCo physics with an explicitly scripted, assumption-based baseline.

No robot ports, motor writes, policy inference, welds or object teleportation are
used. The public SO-101 model is preserved separately from generated task XML.
"""
from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path
import shutil
import struct
import time
import xml.etree.ElementTree as ET
import zlib

from .contracts import JOINT_NAMES


DEFAULT_SCENE = {
    "schema_version": 1, "task_id": "tray_transfer",
    "object_size_m": [0.03, 0.03, 0.03], "object_mass_kg": 0.02,
    "table_size_m": [0.60, 0.40, 0.05], "tray_size_m": [0.12, 0.10, 0.02],
    "source_center_m": [0.20, -0.07], "target_center_m": [0.20, 0.07],
    "timestep_s": 0.002, "control_hz": 30, "hold_seconds": 1.0, "seed": 0,
}
ASSET_ROOT = Path(__file__).resolve().parents[2] / "assets" / "robotstudio_so101"


def _hash(value) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                     allow_nan=False, separators=(",", ":")).encode()).hexdigest()


def _number(value) -> bool:
    if type(value) not in (int, float):
        return False
    try:
        return math.isfinite(value)
    except OverflowError:
        return False


def validate_scene(scene: dict) -> dict:
    if not isinstance(scene, dict) or set(scene) - set(DEFAULT_SCENE):
        raise ValueError("unexpected scene fields")
    resolved = json.loads(json.dumps({**DEFAULT_SCENE, **scene}, allow_nan=False))
    if type(resolved["schema_version"]) is not int or resolved["schema_version"] != 1:
        raise ValueError("unsupported scene schema")
    if resolved["task_id"] != "tray_transfer":
        raise ValueError("this simulator supports tray_transfer only")
    for name in ("object_size_m", "table_size_m", "tray_size_m"):
        value = resolved[name]
        if not isinstance(value, list) or len(value) != 3 or not all(_number(x) and 0.001 <= x <= 1 for x in value):
            raise ValueError(f"invalid {name}")
    for name in ("source_center_m", "target_center_m"):
        value = resolved[name]
        if not isinstance(value, list) or len(value) != 2 or not all(_number(x) and abs(x) <= 0.5 for x in value):
            raise ValueError(f"invalid {name}")
    for name, lower, upper in (("object_mass_kg", 0.001, 0.2), ("timestep_s", 0.001, 0.01),
                               ("control_hz", 1, 100), ("hold_seconds", 0.1, 5)):
        value = resolved[name]
        if not _number(value) or not lower <= value <= upper:
            raise ValueError(f"invalid {name}")
    if type(resolved["seed"]) is not int or not 0 <= resolved["seed"] <= 2**32 - 1:
        raise ValueError("invalid seed")
    substeps = round(1/(resolved["control_hz"]*resolved["timestep_s"]))
    if not 1 <= substeps <= 100:
        raise ValueError("control_hz/timestep requires unsupported physics substeps")
    if any(resolved["object_size_m"][i] >= resolved["tray_size_m"][i] - 0.012 for i in (0, 1)):
        raise ValueError("part must fit inside the tray with wall clearance")
    sx, sy = resolved["source_center_m"]
    tx, ty = resolved["target_center_m"]
    width, depth, _ = resolved["tray_size_m"]
    if abs(sx - tx) < width and abs(sy - ty) < depth:
        raise ValueError("source and target trays overlap")
    table_x, table_y, _ = resolved["table_size_m"]
    for cx, cy in (resolved["source_center_m"], resolved["target_center_m"]):
        if abs(cx - 0.15) + width / 2 > table_x / 2 or abs(cy) + depth / 2 > table_y / 2:
            raise ValueError("tray must remain on the tabletop")
    return resolved


def _vec(values) -> str:
    return " ".join(format(x, ".9g") for x in values)


def _camera_axes(position, target):
    def norm(v):
        magnitude = math.sqrt(sum(x*x for x in v))
        return [x/magnitude for x in v]
    def cross(a, b):
        return [a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0]]
    z = norm([a-b for a, b in zip(position, target)])
    x = norm(cross([0, 0, 1], z))
    return x + cross(z, x)


def _verify_asset_directory(directory: Path, provenance: dict):
    if provenance.get("license") != "Apache-2.0" or len(provenance.get("source_commit", "")) != 40:
        raise ValueError("model license and fixed source commit must be recorded")
    for item in provenance["downloaded_files"]:
        raw = Path(item["path"])
        path = (directory / raw).resolve()
        if raw.is_absolute() or not path.is_relative_to(directory.resolve()):
            raise ValueError("invalid public asset manifest path")
        if hashlib.sha256(path.read_bytes()).hexdigest() != item["sha256"]:
            raise ValueError(f"public asset hash mismatch: {item['path']}")


def _verified_assets() -> dict:
    provenance = json.loads((ASSET_ROOT / "provenance.json").read_text(encoding="utf-8"))
    _verify_asset_directory(ASSET_ROOT, provenance)
    return provenance


def build_world(output_dir: Path, scene: dict) -> dict:
    """Generate a portable scene under output_dir; all numbers are assumptions."""
    scene = validate_scene(scene)
    provenance = _verified_assets()
    output_dir = Path(output_dir).resolve()
    if output_dir == ASSET_ROOT.resolve() or output_dir.is_relative_to(ASSET_ROOT.resolve()):
        raise ValueError("generated worlds must not overwrite original assets")
    output_dir.mkdir(parents=True, exist_ok=True)
    if (output_dir/"scene.xml").exists() or (output_dir/"scene_manifest.json").exists():
        raise ValueError("world evidence already exists; use a new run directory")
    robot_dir = output_dir / "robot"
    if robot_dir.exists():
        raise ValueError("world directory already contains a robot; use a new run directory")
    shutil.copytree(ASSET_ROOT, robot_dir)
    tree = ET.parse(robot_dir / "so101.xml")
    root = tree.getroot()
    root.insert(0, ET.Comment(" Generated derivative: SO-101 source unchanged in robot/; tray_transfer task, tool site, camera and timestep added. "))
    root.set("model", "so101_tray_transfer_assumptions")
    root.find("compiler").set("meshdir", "robot/assets")
    root.find("option").set("timestep", str(scene["timestep_s"]))
    visual = root.find("visual")
    ET.SubElement(visual, "global", offwidth="640", offheight="480")
    body = root.find("worldbody")
    ET.SubElement(body, "light", pos="0.15 -0.3 0.8", dir="0 0 -1", diffuse="0.9 0.9 0.9")
    camera_position = [0.52, -0.55, 0.45]
    ET.SubElement(body, "camera", name="front", pos=_vec(camera_position),
                  xyaxes=_vec(_camera_axes(camera_position, [0.17, 0, 0.12])), fovy="48")
    sx, sy, sz = scene["table_size_m"]
    ET.SubElement(body, "geom", name="table", type="box", pos=_vec([0.15, 0, -sz/2]),
                  size=_vec([sx/2, sy/2, sz/2]), rgba="0.30 0.34 0.39 1", friction="0.8 0.01 0.001")
    width, depth, height = scene["tray_size_m"]
    wall, floor = 0.003, 0.003
    for name, center, rgba in (("source", scene["source_center_m"], "0.22 0.48 0.75 1"),
                               ("target", scene["target_center_m"], "0.22 0.65 0.42 1")):
        tray = ET.SubElement(body, "body", name=f"{name}_tray", pos=_vec([*center, 0]))
        for suffix, pos, size in (("floor", [0, 0, floor/2], [width/2, depth/2, floor/2]),
                                   ("left", [-width/2+wall/2, 0, height/2], [wall/2, depth/2, height/2]),
                                   ("right", [width/2-wall/2, 0, height/2], [wall/2, depth/2, height/2]),
                                   ("near", [0, -depth/2+wall/2, height/2], [width/2, wall/2, height/2]),
                                   ("far", [0, depth/2-wall/2, height/2], [width/2, wall/2, height/2])):
            ET.SubElement(tray, "geom", name=f"{name}_{suffix}", type="box", pos=_vec(pos),
                          size=_vec(size), rgba=rgba, friction="0.8 0.01 0.001")
    object_size = scene["object_size_m"]
    part = ET.SubElement(body, "body", name="part", pos=_vec([*scene["source_center_m"], floor+object_size[2]/2+0.001]))
    ET.SubElement(part, "freejoint", name="part_free")
    ET.SubElement(part, "geom", name="part_geom", type="box", size=_vec([x/2 for x in object_size]),
                  mass=str(scene["object_mass_kg"]), rgba="0.95 0.35 0.08 1", contype="2",
                  conaffinity="1", condim="6", friction="1 0.005 0.0005", solref="0.01 1")
    gripper = root.find(".//body[@name='gripper']")
    ET.SubElement(gripper, "site", name="baseline_tcp", pos="0.0085 -0.000218 -0.09", size="0.002", rgba="0 1 1 1")
    world_path = output_dir / "scene.xml"
    tree.write(world_path, encoding="utf-8", xml_declaration=True)
    manifest = {"schema_version": 1, "execution_kind": "simulation_asset", "scene": scene,
                "scene_sha256": _hash(scene), "world_sha256": hashlib.sha256(world_path.read_bytes()).hexdigest(),
                "asset_provenance": provenance, "active_arms": 1, "physical_status": "not_run",
                "real_robot_match_verified": False, "measurement_source": "simulation_assumptions",
                "assumptions": ["Task dimensions, mass, friction, camera and timing are design assumptions.",
                                "SO-101 geometry/dynamics/gains are a pinned upstream public model, not calibrated to the user's arms.",
                                "The second physical follower is reserved for later comparison; absent from this scene.",
                                "No calibration archive is automatically chosen or applied."],
                "generated_changes": ["task trays/table/free part", "front camera and TCP site", "2ms default timestep"]}
    (output_dir / "scene_manifest.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False)+"\n", encoding="utf-8")
    return {**manifest, "world_path": str(world_path), "manifest_path": str(output_dir / "scene_manifest.json")}


def _dependencies():
    try:
        import mujoco
        import numpy as np
    except ImportError as exc:
        raise RuntimeError("install the isolated simulation dependencies before running MuJoCo") from exc
    return mujoco, np


def _png(path: Path, pixels):
    height, width, channels = pixels.shape
    if channels != 3:
        raise ValueError("RGB camera pixels required")
    def chunk(kind, payload):
        return struct.pack(">I", len(payload))+kind+payload+struct.pack(">I", zlib.crc32(kind+payload)&0xffffffff)
    body = b"".join(b"\0"+pixels[row].tobytes() for row in range(height))
    path.write_bytes(b"\x89PNG\r\n\x1a\n"+chunk(b"IHDR", struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0))
                     +chunk(b"IDAT", zlib.compress(body, 6))+chunk(b"IEND", b""))


class MuJoCoBackend:
    """Position controls in model radians; no LeRobot normalization is assumed."""
    def __init__(self, world_path: Path):
        self.mujoco, self.np = _dependencies()
        self.model = self.mujoco.MjModel.from_xml_path(str(Path(world_path).resolve()))
        self.data = self.mujoco.MjData(self.model)
        self.joint_ids = [self.mujoco.mj_name2id(self.model, self.mujoco.mjtObj.mjOBJ_JOINT, name) for name in JOINT_NAMES]
        self.addresses = self.model.jnt_qposadr[self.joint_ids]
        self.dof_addresses = self.model.jnt_dofadr[self.joint_ids]
        self.actuator_ids = [self.mujoco.mj_name2id(self.model, self.mujoco.mjtObj.mjOBJ_ACTUATOR, name) for name in JOINT_NAMES]
        self.part_id = self.mujoco.mj_name2id(self.model, self.mujoco.mjtObj.mjOBJ_BODY, "part")
        self.site_id = self.mujoco.mj_name2id(self.model, self.mujoco.mjtObj.mjOBJ_SITE, "baseline_tcp")
        if min(self.joint_ids+self.actuator_ids+[self.part_id, self.site_id]) < 0:
            raise ValueError("world does not contain the expected SO-101 task model")

    def reset(self, seed: int | None = None):
        self.mujoco.mj_resetData(self.model, self.data)
        self.data.qpos[self.addresses] = [0, -0.4, 0.7, 0.8, 0, 0.9]
        if seed is not None:
            if type(seed) is not int or not 0 <= seed <= 2**32-1:
                raise ValueError("invalid reset seed")
            part_joint = self.mujoco.mj_name2id(self.model, self.mujoco.mjtObj.mjOBJ_JOINT, "part_free")
            part_address = self.model.jnt_qposadr[part_joint]
            # Assumed reset distribution, never a physical measurement or post-reset teleport.
            self.data.qpos[part_address:part_address+2] += self.np.random.default_rng(seed).uniform(-0.002, 0.002, 2)
        self.data.ctrl[self.actuator_ids] = self.data.qpos[self.addresses]
        self.mujoco.mj_forward(self.model, self.data)
        return self.observe()

    def observe(self):
        return {"timestamp_s": float(self.data.time), "joint_position_rad": self.data.qpos[self.addresses].tolist(),
                "joint_velocity_rad_s": self.data.qvel[self.dof_addresses].tolist(),
                "part_position_m": self.data.xpos[self.part_id].tolist(), "contacts_count": int(self.data.ncon)}

    def step(self, requested_action_rad, substeps=1):
        action = self.np.asarray(requested_action_rad, dtype=float)
        if action.shape != (6,) or not self.np.isfinite(action).all():
            raise ValueError("expected six finite model-radian position controls")
        limits = self.model.actuator_ctrlrange[self.actuator_ids]
        if ((action < limits[:, 0]) | (action > limits[:, 1])).any():
            raise ValueError("position control outside the public model limits")
        if type(substeps) is not int or not 1 <= substeps <= 100:
            raise ValueError("substeps must be 1 through 100")
        self.data.ctrl[self.actuator_ids] = action
        for _ in range(substeps):
            self.mujoco.mj_step(self.model, self.data)
            if not self.np.isfinite(self.data.qpos).all() or not self.np.isfinite(self.data.qvel).all():
                raise RuntimeError("nonfinite MuJoCo state")
        return self.observe()


def _ik(backend, target, seed_q, scratch, iterations=35):
    """Five-joint damped IK; point negative local Z downward; command jaw separately."""
    mj, np, model = backend.mujoco, backend.np, backend.model
    scratch.qpos[:] = backend.data.qpos
    scratch.qpos[backend.addresses] = seed_q
    jp, jr = np.zeros((3, model.nv)), np.zeros((3, model.nv))
    limits = model.jnt_range[backend.joint_ids[:5]]
    for _ in range(iterations):
        mj.mj_forward(model, scratch)
        delta = np.asarray(target)-scratch.site_xpos[backend.site_id]
        axis = scratch.site_xmat[backend.site_id].reshape(3, 3)[:, 2]
        orientation = np.cross(axis, [0, 0, 1])
        error = np.concatenate([delta, 0.08*orientation])
        if np.linalg.norm(delta) < 0.0008 and np.linalg.norm(orientation) < 0.015:
            break
        mj.mj_jacSite(model, scratch, jp, jr, backend.site_id)
        jac = np.vstack([jp[:, backend.dof_addresses[:5]], 0.08*jr[:, backend.dof_addresses[:5]]])
        dq = jac.T@np.linalg.solve(jac@jac.T+0.0001*np.eye(6), error)
        scratch.qpos[backend.addresses[:5]] = np.clip(scratch.qpos[backend.addresses[:5]]+np.clip(dq, -0.12, 0.12),
                                                     limits[:, 0]+0.002, limits[:, 1]-0.002)
    mj.mj_forward(model, scratch)
    return scratch.qpos[backend.addresses].copy(), float(np.linalg.norm(np.asarray(target)-scratch.site_xpos[backend.site_id]))


def _inside_target(backend, scene):
    np = backend.np
    center = backend.data.xpos[backend.part_id]
    rotation = backend.data.xmat[backend.part_id].reshape(3, 3)
    half = np.abs(rotation)@(np.asarray(scene["object_size_m"])/2)
    target = np.asarray(scene["target_center_m"])
    inner = np.asarray(scene["tray_size_m"][:2])/2-0.003
    velocity = np.zeros(6)
    backend.mujoco.mj_objectVelocity(backend.model, backend.data, backend.mujoco.mjtObj.mjOBJ_BODY,
                                     backend.part_id, velocity, 0)
    return bool(np.all(np.abs(center[:2]-target)+half[:2] <= inner)
                and 0.003+half[2]-0.004 <= center[2] <= 0.003+half[2]+0.006
                and np.linalg.norm(velocity[3:]) < 0.03)


def run_simulation(world_path: Path, output_dir: Path, seed=0, *, frame_sink=None) -> dict:
    """Run one bounded scripted contact attempt; failure remains an honest result."""
    if type(seed) is not int or not 0 <= seed <= 2**32-1:
        raise ValueError("invalid seed")
    if frame_sink is not None and not callable(frame_sink):
        raise ValueError("frame sink must be a local callable")
    world_path = Path(world_path).resolve()
    manifest = json.loads((world_path.parent / "scene_manifest.json").read_text(encoding="utf-8"))
    if hashlib.sha256(world_path.read_bytes()).hexdigest() != manifest["world_sha256"]:
        raise ValueError("generated world hash mismatch")
    scene = validate_scene(manifest["scene"])
    if _hash(scene) != manifest["scene_sha256"]:
        raise ValueError("scene configuration hash mismatch")
    _verify_asset_directory(world_path.parent/"robot", manifest["asset_provenance"])
    output_dir = Path(output_dir).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    protected = [world_path, world_path.parent/"scene_manifest.json"]
    targets = [output_dir/name for name in ("joint_trace.jsonl", "demonstration.npz", "simulation_report.json")]
    if any(path.resolve() in protected for path in targets):
        raise ValueError("simulation evidence must not overwrite the world")
    if any(path.exists() for path in targets) or any(output_dir.glob("camera_*.png")):
        raise ValueError("simulation evidence already exists; use a new run directory")
    backend = MuJoCoBackend(world_path)
    mj, np = backend.mujoco, backend.np
    initial = backend.reset(seed=seed)
    if frame_sink is not None:
        frame_sink(backend)
    scratch = mj.MjData(backend.model)
    start_point = backend.data.site_xpos[backend.site_id].copy()
    source = np.asarray(initial["part_position_m"])
    target = np.array([*scene["target_center_m"], source[2]])
    hover_source, hover_target = source+[0, 0, 0.06], target+[0, 0, 0.06]
    phases = [("approach", 2.0, hover_source, 0.9), ("descend", 1.5, source, 0.9),
              ("close", 0.9, source, -0.12), ("lift", 1.5, hover_source, -0.12),
              ("transfer", 2.0, hover_target, -0.12), ("place", 1.5, target, -0.12),
              ("release", 0.8, target, 0.9), ("retreat", 1.0, hover_target, 0.9),
              ("hold", scene["hold_seconds"]+0.5, hover_target, 0.9)]
    renderer = None
    camera_status, camera_error = "not_run", None
    frames, records, observations, actions, timestamps = [], [], [], [], []
    wall_start = time.monotonic()
    max_height, grasp_contacts, hold_time, success = source[2], 0, 0.0, False
    ik_max_error, stopped_reason = 0.0, None
    try:
        try:
            renderer = mj.Renderer(backend.model, height=480, width=640)
            camera_status = "executed"
        except Exception as exc:
            camera_status, camera_error = "failed", f"{type(exc).__name__}: {exc}"
        def capture(name):
            nonlocal camera_status, camera_error
            if renderer is None or camera_status == "failed":
                return
            try:
                options = mj.MjvOption()
                options.geomgroup[3] = options.geomgroup[4] = 0
                renderer.update_scene(backend.data, camera="front", scene_option=options)
                path = output_dir/f"camera_{name}.png"
                _png(path, renderer.render())
                frames.append({"path": path.name, "timestamp_s": float(backend.data.time),
                               "sha256": hashlib.sha256(path.read_bytes()).hexdigest()})
            except Exception as exc:
                camera_status, camera_error = "failed", f"{type(exc).__name__}: {exc}"
        capture("initial")
        previous_point, previous_grip = start_point, float(backend.data.qpos[backend.addresses[-1]])
        for phase, duration, point, grip in phases:
            count = max(1, math.ceil(duration*scene["control_hz"]))
            substeps = max(1, round(1/(scene["control_hz"]*scene["timestep_s"])))
            for index in range(count):
                if time.monotonic()-wall_start > 55:
                    stopped_reason = "wall_clock_budget_exceeded"
                    break
                blend = (index+1)/count
                requested_point = previous_point+(point-previous_point)*blend
                q, error = _ik(backend, requested_point, backend.data.qpos[backend.addresses].copy(), scratch)
                q[-1] = previous_grip+(grip-previous_grip)*blend
                # Explicitly bounded setpoint changes; no object pose assignments.
                q = np.clip(q, backend.data.qpos[backend.addresses]-0.08, backend.data.qpos[backend.addresses]+0.08)
                bounds = backend.model.actuator_ctrlrange[backend.actuator_ids]
                q = np.clip(q, bounds[:, 0], bounds[:, 1])
                before = backend.observe()
                observations.append(before["joint_position_rad"]+before["part_position_m"]+scene["target_center_m"]+[target[2]])
                actions.append(q.tolist())
                timestamps.append(before["timestamp_s"])
                observed = backend.step(q, substeps)
                if frame_sink is not None:
                    frame_sink(backend)
                contacts = _gripper_part_contacts(backend)
                released = observed["joint_position_rad"][-1] >= 0.5 and contacts == 0
                observed.update({"requested_action_rad": q.tolist(), "phase": phase,
                                 "released": released, "gripper_part_contacts": contacts,
                                 "task_success_observed": _released_inside_target(backend, scene), "ik_position_error_m": error})
                ik_max_error = max(ik_max_error, error)
                max_height = max(max_height, observed["part_position_m"][2])
                grasp_contacts += contacts
                if phase in ("retreat", "hold") and observed["task_success_observed"]:
                    hold_time += substeps*scene["timestep_s"]
                    success = success or hold_time >= scene["hold_seconds"]
                else:
                    hold_time = 0.0
                observed["consecutive_release_hold_s"] = hold_time
                records.append(observed)
            if phase in ("close", "lift", "place", "hold"):
                capture(phase)
            if stopped_reason:
                break
            previous_point, previous_grip = point.copy(), grip
    finally:
        if renderer is not None:
            renderer.close()
    log_path = output_dir/"joint_trace.jsonl"
    log_path.write_text("".join(json.dumps(row, allow_nan=False)+"\n" for row in records), encoding="utf-8")
    dataset_metadata = {"schema_version": 1, "data_kind": "simulation", "label_source": "scripted_controller",
                        "time_unit": "s", "clock_domain": "simulation_episode_time", "action_unit": "rad",
                        "action_semantics": "absolute_joint_position",
                        "observation_names": [f"{name}.position_rad" for name in JOINT_NAMES]
                            +[f"part.{axis}_m" for axis in "xyz"]+[f"target.{axis}_m" for axis in "xyz"],
                        "action_names": list(JOINT_NAMES), "split": "unassigned",
                        "demonstration_quality_verified": False, "scene_sha256": manifest["scene_sha256"]}
    np.savez_compressed(output_dir/"demonstration.npz", observations=np.asarray(observations, dtype=np.float32),
                        actions=np.asarray(actions, dtype=np.float32), timestamps_s=np.asarray(timestamps),
                        episode_id=np.zeros(len(actions), dtype=np.int32), joint_names=np.asarray(JOINT_NAMES),
                        metadata_json=np.asarray(json.dumps(dataset_metadata)))
    success = bool(success and _released_inside_target(backend, scene) and stopped_reason is None)
    if success:
        failure_reason = None
    elif stopped_reason:
        failure_reason = stopped_reason
    elif grasp_contacts == 0:
        failure_reason = "scripted_baseline_did_not_contact_part_with_gripper"
    elif max_height < source[2]+0.03:
        failure_reason = "contact_occurred_but_no_verified_lift"
    else:
        failure_reason = "part_not_stably_placed_inside_target_tray"
    report = {"schema_version": 1, "execution_kind": "simulation", "simulation_status": "executed",
              "physical_status": "not_run", "policy_kind": "scripted_damped_ik_baseline", "ai_policy_used": False,
              "task_success": bool(success), "failure_reason": failure_reason,
              "physics_steps": int(round(backend.data.time/scene["timestep_s"])), "control_steps": len(records),
              "simulated_seconds": float(backend.data.time), "wall_seconds": time.monotonic()-wall_start,
              "seed": seed, "randomization_applied": True, "reset_part_xy_jitter_m": 0.002,
              "randomization_source": "simulation_assumption_not_physical_measurement", "initial_observation": initial,
              "final_observation": backend.observe(), "max_part_height_m": float(max_height),
              "gripper_part_contact_samples": grasp_contacts, "max_ik_position_error_m": ik_max_error,
              "camera_status": camera_status, "camera_error": camera_error, "camera_frames": frames,
              "joint_log": log_path.name, "demonstration": "demonstration.npz",
              "demonstration_schema": {"observation": "joint_position_rad[6],part_position_m[3],target_center_m[3]",
                                       "action": "scripted_position_setpoint_rad[6]", "episode_count": 1,
                                       "camera_is_training_input": False},
              "scene_sha256": manifest["scene_sha256"], "world_sha256": manifest["world_sha256"],
              "source_commit": manifest["asset_provenance"]["source_commit"],
              "evaluation": {"criterion": "entire_rotated_part_inside_target_and_settled_after_release",
                             "final_object_fully_inside_target_and_settled": _inside_target(backend, scene),
                             "final_released_inside_target": _released_inside_target(backend, scene),
                             "settled_speed_limit_m_s": 0.03,
                             "gripper_open_threshold_rad": 0.5,
                             "gripper_part_contact_required_absent": True,
                             "baseline_hold_phases": ["retreat", "hold"],
                             "hold_seconds": scene["hold_seconds"], "forced_grasp": False,
                             "teleportation_after_reset": False},
              "limitations": ["Single scripted episode is not a policy success-rate benchmark.",
                              "Baseline uses the common measured release criterion plus a conservative retreat/hold phase gate.",
                              "Public model and task parameters have not been matched to physical arms.",
                              "Joint model radians are not confirmed LeRobot normalized action coordinates.",
                              "No ACT, runtime LLM, physical transfer or real2sim improvement is claimed."]}
    (output_dir/"simulation_report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False)+"\n", encoding="utf-8")
    return report


def _read_verified_world(world_path: Path) -> tuple[dict, dict]:
    path = Path(world_path).resolve()
    manifest_path = path.parent/"scene_manifest.json"
    if manifest_path.stat().st_size > 1_048_576:
        raise ValueError("scene manifest exceeds the input budget")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if hashlib.sha256(path.read_bytes()).hexdigest() != manifest["world_sha256"]:
        raise ValueError("generated world hash mismatch")
    scene = validate_scene(manifest["scene"])
    if _hash(scene) != manifest["scene_sha256"]:
        raise ValueError("scene configuration hash mismatch")
    _verify_asset_directory(path.parent/"robot", manifest["asset_provenance"])
    return manifest, scene


def _gripper_part_contacts(backend) -> int:
    mj = backend.mujoco
    part_geom = mj.mj_name2id(backend.model, mj.mjtObj.mjOBJ_GEOM, "part_geom")
    count = 0
    for contact in backend.data.contact:
        if part_geom in (contact.geom1, contact.geom2):
            other = contact.geom2 if contact.geom1 == part_geom else contact.geom1
            owner = backend.model.geom_bodyid[other]
            if mj.mj_id2name(backend.model, mj.mjtObj.mjOBJ_BODY, owner) in ("gripper", "moving_jaw_so101_v1"):
                count += 1
    return count


def _released_inside_target(backend, scene) -> bool:
    """Common measured criterion for both controllers; no phase or action oracle."""
    return bool(_inside_target(backend, scene)
                and backend.data.qpos[backend.addresses[-1]] >= 0.5
                and _gripper_part_contacts(backend) == 0)


def _observation_names() -> list[str]:
    return [f"{name}.position_rad" for name in JOINT_NAMES]+[f"part.{axis}_m" for axis in "xyz"]+[f"target.{axis}_m" for axis in "xyz"]


class _EvidenceCamera:
    def __init__(self, backend, directory: Path):
        self.backend, self.directory = backend, directory
        self.renderer, self.status, self.error, self.frames = None, "not_run", None, []
        try:
            self.renderer = backend.mujoco.Renderer(backend.model, height=480, width=640)
            self.status = "executed"
        except Exception as exc:
            self.status, self.error = "failed", f"{type(exc).__name__}: {exc}"

    def capture(self, name):
        if self.renderer is None or self.status == "failed":
            return
        try:
            options = self.backend.mujoco.MjvOption()
            options.geomgroup[3] = options.geomgroup[4] = 0
            self.renderer.update_scene(self.backend.data, camera="front", scene_option=options)
            path = self.directory/f"policy_camera_{name}.png"
            _png(path, self.renderer.render())
            self.frames.append({"path": path.name, "timestamp_s": float(self.backend.data.time),
                                "sha256": hashlib.sha256(path.read_bytes()).hexdigest()})
        except Exception as exc:
            self.status, self.error = "failed", f"{type(exc).__name__}: {exc}"

    def close(self):
        if self.renderer is not None:
            self.renderer.close()


def evaluate_policy_in_simulation(world_path: Path, checkpoint_dir: Path, output_dir: Path,
                                  seed: int, episode_seconds=14, *, frame_sink=None) -> dict:
    """Closed-loop learned inference only; consume chunk[0], then observe again.

    Scripted IK, demonstrations, future states and phase labels are never read by
    this evaluator. The evaluator clips position setpoints and records both sides.
    """
    from .learning import load_chunk_policy
    if type(seed) is not int or not 0 <= seed <= 2**32-1:
        raise ValueError("invalid seed")
    if frame_sink is not None and not callable(frame_sink):
        raise ValueError("frame sink must be a local callable")
    if not _number(episode_seconds) or not 0.1 <= episode_seconds <= 20:
        raise ValueError("policy episode duration must be 0.1 through 20 seconds")
    world_path, checkpoint_dir = Path(world_path).resolve(), Path(checkpoint_dir).resolve()
    manifest, scene = _read_verified_world(world_path)
    policy = load_chunk_policy(checkpoint_dir)
    policy_manifest = policy.manifest
    contract = policy_manifest.get("contract", {})
    if (policy_manifest.get("observation_dim") != 12 or policy_manifest.get("action_dim") != 6
            or type(policy_manifest.get("chunk_size")) is not int or not 1 <= policy_manifest["chunk_size"] <= 4):
        raise ValueError("simulator policy requires observation[12] and at most four action[6] setpoints")
    if (contract.get("observation_names") != _observation_names()
            or contract.get("action_names") != list(JOINT_NAMES)
            or contract.get("action_unit") != "rad" or contract.get("action_semantics") != "absolute_joint_position"
            or contract.get("time_unit") != "s" or contract.get("clock_domain") != "simulation_episode_time"
            or contract.get("data_kind") != "simulation"):
        raise ValueError("policy names/units/time/domain do not match the simulator contract")
    if contract.get("scene_sha256") not in (None, manifest["scene_sha256"]):
        raise ValueError("policy scene contract does not match the evaluated world")
    substeps = round(1/(scene["control_hz"]*scene["timestep_s"]))
    sample_period = substeps*scene["timestep_s"]
    policy_period = policy_manifest.get("sample_period_s_verified")
    if not _number(policy_period) or not math.isclose(policy_period, sample_period, rel_tol=1e-5, abs_tol=1e-8):
        raise ValueError("policy sampling period does not match actual simulation control timing")
    output_dir = Path(output_dir).resolve()
    if (output_dir.is_relative_to(checkpoint_dir) or output_dir.is_relative_to(ASSET_ROOT.resolve())
            or output_dir.is_relative_to(world_path.parent/"robot")):
        raise ValueError("policy evidence must remain separate from checkpoint and source assets")
    targets = [output_dir/name for name in ("policy_trace.jsonl", "policy_simulation_report.json")]
    if any(path.exists() for path in targets) or any(output_dir.glob("policy_camera_*.png")):
        raise ValueError("policy evidence already exists; use a new run directory")
    output_dir.mkdir(parents=True, exist_ok=True)
    backend = MuJoCoBackend(world_path)
    mj, np = backend.mujoco, backend.np
    initial = backend.reset(seed=seed)
    if frame_sink is not None:
        frame_sink(backend)
    target = [*scene["target_center_m"], 0.003+scene["object_size_m"][2]/2+0.001]
    records, hold_time, success, clip_steps = [], 0.0, False, 0
    max_height = initial["part_position_m"][2]
    stopped_reason, prediction_error = None, None
    wall_start = time.monotonic()
    camera = _EvidenceCamera(backend, output_dir)
    camera.capture("initial")
    checkpoints = [episode_seconds*fraction for fraction in (0.25, 0.5, 0.75)]
    captured = set()
    old_torch_threads = None
    if policy_manifest["backend"] == "torch_tiny_chunk_transformer":
        import torch
        old_torch_threads = torch.get_num_threads()
        torch.set_num_threads(min(old_torch_threads, 2))
    try:
        for _ in range(math.ceil(episode_seconds/sample_period)):
            if time.monotonic()-wall_start > 55:
                stopped_reason = "wall_clock_budget_exceeded"
                break
            before = backend.observe()
            observation = before["joint_position_rad"]+before["part_position_m"]+target
            try:
                chunk = np.asarray(policy.predict(observation), dtype=float)
                if chunk.shape != (policy_manifest["chunk_size"], 6) or not np.isfinite(chunk).all():
                    raise ValueError("policy returned an invalid action chunk")
            except Exception as exc:
                stopped_reason, prediction_error = "invalid_policy_prediction", f"{type(exc).__name__}: {exc}"
                break
            requested = chunk[0].copy()
            position = np.asarray(before["joint_position_rad"])
            bounds = backend.model.actuator_ctrlrange[backend.actuator_ids]
            transmitted = np.clip(np.clip(requested, position-0.08, position+0.08), bounds[:, 0], bounds[:, 1])
            clipped = bool(np.any(np.abs(transmitted-requested) > 1e-12))
            observed = backend.step(transmitted, substeps)
            if frame_sink is not None:
                frame_sink(backend)
            contacts = _gripper_part_contacts(backend)
            released = observed["joint_position_rad"][-1] >= 0.5 and contacts == 0
            task_criterion = _released_inside_target(backend, scene)
            hold_time = hold_time+sample_period if task_criterion else 0.0
            success = success or hold_time >= scene["hold_seconds"]
            observed.update({"observation_before": observation, "observation_timestamp_s": before["timestamp_s"],
                             "requested_action_rad": requested.tolist(), "transmitted_command_rad": transmitted.tolist(),
                             "control_clipped": clipped, "gripper_part_contacts": contacts,
                             "released": released, "task_success_observed": task_criterion,
                             "consecutive_release_hold_s": hold_time})
            records.append(observed)
            clip_steps += int(clipped)
            max_height = max(max_height, observed["part_position_m"][2])
            for index, boundary in enumerate(checkpoints):
                if observed["timestamp_s"] >= boundary and index not in captured:
                    camera.capture(f"fraction_{index+1}")
                    captured.add(index)
    finally:
        camera.capture("final")
        camera.close()
        if old_torch_threads is not None:
            torch.set_num_threads(old_torch_threads)
    final = backend.observe()
    released = final["joint_position_rad"][-1] >= 0.5 and _gripper_part_contacts(backend) == 0
    success = bool(success and _released_inside_target(backend, scene) and stopped_reason is None)
    trace_path = output_dir/"policy_trace.jsonl"
    trace_path.write_text("".join(json.dumps(row, allow_nan=False)+"\n" for row in records), encoding="utf-8")
    report = {"schema_version": 1, "execution_kind": "simulation",
              "simulation_status": "executed" if stopped_reason is None else "stopped",
              "physical_status": "not_run", "ai_policy_used": True,
              "policy_kind": policy_manifest["backend"], "policy_scope": "tiny action-chunk model; not original ACT",
              "task_success": success, "failure_reason": None if success else (stopped_reason or "learned_policy_did_not_complete_released_hold"),
              "prediction_error": prediction_error, "checkpoint_weights_sha256": policy_manifest["weights_sha256"],
              "checkpoint_manifest_sha256": hashlib.sha256((checkpoint_dir/"policy_manifest.json").read_bytes()).hexdigest(),
              "scene_sha256": manifest["scene_sha256"], "world_sha256": manifest["world_sha256"],
              "seed": seed, "reset_part_xy_jitter_m": 0.002,
              "initial_observation": initial, "final_observation": final,
              "physics_steps": int(round(backend.data.time/scene["timestep_s"])), "control_steps": len(records),
              "policy_prediction_calls": len(records)+(1 if prediction_error else 0),
              "simulated_seconds": float(backend.data.time), "wall_seconds": time.monotonic()-wall_start,
              "actual_sample_period_s": sample_period, "action_chunk_consumption": "first_action_receding_horizon",
              "observation_updated_after_each_control": True, "scripted_actions_used": False,
              "demonstration_labels_read_during_execution": False, "clipped_control_steps": clip_steps,
              "setpoint_delta_limit_rad": 0.08,
              "max_setpoint_delta_from_measured_rad": max((max(abs(sent-state) for sent, state in
                   zip(row["transmitted_command_rad"], row["observation_before"][:6])) for row in records), default=0.0),
              "max_part_height_m": float(max_height), "camera_is_policy_input": False,
              "policy_observation_source": "MuJoCo joint/body state and declared target pose",
              "observation_names": _observation_names(), "action_unit": "rad",
              "action_semantics": "absolute_joint_position",
              "joint_log": trace_path.name, "camera_status": camera.status, "camera_error": camera.error,
              "camera_frames": camera.frames,
              "evaluation": {"criterion": "entire_rotated_part_inside_target_and_settled_after_release",
                             "final_released_inside_target": _released_inside_target(backend, scene),
                             "hold_seconds": scene["hold_seconds"], "settled_speed_limit_m_s": 0.03,
                             "gripper_open_threshold_rad": 0.5, "gripper_part_contact_required_absent": True,
                             "forced_grasp": False, "teleportation_after_reset": False},
              "limitations": ["Fresh simulated state drives learned inference; no scripted action fallback is used.",
                              "One episode does not establish a policy success rate or physical transfer.",
                              "Safety clipping changes policy commands and is recorded for interpretation.",
                              "Policy uses simulator ground-truth part position; camera perception is not implemented.",
                              "Simulator parameters and reset jitter remain design assumptions."]}
    (output_dir/"policy_simulation_report.json").write_text(json.dumps(report, indent=2, ensure_ascii=False, allow_nan=False)+"\n", encoding="utf-8")
    return report


def collect_simulation_response_log(world_path: Path, output_path: Path) -> Path:
    """Four actual MuJoCo shoulder response sessions; no analytical fake state."""
    world_path, output_path = Path(world_path).resolve(), Path(output_path).resolve()
    manifest, scene = _read_verified_world(world_path)
    if (output_path.suffix.lower() != ".json" or output_path.exists()
            or output_path.is_relative_to(ASSET_ROOT.resolve())
            or output_path.is_relative_to(world_path.parent/"robot")):
        raise ValueError("response output requires a new JSON path separate from source assets")
    backend = MuJoCoBackend(world_path)
    np = backend.np
    substeps = max(1, round(0.01/scene["timestep_s"]))
    sample_period = substeps*scene["timestep_s"]
    sessions = []
    wall_start = time.monotonic()
    for session_index, frequency in enumerate((0.6, 0.9, 1.1, 1.4)):
        backend.reset()
        rest = backend.data.qpos[backend.addresses].copy()
        # Settling uses physics steps, never writes measured joint trajectories.
        for _ in range(10):
            backend.step(rest, 25)
        origin_time = float(backend.data.time)
        phase = session_index*0.35
        times, requested_values, transmitted_values, measured_values = [], [], [], []
        for _ in range(400):
            if time.monotonic()-wall_start > 55:
                raise RuntimeError("response collection exceeded the wall-clock budget")
            timestamp = float(backend.data.time)-origin_time
            requested = 0.08*math.sin(2*math.pi*frequency*timestamp+phase)+0.025*math.sin(2*math.pi*1.7*timestamp+0.4*phase)
            bounds = backend.model.actuator_ctrlrange[backend.actuator_ids[0]]
            transmitted = float(np.clip(requested, bounds[0], bounds[1]))
            measured = float(backend.data.qpos[backend.addresses[0]])
            # Command is assigned at this timestamp; pre-step state is measured on the same grid.
            control = rest.copy()
            control[0] = transmitted
            backend.data.ctrl[backend.actuator_ids] = control
            times.append(timestamp)
            requested_values.append(requested)
            transmitted_values.append(transmitted)
            measured_values.append(measured)
            backend.step(control, substeps)
        sessions.append({"session_id": f"mujoco-shoulder-pan-{session_index}",
                         "split": "calibration" if session_index < 2 else "holdout",
                         "clock_domain": "simulation_session_time", "timestamps_s": times,
                         "requested_target": requested_values, "transmitted_command": transmitted_values,
                         "measured_state": measured_values, "frequency_hz": frequency,
                         "measured_state_source": "MuJoCo qpos before integration at command timestamp",
                         "reset_performed": True, "physics_steps": 250+400*substeps})
    payload = {"schema_version": 1, "execution_kind": "simulation", "physical_status": "not_run",
               "time_unit": "s", "command_unit": "rad", "measured_state_unit": "rad",
               "clock_domain": "simulation_session_time", "joint_name": "shoulder_pan",
               "actual_sample_period_s": sample_period, "sessions": sessions,
               "scene_sha256": manifest["scene_sha256"], "world_sha256": manifest["world_sha256"],
               "source_commit": manifest["asset_provenance"]["source_commit"],
               "provenance": "Actual MuJoCo motor/rigid-body/contact integration of a public model; not hardware measurements.",
               "gain_delay_model_applicability": "Scalar gain/transport delay can approximate these logs but cannot identify full actuator/contact dynamics.",
               "limitations": ["No fitted response values are substituted into recorded measured_state.",
                               "Calibration and holdout sessions are separate resets and distinct frequencies.",
                               "Holdout improvement is evaluated honestly and may be absent.",
                               "No hardware motor parameters or real2sim validity are established."]}
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(payload, indent=2, allow_nan=False)+"\n", encoding="utf-8")
    return output_path
