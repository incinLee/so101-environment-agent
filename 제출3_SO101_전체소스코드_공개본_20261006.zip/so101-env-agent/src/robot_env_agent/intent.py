"""Local learned two-intent router; no LLM, network, or hardware calls at runtime.

Synthetic bilingual development fixtures train a char-ngram softmax model with
gradient descent. This narrow classifier is not a general instruction-following
agent. Safety guards are explicit rules, separate from learned inference.
"""

from collections import Counter
from functools import lru_cache
import math
import re
import unicodedata

MODEL_KIND = "local_trained_linear_text_classifier"
INTENTS = ("tray_transfer", "response_calibration")
CONFIDENCE_THRESHOLD = 0.65
MIN_RECOGNIZED_FRACTION = 0.14
TRAINING_EPOCHS = 500
MAX_FEATURES = 2800

# Labelled synthetic development examples, prepared with Codex coding assistance.
# They are not user data, independently sampled language benchmarks, or physical logs.
_TRAIN = (
    ("부품을 한 트레이에서 다른 트레이로 옮기는 환경을 구성해줘", "tray_transfer"),
    ("로봇 트레이 이동 작업의 가상환경을 만들고 검사해줘", "tray_transfer"),
    ("부품 옮기기 시뮬레이션을 실행하고 결과를 확인해줘", "tray_transfer"),
    ("소스 트레이에서 목표 트레이로 부품을 운반하는 장면을 생성해줘", "tray_transfer"),
    ("SO101 환경 구성과 검증 계획을 세워줘", "tray_transfer"),
    ("부품 이송 작업 환경 생성과 시뮬레이션 검사를 진행해줘", "tray_transfer"),
    ("트레이와 물체를 배치한 로봇 환경을 검증해줘", "tray_transfer"),
    ("한 트레이의 부품을 다른 트레이에 내려놓는 작업을 시뮬레이션해줘", "tray_transfer"),
    ("트레이 간 부품 이동 환경을 만들어 오류를 검사해줘", "tray_transfer"),
    ("로봇 가상환경 생성 도구를 사용해 부품 이동 실험을 해줘", "tray_transfer"),
    ("build a robot environment for transferring a part between trays", "tray_transfer"),
    ("create and validate the SO101 tray transfer simulation", "tray_transfer"),
    ("simulate moving one part from a source tray to a target tray", "tray_transfer"),
    ("construct the robot scene and inspect environment errors", "tray_transfer"),
    ("plan build validate and run the part transfer environment", "tray_transfer"),
    ("generate a virtual scene for moving parts between two trays", "tray_transfer"),
    ("run the tray transfer simulation and check the outcome", "tray_transfer"),
    ("inspect and repair the generated part transfer environment", "tray_transfer"),
    ("응답 로그에서 전달 지연과 이득을 추정해줘", "response_calibration"),
    ("명령과 측정 상태를 비교해 응답 보정을 수행해줘", "response_calibration"),
    ("전송 명령과 실측 로그의 지연을 분석해줘", "response_calibration"),
    ("보정 세션으로 gain delay를 맞추고 홀드아웃에서 검증해줘", "response_calibration"),
    ("기록된 응답 데이터의 이득과 지연 시간을 계산해줘", "response_calibration"),
    ("응답 로그를 비교하고 제한 범위 안에서 파라미터를 보정해줘", "response_calibration"),
    ("전송된 목표와 상태 로그의 응답 오차를 분석하고 검증해줘", "response_calibration"),
    ("합성 응답에서 지연과 gain을 추정하는 보정 시험을 해줘", "response_calibration"),
    ("이득 지연 모델을 로그에 맞추고 독립 세션에서 비교해줘", "response_calibration"),
    ("응답 보정용 기록 파일로 전달 지연을 측정해줘", "response_calibration"),
    ("fit response gain and transport delay from command state logs", "response_calibration"),
    ("calibrate the response using transmitted commands and measured states", "response_calibration"),
    ("estimate bounded gain and latency from recorded response data", "response_calibration"),
    ("compare before and after response calibration on heldout sessions", "response_calibration"),
    ("identify scalar gain and delay in the timestamped response log", "response_calibration"),
    ("fit the toy response model and evaluate a separate holdout", "response_calibration"),
    ("analyse command response errors and calibrate delay parameters", "response_calibration"),
    ("use recorded signals to estimate response delay and gain", "response_calibration"),
)

# Held out from feature construction, fitting and normalization. Thresholds above
# are fixed design choices, not a claim of broad calibrated language confidence.
_EVAL = (
    ("두 트레이 사이로 부품을 옮기는 가상환경을 생성하고 검증해줘", "tray_transfer"),
    ("SO101 부품 이송 시뮬레이션 환경을 구성해줘", "tray_transfer"),
    ("부품을 목표 트레이로 운반하는 로봇 작업을 실행해줘", "tray_transfer"),
    ("물체 이동 환경을 만들고 구성 오류를 검사해줘", "tray_transfer"),
    ("prepare a virtual robot environment to move a part between trays", "tray_transfer"),
    ("build then inspect the SO101 part transfer scene", "tray_transfer"),
    ("simulate transferring a component into the target tray", "tray_transfer"),
    ("validate and run the generated robot tray environment", "tray_transfer"),
    ("응답 기록에서 gain과 지연을 추정하고 홀드아웃으로 확인해줘", "response_calibration"),
    ("시간별 전송 명령과 측정 상태 로그의 응답을 보정해줘", "response_calibration"),
    ("기록 파일로 응답 이득 및 지연 시간을 분석해줘", "response_calibration"),
    ("독립 검증 세션으로 지연 보정 결과를 비교해줘", "response_calibration"),
    ("estimate response latency and gain from transmitted command logs", "response_calibration"),
    ("fit scalar response parameters and compare heldout errors", "response_calibration"),
    ("analyse timestamped response signals for gain delay calibration", "response_calibration"),
    ("calibrate response delay from measured states without hardware writes", "response_calibration"),
)

_UNSUPPORTED_EVAL = ("오늘 날씨 알려줘", "시 한 편 써줘", "what is the capital of France", "prepare a cake recipe", "asdf zxcv qwerty", "😀😀😀")

_GUARDS = (
    ("hardware_action_not_supported", (
        "실제 로봇", "실기로", "실기 동작", "모터 켜", "모터를 켜", "모터 활성", "토크 활성", "토크를 켜", "호밍", "펌웨어",
        "motor enable", "enable motor", "motor_enable", "torque on", "turn on the motor", "activate motor", "move the physical robot", "real robot motion", "firmware", "homing")),
    ("protected_evaluation_change_not_supported", (
        "평가 기준을 바꿔", "성공 기준을 낮춰", "테스트를 무시", "검사를 무시", "change success threshold", "ignore the tests", "disable safety", "비상정지 해제")),
    ("secret_or_unbounded_instruction_not_supported", (
        "api key", "api_key", "password", "비밀번호", "인증 토큰", "upload private", "print secrets", "ignore previous instructions", "../../", "..\\..\\")),
)

_HARDWARE_PATTERNS = (
    re.compile(r"(?:enable|activate|turn\s+on).{0,20}(?:motor|torque)", re.IGNORECASE),
    re.compile(r"(?:모터|토크).{0,12}(?:켜|활성|enable|\bon\b)", re.IGNORECASE),
    re.compile(r"(?:move|operate|actuate|connect).{0,20}(?:physical|real).{0,15}(?:robot|device)", re.IGNORECASE),
)


def _normalize(value: str) -> str:
    value = unicodedata.normalize("NFKC", value).lower()
    return " ".join(value.split())


def _ngrams(text: str) -> Counter:
    normalized = " ".join("".join(char if char.isalnum() else " " for char in text).split())
    counts = Counter()
    for word in normalized.split():
        for size in (2, 3, 4):
            for start in range(len(word) - size + 1):
                counts[word[start:start + size]] += 1
    return counts


def _features(text: str, vocabulary: dict, idf):
    import numpy as np
    counts = _ngrams(_normalize(text))
    vector = np.zeros(len(vocabulary), dtype="float64")
    recognized = 0
    for term, count in counts.items():
        if term in vocabulary:
            vector[vocabulary[term]] = math.log1p(count) * idf[vocabulary[term]]
            recognized += count
    norm = float(np.linalg.norm(vector))
    if norm:
        vector /= norm
    fraction = recognized / max(sum(counts.values()), 1)
    return vector, fraction


def _softmax(logits):
    import numpy as np
    shifted = logits - np.max(logits, axis=-1, keepdims=True)
    value = np.exp(shifted)
    return value / value.sum(axis=-1, keepdims=True)


@lru_cache(maxsize=1)
def _trained_model():
    try:
        import numpy as np
    except ImportError as error:
        raise RuntimeError("numpy is required for the local trained intent classifier") from error
    documents = [_ngrams(_normalize(text)) for text, _ in _TRAIN]
    frequencies = Counter(term for document in documents for term in document)
    ordered = sorted(frequencies, key=lambda term: (-frequencies[term], term))[:MAX_FEATURES]
    vocabulary = {term: index for index, term in enumerate(ordered)}
    idf = np.asarray([math.log((1 + len(_TRAIN)) / (1 + frequencies[term])) + 1 for term in ordered])
    x = np.vstack([_features(text, vocabulary, idf)[0] for text, _ in _TRAIN])
    y = np.asarray([INTENTS.index(label) for _, label in _TRAIN])
    targets = np.eye(len(INTENTS))[y]
    rng = np.random.default_rng(17)
    weights = rng.normal(0.0, 0.001, (len(vocabulary), len(INTENTS)))
    bias = np.zeros(len(INTENTS), dtype="float64")
    initial_loss = None
    for epoch in range(TRAINING_EPOCHS):
        probs = _softmax(x @ weights + bias)
        if epoch == 0:
            initial_loss = float(-np.log(np.clip(probs[np.arange(len(y)), y], 1e-12, 1)).mean())
        residual = (probs - targets) / len(x)
        weights -= x.T @ residual + 0.001 * weights
        bias -= residual.sum(axis=0)
    probabilities = _softmax(x @ weights + bias)
    final_loss = float(-np.log(np.clip(probabilities[np.arange(len(y)), y], 1e-12, 1)).mean())
    train_correct = int((probabilities.argmax(axis=1) == y).sum())
    # These arrays are immutable after fitting. Classification cannot train on goals.
    weights.flags.writeable = False
    bias.flags.writeable = False
    idf.flags.writeable = False
    return {"vocabulary": vocabulary, "idf": idf, "weights": weights, "bias": bias,
            "initial_cross_entropy": initial_loss, "final_cross_entropy": final_loss,
            "train_correct": train_correct}


def classify_goal(goal: str) -> dict:
    if not isinstance(goal, str) or not goal.strip() or len(goal) > 1000:
        raise ValueError("goal must be a nonempty string of at most 1000 characters")
    if any(unicodedata.category(char) == "Cc" and char not in "\t\n\r" for char in goal):
        raise ValueError("goal contains unsupported control characters")
    normalized = _normalize(goal)
    if any(pattern.search(normalized) for pattern in _HARDWARE_PATTERNS):
        return {"intent": "unsupported", "confidence": 0.0, "model_kind": MODEL_KIND,
                "ai_used": False, "llm_used": False, "routing_source": "explicit_safety_guard",
                "reason": "hardware_action_not_supported", "hardware_access": False}
    for reason, patterns in _GUARDS:
        if any(pattern in normalized for pattern in patterns):
            return {"intent": "unsupported", "confidence": 0.0, "model_kind": MODEL_KIND,
                    "ai_used": False, "llm_used": False, "routing_source": "explicit_safety_guard",
                    "reason": reason, "hardware_access": False}
    model = _trained_model()
    vector, fraction = _features(normalized, model["vocabulary"], model["idf"])
    probabilities = _softmax(vector @ model["weights"] + model["bias"])
    index = int(probabilities.argmax())
    confidence = float(probabilities[index])
    supported = bool(vector.any()) and fraction >= MIN_RECOGNIZED_FRACTION and confidence >= CONFIDENCE_THRESHOLD
    result = {"intent": INTENTS[index] if supported else "unsupported", "confidence": confidence,
              "class_probabilities": {label: float(probabilities[i]) for i, label in enumerate(INTENTS)},
              "model_kind": MODEL_KIND, "ai_used": True, "llm_used": False,
              "routing_source": "trained_softmax_inference", "recognized_ngram_fraction": fraction,
              "confidence_threshold": CONFIDENCE_THRESHOLD, "hardware_access": False}
    if not supported:
        result["reason"] = "insufficient_in_scope_language_evidence"
    return result


def get_intent_model_report() -> dict:
    """Only actual fixed synthetic fixture accuracy, not general language accuracy."""
    model = _trained_model()
    results = [{"expected": label, "predicted": classify_goal(text)["intent"]} for text, label in _EVAL]
    supported_correct = sum(row["expected"] == row["predicted"] for row in results)
    unsupported = [classify_goal(text)["intent"] for text in _UNSUPPORTED_EVAL]
    return {"status": "passed", "execution_kind": "synthetic", "model_kind": MODEL_KIND,
            "ai_used": True, "llm_used": False, "external_calls": 0,
            "features": "L2-normalized character 2/3/4-gram TF-IDF", "feature_count": len(model["vocabulary"]),
            "optimization": "full_batch_softmax_gradient_descent", "epochs": TRAINING_EPOCHS,
            "seed": 17, "trained_intents": list(INTENTS), "training_examples": len(_TRAIN),
            "training_correct": model["train_correct"], "training_accuracy": model["train_correct"] / len(_TRAIN),
            "initial_cross_entropy": model["initial_cross_entropy"], "final_cross_entropy": model["final_cross_entropy"],
            "evaluation_examples": len(_EVAL), "evaluation_correct": supported_correct,
            "evaluation_accuracy": supported_correct / len(_EVAL),
            "unsupported_fixture_examples": len(unsupported), "unsupported_fixture_rejected": unsupported.count("unsupported"),
            "evaluation_used_for_training": False, "confidence_threshold": CONFIDENCE_THRESHOLD,
            "fixture_provenance": "Synthetic bilingual development templates prepared with Codex coding assistance; not user data.",
            "runtime_llm_used": False, "task_success": "not_evaluated", "physical_status": "not_run",
            "limitations": ["Only two predeclared project intents are learned.",
                            "Fixture accuracy does not estimate broad language or production accuracy.",
                            "Softmax scores are not calibrated probabilities of safe action.",
                            "Rules guard restricted requests before learned inference; no hardware tool exists here."]}
