"""Robot environment development foundation; no physical device access."""

__version__ = "0.2.2"
