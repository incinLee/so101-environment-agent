"""Stream camera pixels from fresh MuJoCo steps; never replay a saved trajectory.

An explicitly supplied FFmpeg binary encodes MP4 using fixed arguments. Without
one, a small MJPEG AVI writer uses the project's existing Pillow dependency.
"""
from __future__ import annotations

import hashlib
import io
import json
import math
from pathlib import Path
import struct
import subprocess


WIDTH, HEIGHT, MAX_FRAMES, MAX_SECONDS = 640, 480, 600, 20.0


def _validate_options(fps, encoder):
    if type(fps) is not int or not 1 <= fps <= 30:
        raise ValueError("video fps must be an integer from 1 through 30")
    if encoder is None:
        try:
            import imageio_ffmpeg
            encoder = imageio_ffmpeg.get_ffmpeg_exe()
        except ImportError:
            return None
    path = Path(encoder).expanduser().resolve()
    if not path.is_file():
        raise ValueError("explicit FFmpeg encoder must be an existing file")
    return path


def _chunk(tag, payload):
    return tag+struct.pack("<I", len(payload))+payload+(b"\0" if len(payload)%2 else b"")


class _AVIWriter:
    """Bounded streaming RIFF AVI with independently encoded JPEG frames."""
    def __init__(self, path: Path, fps: int):
        from PIL import Image
        self.Image, self.path, self.fps = Image, path, fps
        self.file = path.open("xb")
        self.frames, self.index = 0, []
        avih = struct.pack("<IIIIIIIIII4I", round(1_000_000/fps), 0, 0, 0x10, 0, 0, 1,
                           WIDTH*HEIGHT*3, WIDTH, HEIGHT, 0, 0, 0, 0)
        strh = struct.pack("<4s4sIHHIIIIIIIIhhhh", b"vids", b"MJPG", 0, 0, 0,
                           0, 1, fps, 0, 0, WIDTH*HEIGHT*3, 0xffffffff, 0,
                           0, 0, WIDTH, HEIGHT)
        strf = struct.pack("<IiiHH4sIiiII", 40, WIDTH, HEIGHT, 1, 24, b"MJPG",
                           WIDTH*HEIGHT*3, 0, 0, 0, 0)
        stream = _chunk(b"LIST", b"strl"+_chunk(b"strh", strh)+_chunk(b"strf", strf))
        header = _chunk(b"LIST", b"hdrl"+_chunk(b"avih", avih)+stream)
        self.file.write(b"RIFF\0\0\0\0AVI "+header)
        self.avih_frames_offset = 12+12+8+16
        # RIFF(12), hdrl LIST/type(12), avih chunk(8+56), strl LIST/type(12), strh header(8).
        self.strh_length_offset = 12+12+8+56+12+8+32
        self.movi_header = self.file.tell()
        self.file.write(b"LIST\0\0\0\0movi")
        self.movi_type_position = self.movi_header+8

    def write(self, pixels):
        buffer = io.BytesIO()
        self.Image.fromarray(pixels).save(buffer, format="JPEG", quality=85)
        payload = buffer.getvalue()
        offset = self.file.tell()-self.movi_type_position
        self.file.write(_chunk(b"00dc", payload))
        self.index.append(struct.pack("<4sIII", b"00dc", 0x10, offset, len(payload)))
        self.frames += 1

    def close(self):
        if self.file.closed:
            return
        movi_end = self.file.tell()
        self.file.write(_chunk(b"idx1", b"".join(self.index)))
        end = self.file.tell()
        self.file.seek(4)
        self.file.write(struct.pack("<I", end-8))
        self.file.seek(self.movi_header+4)
        self.file.write(struct.pack("<I", movi_end-self.movi_header-8))
        self.file.seek(self.avih_frames_offset)
        self.file.write(struct.pack("<I", self.frames))
        self.file.seek(self.strh_length_offset)
        self.file.write(struct.pack("<I", self.frames))
        self.file.close()
        if self.frames == 0:
            raise RuntimeError("camera produced no video frames")


class _FFmpegWriter:
    def __init__(self, path: Path, fps: int, encoder: Path):
        self.path = path
        self.error_path = path.parent/"video_encoder_error.log"
        self.error_file = self.error_path.open("xb")
        # Never interpret goal/model text as executable arguments or shell commands.
        self.arguments = [str(encoder), "-hide_banner", "-loglevel", "error", "-nostdin", "-n",
                          "-f", "rawvideo", "-pixel_format", "rgb24", "-video_size", f"{WIDTH}x{HEIGHT}",
                          "-framerate", str(fps), "-i", "pipe:0", "-an", "-c:v", "libx264",
                          "-preset", "veryfast", "-crf", "20", "-pix_fmt", "yuv420p",
                          "-movflags", "+faststart", str(path)]
        try:
            self.process = subprocess.Popen(self.arguments, stdin=subprocess.PIPE,
                                             stdout=subprocess.DEVNULL, stderr=self.error_file,
                                             shell=False)
        except Exception:
            self.error_file.close()
            raise
        self.frames, self.closed = 0, False

    def write(self, pixels):
        self.process.stdin.write(pixels.tobytes(order="C"))
        self.frames += 1

    def close(self):
        if self.closed:
            return
        self.closed = True
        try:
            try:
                self.process.stdin.close()
            except BrokenPipeError:
                pass
            try:
                status = self.process.wait(timeout=20)
            except subprocess.TimeoutExpired:
                self.process.kill()
                self.process.wait(timeout=5)
                raise RuntimeError("FFmpeg exceeded the bounded finalization time")
        finally:
            self.error_file.close()
        if status != 0:
            detail = self.error_path.read_text(encoding="utf-8", errors="replace")[:2000]
            raise RuntimeError(f"FFmpeg exited with status {status}: {detail}")
        if self.frames == 0 or not self.path.exists() or self.path.stat().st_size < 1024:
            raise RuntimeError("FFmpeg did not produce a usable video file")
        with self.path.open("rb") as source:
            prefix = source.read(12)
        if prefix[4:8] != b"ftyp":
            raise RuntimeError("encoder output is not an MP4 container")


class _CameraFrameSink:
    def __init__(self, directory: Path, fps: int, encoder: Path | None, controller: str):
        self.directory, self.fps, self.encoder, self.controller = directory, fps, encoder, controller
        self.path = directory/("simulation.mp4" if encoder is not None else "simulation.avi")
        self.writer, self.renderer = None, None
        self.frames, self.max_lateness, self.last_actual_time = 0, 0.0, 0.0
        self.status, self.error = "not_run", None
        self.capture_truncated = False
        self.timeline = (directory/"video_frame_timeline.jsonl").open("x", encoding="utf-8")

    def __call__(self, backend):
        if self.status == "failed":
            return
        actual = float(backend.data.time)
        self.last_actual_time = actual
        if not math.isfinite(actual) or actual < 0 or actual > MAX_SECONDS+0.1:
            self.status, self.error = "failed", "simulation time exceeded the video budget"
            return
        desired = self.frames/self.fps
        if actual+1e-9 < desired:
            return
        try:
            if self.renderer is None:
                self.renderer = backend.mujoco.Renderer(backend.model, height=HEIGHT, width=WIDTH)
            if self.writer is None:
                self.writer = (_FFmpegWriter(self.path, self.fps, self.encoder) if self.encoder is not None
                               else _AVIWriter(self.path, self.fps))
            options = backend.mujoco.MjvOption()
            options.geomgroup[3] = options.geomgroup[4] = 0
            self.renderer.update_scene(backend.data, camera="front", scene_option=options)
            pixels = self.renderer.render()
            if pixels.shape != (HEIGHT, WIDTH, 3) or str(pixels.dtype) != "uint8":
                raise ValueError("camera must provide uint8 RGB 640x480 pixels")
            from PIL import Image, ImageDraw, ImageFont
            image = Image.fromarray(pixels)
            draw = ImageDraw.Draw(image)
            draw.rectangle((0, 0, WIDTH, 66), fill=(10, 17, 25))
            font = ImageFont.load_default(size=17)
            label = "SCRIPTED IK BASELINE" if self.controller == "scripted" else "LEARNED ACTION-CHUNK POLICY"
            draw.text((10, 7), f"SO-101 | {label} | SIMULATION ONLY", font=font, fill=(245, 247, 249))
            draw.text((10, 35), f"Physics time {actual:6.3f} s | Verdict: video_report.json",
                      font=font, fill=(181, 215, 235))
            pixels = backend.np.asarray(image, dtype=backend.np.uint8)
            # When a control step spans more than one frame boundary, identical
            # observed pixels fill those boundaries; no future state is invented.
            while self.frames/self.fps <= actual+1e-9:
                if self.frames >= MAX_FRAMES:
                    self.capture_truncated = True
                    return
                desired = self.frames/self.fps
                if desired > MAX_SECONDS:
                    raise RuntimeError("video exceeded the 20-second duration budget")
                self.writer.write(pixels)
                lateness = actual-desired
                self.max_lateness = max(self.max_lateness, lateness)
                self.timeline.write(json.dumps({"frame_index": self.frames,
                                                "video_timestamp_s": desired,
                                                "actual_simulation_timestamp_s": actual,
                                                "capture_lateness_s": lateness})+"\n")
                self.frames += 1
                self.status = "executed"
        except Exception as exc:
            self.status, self.error = "failed", f"{type(exc).__name__}: {exc}"

    def close(self):
        try:
            if self.writer is not None:
                self.writer.close()
            else:
                self.status, self.error = "failed", self.error or "camera produced no frames"
        except Exception as exc:
            self.status, self.error = "failed", f"{type(exc).__name__}: {exc}"
        finally:
            try:
                if self.renderer is not None:
                    self.renderer.close()
            except Exception as exc:
                self.status, self.error = "failed", f"camera cleanup {type(exc).__name__}: {exc}"
            finally:
                self.timeline.close()

    def report(self):
        complete = self.status == "executed"
        return {"video_status": self.status, "video_error": self.error,
                "video_path": self.path.name if self.path.exists() else None,
                "container": "mp4" if self.encoder is not None else "avi",
                "codec": "h264" if self.encoder is not None else "mjpeg",
                "resolution": [WIDTH, HEIGHT], "fps": self.fps,
                "frame_count": self.frames, "video_duration_s": self.frames/self.fps,
                "last_simulation_timestamp_s": self.last_actual_time,
                "max_capture_lateness_s": self.max_lateness,
                "timeline_path": "video_frame_timeline.jsonl",
                "encoder": str(self.encoder) if self.encoder is not None else "builtin_mjpeg_avi_writer",
                "video_sha256": hashlib.sha256(self.path.read_bytes()).hexdigest() if complete else None,
                "capture_source": "fresh_MuJoCo_front_camera_at_reset_and_after_actual_physics_steps",
                "sampling": "first_observed_control_state_at_or_after_each_fps_boundary",
                "duplicate_state_frames_possible": True, "trajectory_replay_used": False,
                "capture_truncated_by_frame_budget": self.capture_truncated,
                "visible_controller_label": "scripted IK baseline" if self.controller == "scripted" else "learned action-chunk policy",
                "teleportation_after_reset": False, "audio_recorded": False,
                "limits": {"max_seconds": MAX_SECONDS, "max_frames": MAX_FRAMES, "max_fps": 30}}


def record_simulation_video(world_path: Path, output_dir: Path, *, controller="scripted",
                            checkpoint_dir=None, seed=0, fps=15, encoder=None) -> dict:
    """Execute one fresh baseline/learned episode and preserve both video and verdict.

    A task failure can have a successfully encoded video. These two statuses are
    deliberately separate. All outputs require a new or empty evidence directory.
    """
    from .simulation import (ASSET_ROOT, _read_verified_world, evaluate_policy_in_simulation,
                             run_simulation)
    encoder = _validate_options(fps, encoder)
    if controller not in ("scripted", "learned"):
        raise ValueError("video controller must be scripted or learned")
    if type(seed) is not int or not 0 <= seed <= 2**32-1:
        raise ValueError("invalid seed")
    if controller == "learned" and checkpoint_dir is None:
        raise ValueError("learned video requires an explicit checkpoint directory")
    if controller == "scripted" and checkpoint_dir is not None:
        raise ValueError("scripted video must not claim to use a learned checkpoint")
    world_path, output_dir = Path(world_path).resolve(), Path(output_dir).resolve()
    _read_verified_world(world_path)
    protected = [ASSET_ROOT.resolve(), world_path.parent/"robot"]
    checkpoint = Path(checkpoint_dir).resolve() if checkpoint_dir is not None else None
    if checkpoint is not None:
        protected.append(checkpoint)
    if (output_dir == world_path.parent or any(output_dir.is_relative_to(path) for path in protected)
            or output_dir == output_dir.parent or output_dir.is_file()
            or (output_dir.exists() and any(output_dir.iterdir()))):
        raise ValueError("video evidence requires a new empty directory separate from inputs and assets")
    output_dir.mkdir(parents=True, exist_ok=True)
    sink = _CameraFrameSink(output_dir, fps, encoder, controller)
    simulation_report, execution_error = None, None
    try:
        if controller == "scripted":
            simulation_report = run_simulation(world_path, output_dir, seed=seed, frame_sink=sink)
        else:
            simulation_report = evaluate_policy_in_simulation(world_path, checkpoint, output_dir,
                                                              seed=seed, frame_sink=sink)
    except Exception as exc:
        execution_error = f"{type(exc).__name__}: {exc}"
    finally:
        sink.close()
    report = {"schema_version": 1, "execution_kind": "simulation", "physical_status": "not_run",
              "controller": controller,
              "ai_policy_used": bool(simulation_report and simulation_report.get("ai_policy_used")), "seed": seed,
              "policy_kind": simulation_report.get("policy_kind") if simulation_report else None,
              "checkpoint_weights_sha256": simulation_report.get("checkpoint_weights_sha256") if simulation_report else None,
              "checkpoint_manifest_sha256": simulation_report.get("checkpoint_manifest_sha256") if simulation_report else None,
              "simulation_status": simulation_report.get("simulation_status") if simulation_report else "failed",
              "execution_error": execution_error,
              "task_success": simulation_report.get("task_success") if simulation_report else None,
              "task_failure_reason": simulation_report.get("failure_reason") if simulation_report else execution_error,
              "simulated_seconds": simulation_report.get("simulated_seconds") if simulation_report else None,
              "simulation_report_path": ("simulation_report.json" if controller == "scripted"
                                          else "policy_simulation_report.json") if simulation_report else None,
              "scene_sha256": simulation_report.get("scene_sha256") if simulation_report else None,
              "world_sha256": simulation_report.get("world_sha256") if simulation_report else None,
              "video": sink.report(),
              "limitations": ["This is a simulated public model with proposed dimensions, not a physical-arm recording.",
                              "A playable video does not establish task success; inspect the separately preserved verdict.",
                              "Frames are sampled from control states; no visual interpolation or log replay is used."]}
    (output_dir/"video_report.json").write_text(json.dumps(report, ensure_ascii=False, indent=2,
                                                         allow_nan=False)+"\n", encoding="utf-8")
    return report
