"""Independent CPU MuJoCo episodes, with bounded spawn workers and live evidence.

The workers collect scripted demonstrations. This is environment parallelism,
not a new policy algorithm, GPU execution or reinforcement learning.
"""
from __future__ import annotations

from datetime import datetime, timezone
import json
import multiprocessing
import os
from pathlib import Path
import queue
import threading
import time


def validate_workers(workers: int) -> int:
    if type(workers) is not int or not 1 <= workers <= 8:
        raise ValueError("workers must be an integer from 1 through 8")
    return workers


def _timestamp() -> tuple[str, float]:
    now = time.time()
    return datetime.fromtimestamp(now, timezone.utc).isoformat(), now


def _atomic_json(path: Path, value: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2,
                                    allow_nan=False) + "\n", encoding="utf-8")
    # Windows readers may briefly hold a sharing lock while the UI polls this
    # snapshot. Retry only those known lock/access errors, with a 0.49s budget;
    # unrelated or persistent permission failures remain visible exceptions.
    for attempt in range(50):
        try:
            os.replace(temporary, path)
            return
        except PermissionError as exc:
            if getattr(exc, "winerror", None) not in (5, 32, 33) or attempt == 49:
                raise
            time.sleep(0.01)


def _failed_episode(seed: int, error: str) -> dict:
    return {"schema_version": 1, "execution_kind": "simulation",
            "physical_status": "not_run", "ai_policy_used": False,
            "policy_kind": "scripted_damped_ik_baseline", "seed": seed,
            "task_success": False, "simulation_status": "failed",
            "failure_reason": "parallel_worker_execution_failed", "execution_error": error,
            "camera_frames": [], "camera_status": "not_run",
            "max_ik_position_error_m": 0.0}


def _execute_episode(world: Path, output_dir: Path, seed: int, slot: int,
                     emit, *, startup_error: str | None = None) -> dict:
    started_at, started_unix = _timestamp()
    metadata = {"pid": os.getpid(), "worker_slot": slot,
                "started_at": started_at, "started_at_unix_s": started_unix,
                "ended_at": None, "ended_at_unix_s": None}
    output_dir.mkdir(parents=True, exist_ok=True)
    _atomic_json(output_dir / "parallel_execution.json", metadata)
    emit({"kind": "started", "seed": seed, "slot": slot, "metadata": metadata})
    try:
        if startup_error:
            raise RuntimeError(startup_error)
        from .simulation import run_simulation
        result = run_simulation(world, output_dir, seed=seed)
    except Exception as exc:
        result = _failed_episode(seed, f"{type(exc).__name__}: {exc}")
        _atomic_json(output_dir / "parallel_failure.json", result)
    ended_at, ended_unix = _timestamp()
    metadata = {**metadata, "ended_at": ended_at, "ended_at_unix_s": ended_unix}
    result["parallel_execution"] = metadata
    _atomic_json(output_dir / "parallel_execution.json", metadata)
    emit({"kind": "finished", "seed": seed, "slot": slot,
          "metadata": metadata, "result": result})
    return result


def _run_slot(world: str, output_dir: str, seeds: list[int], slot: int,
              barrier, events) -> None:
    # Each spawned child imports its own model/data and owns its renderer. Keep
    # numerical-library thread pools small instead of multiplying CPU threads.
    for name in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
                 "NUMEXPR_NUM_THREADS", "VECLIB_MAXIMUM_THREADS"):
        os.environ[name] = "1"
    startup_error = None
    try:
        barrier.wait(timeout=30)
    except threading.BrokenBarrierError:
        startup_error = "parallel_startup_barrier_timeout; episodes preserved as failures"
    for seed in seeds:
        _execute_episode(Path(world), Path(output_dir) / f"seed-{seed}", seed, slot,
                         events.put, startup_error=startup_error)


def _maximum_overlap(episodes: list[dict]) -> int:
    boundaries = []
    for episode in episodes:
        metadata = episode.get("parallel_execution", {})
        begin, end = metadata.get("started_at_unix_s"), metadata.get("ended_at_unix_s")
        if begin is not None and end is not None and end >= begin:
            boundaries.extend(((begin, 1), (end, -1)))
    active, maximum = 0, 0
    for _, delta in sorted(boundaries):
        active += delta
        maximum = max(maximum, active)
    return maximum


def collect_parallel_baselines(world: Path, output_dir: Path, seeds, *, workers=1) -> tuple[list[dict], dict]:
    """Collect ordered episodes without dropping failed or interrupted attempts.

    The same immutable XML is read by all workers. Every episode gets an
    independent MuJoCo model/data through run_simulation, plus distinct output.
    Nine episodes remain nine episodes even when eight workers collect them.
    """
    validate_workers(workers)
    seeds = list(seeds)
    if (not 1 <= len(seeds) <= 9
            or any(type(seed) is not int or not 0 <= seed <= 2**32-1 for seed in seeds)
            or len(set(seeds)) != len(seeds)):
        raise ValueError("collection requires one through nine distinct valid integer seeds")
    world, output_dir = Path(world).resolve(), Path(output_dir).resolve()
    progress_path = output_dir / "parallel_progress.json"
    if progress_path.exists() or any((output_dir / f"seed-{seed}").exists() for seed in seeds):
        raise ValueError("parallel collection evidence already exists; use a new directory")
    started = time.monotonic()
    effective = min(workers, len(seeds))
    assignments = [seeds[slot::effective] for slot in range(effective)]
    mode = "sequential" if effective == 1 else "spawn_processes"
    results, started_metadata = {}, {}
    slots = [{"slot": slot, "seed": group[0], "pid": None, "status": "pending",
              "evidence_directory": f"{output_dir.name}/seed-{group[0]}"}
             for slot, group in enumerate(assignments)]
    progress = {"schema_version": 1, "evidence_kind": "simulation",
                "physical_execution": "not_run", "requested_workers": workers,
                "effective_workers": effective, "completed": 0, "total": len(seeds),
                "mode": mode, "status": "starting", "slots": slots}

    def publish():
        progress["completed"] = len(results)
        progress["wall_seconds"] = time.monotonic() - started
        progress["updated_at"] = _timestamp()[0]
        _atomic_json(progress_path, progress)

    def handle(event):
        seed, slot = event["seed"], event["slot"]
        metadata = event["metadata"]
        row = slots[slot]
        row.update({"seed": seed, "pid": metadata["pid"],
                    "evidence_directory": f"{output_dir.name}/seed-{seed}"})
        if event["kind"] == "started":
            started_metadata[seed] = metadata
            row["status"] = "running"
            row.pop("task_success", None)
            progress["status"] = "running"
        else:
            result = event["result"]
            result["evidence_directory"] = f"{output_dir.name}/seed-{seed}"
            results[seed] = result
            row["status"] = "succeeded" if result["task_success"] else "failed"
            row["task_success"] = result["task_success"]
        publish()

    publish()
    processes = []
    if effective == 1:
        for seed in seeds:
            _execute_episode(world, output_dir / f"seed-{seed}", seed, 0, handle)
    else:
        context = multiprocessing.get_context("spawn")
        events = context.Queue()
        barrier = context.Barrier(effective)
        try:
            for slot, group in enumerate(assignments):
                process = context.Process(target=_run_slot,
                                          args=(str(world), str(output_dir), group, slot, barrier, events),
                                          name=f"so101-collection-{slot}")
                processes.append(process)
                process.start()
            deadline = time.monotonic() + 90 + 90 * max(map(len, assignments))
            exited_at = {}
            while len(results) < len(seeds):
                try:
                    handle(events.get(timeout=0.1))
                except queue.Empty:
                    pass
                now = time.monotonic()
                for slot, process in enumerate(processes):
                    if process.exitcode is not None:
                        exited_at.setdefault(slot, now)
                        if now - exited_at[slot] > 1:
                            for seed in assignments[slot]:
                                if seed not in results:
                                    error = f"worker exited with code {process.exitcode} before returning evidence"
                                    _preserve_missing(seed, slot, process.pid, error, output_dir,
                                                      started_metadata, handle)
                if now > deadline:
                    for process in processes:
                        if process.is_alive():
                            process.terminate()
                    for process in processes:
                        process.join(timeout=2)
                    for slot, process in enumerate(processes):
                        for seed in assignments[slot]:
                            if seed not in results:
                                _preserve_missing(seed, slot, process.pid, "collection wall-clock budget exceeded",
                                                  output_dir, started_metadata, handle)
        except Exception as exc:
            # Stop writers before preserving missing results in their output
            # directories; parent/child writes must never race on failure.
            for process in processes:
                if process.pid is not None and process.is_alive():
                    process.terminate()
            for process in processes:
                if process.pid is not None:
                    process.join(timeout=2)
            for slot, group in enumerate(assignments):
                pid = processes[slot].pid if slot < len(processes) else None
                for seed in group:
                    if seed not in results:
                        _preserve_missing(seed, slot, pid, f"{type(exc).__name__}: {exc}", output_dir,
                                          started_metadata, handle)
        finally:
            for process in processes:
                if process.pid is not None:
                    process.join(timeout=2)
                    if process.is_alive():
                        process.terminate()
                        process.join(timeout=2)
            events.close()
            events.join_thread()
    episodes = [results[seed] for seed in seeds]
    progress["status"] = "completed" if all(row["task_success"] for row in episodes) else "completed_with_failures"
    publish()
    metadata = {"evidence_kind": "simulation", "execution_kind": "simulation", "requested_workers": workers,
                "effective_workers": effective, "mode": mode, "episodes": len(episodes),
                "max_concurrent_observed": _maximum_overlap(episodes),
                "unique_worker_pids": sorted({row["parallel_execution"]["pid"] for row in episodes
                                               if row["parallel_execution"]["pid"] is not None}),
                "wall_seconds": time.monotonic() - started,
                "progress_path": f"{output_dir.name}/parallel_progress.json",
                "ordering": "requested_seed_order", "immutable_world_path": str(world),
                "independent_model_and_data_per_episode": True,
                "concurrency_measurement": "wall-clock overlap of episode initialization, physics and evidence rendering",
                "worker_numeric_thread_limit": 1 if effective > 1 else None,
                "algorithm": "scripted_demonstration_collection; policy training remains behavior cloning",
                "physical_execution": "not_run", "execution_device": "CPU"}
    _atomic_json(output_dir / "parallel_collection.json", metadata)
    return episodes, metadata


def _preserve_missing(seed, slot, pid, error, output_dir, started_metadata, handle):
    end, end_unix = _timestamp()
    metadata = started_metadata.get(seed, {"pid": pid, "worker_slot": slot,
                                          "started_at": None, "started_at_unix_s": None})
    metadata = {**metadata, "ended_at": end, "ended_at_unix_s": end_unix}
    result = _failed_episode(seed, error)
    result["parallel_execution"] = metadata
    destination = output_dir / f"seed-{seed}"
    _atomic_json(destination / "parallel_failure.json", result)
    _atomic_json(destination / "parallel_execution.json", metadata)
    handle({"kind": "finished", "seed": seed, "slot": slot, "metadata": metadata, "result": result})
