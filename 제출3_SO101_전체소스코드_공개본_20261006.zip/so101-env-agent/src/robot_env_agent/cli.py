"""Local CLI for static intake, real physics and bounded AI workflows."""

import argparse
import json
from pathlib import Path

from .calibration import inspect_archive
from .contracts import parse_profile, parse_task, validate
from .runtime import build_draft, plan, read_json, resolve_output, resolve_path, run_mock, write_json


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="SO-101 environment construction and validation agent")
    parser.add_argument("--project-root", default=".")
    commands = parser.add_subparsers(dest="command", required=True)
    inspect = commands.add_parser("inspect", help="Read and validate a local calibration ZIP")
    inspect.add_argument("--archive", required=True)
    inspect.add_argument("--output", required=True)
    for name in ("validate", "plan", "build"):
        sub = commands.add_parser(name)
        sub.add_argument("--profile", required=True)
        sub.add_argument("--task", required=True)
        sub.add_argument("--output", required=True)
    mock = commands.add_parser("run-mock", help="Synthetic control-flow check; no physics")
    mock.add_argument("--bundle", required=True)
    mock.add_argument("--steps", type=int, default=3)
    mock.add_argument("--output", required=True)
    for name in ("demo", "agent"):
        sub = commands.add_parser(name, help="Local AI goal routing, MuJoCo, learning and evidence")
        sub.add_argument("--goal", default="부품을 한 트레이에서 다른 트레이로 옮겨줘")
        sub.add_argument("--scene", default="configs/scene.simulation.json")
        sub.add_argument("--output-dir", required=True)
        sub.add_argument("--epochs", type=int, default=60)
        sub.add_argument("--skip-training", action="store_true")
        sub.add_argument("--workers", type=int, choices=range(1, 9), default=1,
                         help="Independent CPU simulation collectors (1 through 8); nine training episodes remain fixed")
    build_sim = commands.add_parser("build-sim", help="Construct an assumed MuJoCo world")
    build_sim.add_argument("--scene", default="configs/scene.simulation.json")
    build_sim.add_argument("--output-dir", required=True)
    sim = commands.add_parser("run-sim", help="Execute a contact-based scripted baseline")
    sim.add_argument("--world", required=True)
    sim.add_argument("--seed", type=int, default=0)
    sim.add_argument("--output-dir", required=True)
    viewing = commands.add_parser("view-sim", help="Open an interactive scene inspection window")
    viewing.add_argument("--world", required=True)
    viewing.add_argument("--seed", type=int, default=0)
    viewing.add_argument("--seconds", type=float, default=300)
    recording = commands.add_parser("record-video", help="Record actual simulated motion and its task result")
    recording.add_argument("--world", required=True)
    recording.add_argument("--controller", choices=("scripted", "learned"), default="scripted")
    recording.add_argument("--checkpoint")
    recording.add_argument("--seed", type=int, default=0)
    recording.add_argument("--fps", type=int, default=15)
    recording.add_argument("--encoder")
    recording.add_argument("--output-dir", required=True)
    training = commands.add_parser("train", help="Fit a small action-chunk policy on split episodes")
    training.add_argument("--dataset", required=True)
    training.add_argument("--epochs", type=int, default=60)
    training.add_argument("--backend", choices=("torch", "numpy", "auto"), default="torch")
    training.add_argument("--output-dir", required=True)
    fitting = commands.add_parser("fit-response", help="Fit scalar gain/delay on a recorded response file")
    fitting.add_argument("--log", required=True)
    fitting.add_argument("--output-dir", required=True)
    args = parser.parse_args(argv)
    root = Path(args.project_root)
    try:
        if args.command == "view-sim":
            from .viewer import inspect_world
            report = inspect_world(resolve_path(root, args.world), seed=args.seed, seconds=args.seconds)
            print(json.dumps(report, ensure_ascii=False))
            return 0
        if hasattr(args, "output_dir"):
            from .workflow import resolve_run_directory, run_workflow
            output_dir = resolve_run_directory(root, args.output_dir)
            if args.command in ("demo", "agent"):
                report = run_workflow(root, output_dir, goal=args.goal,
                                      scene=read_json(resolve_path(root, args.scene)),
                                      epochs=args.epochs, train=not args.skip_training, workers=args.workers)
            elif args.command == "build-sim":
                from .simulation import build_world
                report = build_world(output_dir, read_json(resolve_path(root, args.scene)))
            elif args.command == "run-sim":
                from .simulation import run_simulation
                report = run_simulation(resolve_path(root, args.world), output_dir, args.seed)
            elif args.command == "train":
                from .learning import train_chunk_policy
                report = train_chunk_policy(resolve_path(root, args.dataset), output_dir,
                                            epochs=args.epochs, backend=args.backend)
            elif args.command == "record-video":
                from .video import record_simulation_video
                report = record_simulation_video(resolve_path(root, args.world), output_dir,
                                                 controller=args.controller,
                                                 checkpoint_dir=resolve_path(root, args.checkpoint) if args.checkpoint else None,
                                                 seed=args.seed, fps=args.fps, encoder=args.encoder)
            else:
                from .identification import compare_and_fit
                report = compare_and_fit(resolve_path(root, args.log), output_dir)
            # Video capture completion and the recorded controller result are
            # independent. A valid clip of a failed learned policy exits zero.
            if args.command == "record-video":
                status = 0 if report.get("video", {}).get("video_status") == "executed" and report.get("execution_error") is None else 2
            else:
                status = 2 if report.get("status") in ("failed", "unsupported") or report.get("task_success") is False else 0
            print(json.dumps({"command": args.command, "execution_kind": report.get("execution_kind", "simulation"),
                              "output": str(output_dir.relative_to(root.resolve())),
                              "status": "failed" if status else report.get("status", "executed"),
                              "video_status": report.get("video", {}).get("video_status"),
                              "task_success": report.get("task_success"), "exit_status": status}, ensure_ascii=False))
            return status
        output_path = resolve_output(root, args.output)
        source_paths = [resolve_path(root, getattr(args, key)) for key in ("archive", "profile", "task", "bundle")
                        if hasattr(args, key)]
        if output_path in source_paths:
            raise ValueError("output must not overwrite an input")
        validation_output = resolve_output(root, str(output_path.with_name(output_path.stem + ".validation.json")))
        if args.command == "build" and validation_output in source_paths:
            raise ValueError("validation output must not overwrite an input")
        status = 0
        if args.command == "inspect":
            report = inspect_archive(source_paths[0])
            report["execution_kind"] = "static"
            if not report["candidates"] or any(candidate["validation_status"] == "failed" for candidate in report["candidates"]):
                status = 2
        elif args.command == "run-mock":
            report = run_mock(read_json(source_paths[0]), args.steps)
        else:
            profile = parse_profile(read_json(source_paths[0]))
            task = parse_task(read_json(source_paths[1]))
            if args.command == "validate":
                report = validate(profile, task).to_dict()
                status = 2 if report["errors"] else 0
            elif args.command == "plan":
                report = plan(profile, task)
                status = 2 if report["validation"]["errors"] else 0
            else:
                report, build_report = build_draft(profile, task)
                write_json(validation_output, build_report)
        write_json(output_path, report)
        print(json.dumps({"command": args.command, "execution_kind": report["execution_kind"],
                          "output": str(output_path.relative_to(root.resolve())), "exit_status": status}, ensure_ascii=False))
        return status
    except (OSError, ValueError, KeyError, TypeError, PermissionError, RuntimeError, RecursionError) as error:
        print(json.dumps({"status": "failed", "error": str(error)}, ensure_ascii=False))
        return 2
