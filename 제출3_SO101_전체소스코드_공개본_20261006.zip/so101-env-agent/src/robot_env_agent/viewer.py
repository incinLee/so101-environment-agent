"""Interactive scene inspection, separate from controller task evaluation."""

import math
import time
from pathlib import Path


def inspect_world(world_path: Path, *, seed=0, seconds=300) -> dict:
    if type(seed) is not int or not 0 <= seed <= 2**32-1:
        raise ValueError("invalid seed")
    if type(seconds) not in (int, float) or not math.isfinite(seconds) or not 1 <= seconds <= 600:
        raise ValueError("viewer duration must be 1 through 600 seconds")
    from .simulation import MuJoCoBackend, _read_verified_world
    import mujoco.viewer
    manifest, _ = _read_verified_world(world_path)
    backend = MuJoCoBackend(world_path)
    backend.reset(seed)
    started = time.monotonic()
    sync_count = 0
    with mujoco.viewer.launch_passive(backend.model, backend.data) as handle:
        with handle.lock():
            handle.cam.type = backend.mujoco.mjtCamera.mjCAMERA_FREE
            handle.cam.lookat[:] = [0.15, 0, 0.08]
            handle.cam.distance, handle.cam.azimuth, handle.cam.elevation = 0.8, 135, -25
            handle.opt.geomgroup[3] = handle.opt.geomgroup[4] = 0
        while handle.is_running() and time.monotonic()-started < seconds:
            handle.sync(state_only=True)
            sync_count += 1
            time.sleep(1/60)
    return {"status": "passed", "execution_kind": "scene_inspection", "physical_status": "not_run",
            "scene_sha256": manifest["scene_sha256"], "viewer_sync_count": sync_count,
            "wall_seconds": time.monotonic()-started, "physics_steps": 0,
            "task_success": "not_evaluated", "controller_executed": False,
            "limitations": ["Interactive model and camera inspection only; no tray-transfer controller.",
                            "GUI state edits are not saved as task evaluation evidence."]}
