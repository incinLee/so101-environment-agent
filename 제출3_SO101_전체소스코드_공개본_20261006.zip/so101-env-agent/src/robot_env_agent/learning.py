"""Small supervised action-chunk learning; synthetic evidence is never task success.

The optional Torch model is an ACT-style smoke model, not an ACT reproduction:
it has no image encoder, latent CVAE, or original ACT training implementation.
NPZ weights avoid pickle deserialization. This module never accesses a device.
"""

import hashlib
import importlib.util
import io
import json
import math
import zipfile
from pathlib import Path

MAX_ARCHIVE_BYTES = 64 * 1024 * 1024
MAX_NPY_HEADER_BYTES = 64 * 1024
MAX_ARRAY_DIMENSIONS = 4
MAX_ARRAY_AXIS = 100000
MAX_WINDOWS = 20000
MAX_TRAIN_UPDATES = 3000
DATA_KEYS = {"observations", "actions", "episode_ids", "splits", "timestamps_s", "metadata_json"}
LABEL_SOURCES = {"synthetic_function", "scripted_controller", "human_demonstration", "simulated_teleoperation"}
ACTION_UNITS = {"rad", "deg", "m", "normalized"}
ACTION_SEMANTICS = {"absolute_joint_position", "delta_joint_position", "cartesian_position", "actuator_position", "synthetic_target"}


def _numpy():
    try:
        import numpy as np
    except ImportError as error:
        raise RuntimeError("numpy is required for action-chunk learning") from error
    return np


def _json_write(path: Path, payload: dict):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def _checked_npy_header(prefix: bytes, member_size: int, np) -> tuple:
    """Read only a bounded header and prove payload size before any array view."""
    stream = io.BytesIO(prefix)
    try:
        version = np.lib.format.read_magic(stream)
        if version == (1, 0):
            length_width, reader = 2, np.lib.format.read_array_header_1_0
        elif version == (2, 0):
            length_width, reader = 4, np.lib.format.read_array_header_2_0
        else:
            raise ValueError("unsupported NPY version; only 1.0 and 2.0 are allowed")
        overhead = 8 + length_width
        if len(prefix) < overhead:
            raise ValueError("truncated NPY header length")
        header_length = int.from_bytes(prefix[8:overhead], "little")
        if header_length > MAX_NPY_HEADER_BYTES - overhead:
            raise ValueError("NPY header exceeds 64 KiB budget")
        if overhead + header_length > len(prefix):
            raise ValueError("truncated NPY header")
        shape, fortran_order, dtype = reader(stream, max_header_size=MAX_NPY_HEADER_BYTES)
    except (EOFError, UnicodeError, OverflowError, RecursionError, SyntaxError) as error:
        raise ValueError("invalid bounded NPY header") from error
    if dtype.hasobject:
        raise ValueError("object arrays are not allowed")
    if dtype.fields is not None or dtype.subdtype is not None or dtype.kind not in "fiuUS":
        raise ValueError("only primitive numeric and string NPY dtypes are allowed")
    if dtype.itemsize <= 0 or dtype.itemsize > MAX_ARCHIVE_BYTES:
        raise ValueError("NPY dtype size exceeds budget")
    if len(shape) > MAX_ARRAY_DIMENSIONS or any(type(axis) is not int or not 0 <= axis <= MAX_ARRAY_AXIS for axis in shape):
        raise ValueError("NPY shape dimensions exceed budget")
    elements = math.prod(shape)
    expected_bytes = elements * dtype.itemsize
    header_bytes = stream.tell()
    if expected_bytes > MAX_ARCHIVE_BYTES:
        raise ValueError("NPY shape payload exceeds 64 MiB budget")
    if member_size - header_bytes != expected_bytes:
        raise ValueError("NPY declared shape does not exactly match payload size")
    return shape, fortran_order, dtype, header_bytes, expected_bytes


def _load_npz(path: Path):
    np = _numpy()
    path = Path(path)
    if path.stat().st_size > MAX_ARCHIVE_BYTES:
        raise ValueError("NPZ compressed input exceeds 64 MiB budget")
    with zipfile.ZipFile(path) as archive:
        entries = archive.infolist()
        if len(entries) > 256 or sum(item.file_size for item in entries) > MAX_ARCHIVE_BYTES:
            raise ValueError("NPZ expanded input exceeds budget")
        if len({item.filename for item in entries}) != len(entries):
            raise ValueError("duplicate NPZ entries")
        checked = {}
        for item in entries:
            if (item.is_dir() or not item.filename.endswith(".npy") or "/" in item.filename
                    or "\\" in item.filename or item.flag_bits & 1
                    or item.compress_type not in {zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED}):
                raise ValueError("NPZ must contain unencrypted flat stored/deflated NPY entries")
            with archive.open(item) as member:
                prefix = member.read(min(item.file_size, MAX_NPY_HEADER_BYTES))
            checked[item.filename] = _checked_npy_header(prefix, item.file_size, np)
        if sum(header[4] for header in checked.values()) > MAX_ARCHIVE_BYTES:
            raise ValueError("NPZ derived array payload exceeds budget")
        values = {}
        for item in entries:
            # A bounded immutable snapshot also avoids reopening a changed pathname.
            with archive.open(item) as member:
                payload = member.read(item.file_size + 1)
            if len(payload) != item.file_size:
                raise ValueError("NPY payload size changed after header validation")
            header = _checked_npy_header(payload[:MAX_NPY_HEADER_BYTES], len(payload), np)
            if header != checked[item.filename]:
                raise ValueError("NPY header changed after validation")
            shape, fortran_order, dtype, offset, _ = header
            # frombuffer cannot allocate memory for a fabricated header shape. The
            # already checked byte length bounds the immutable backing storage.
            values[item.filename[:-4]] = np.frombuffer(payload, dtype=dtype, count=math.prod(shape),
                                                       offset=offset).reshape(shape, order="F" if fortran_order else "C")
    return values


def _strict_json(text: str):
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError("duplicate metadata key")
            result[key] = value
        return result
    if len(text) > 65536:
        raise ValueError("metadata exceeds budget")
    result = json.loads(text, object_pairs_hook=pairs,
                        parse_constant=lambda value: (_ for _ in ()).throw(ValueError("nonfinite JSON number")))
    if not isinstance(result, dict):
        raise ValueError("metadata must be an object")
    return result


def _episode_groups(episode_ids):
    """Stable groups avoid an O(episodes * samples) full-array scan."""
    np = _numpy()
    order = np.argsort(episode_ids, kind="stable")
    if not len(order):
        return
    sorted_ids = episode_ids[order]
    boundaries = np.concatenate(([0], np.flatnonzero(sorted_ids[1:] != sorted_ids[:-1]) + 1, [len(order)]))
    for begin, end in zip(boundaries[:-1], boundaries[1:]):
        yield str(sorted_ids[begin]), order[begin:end]


def load_chunk_dataset(dataset_path: Path) -> dict:
    """Validate action labels, contracts, timestamps and episode-level splits."""
    np = _numpy()
    data = _load_npz(Path(dataset_path))
    if set(data) != DATA_KEYS:
        raise ValueError(f"dataset requires exactly {sorted(DATA_KEYS)}")
    if data["metadata_json"].shape != () or data["metadata_json"].dtype.kind not in "US":
        raise ValueError("metadata_json must be one JSON string")
    metadata = _strict_json(str(data["metadata_json"].item()))
    if type(metadata.get("schema_version")) is not int or metadata["schema_version"] != 1:
        raise ValueError("unsupported dataset schema")
    if metadata.get("data_kind") not in {"synthetic", "simulation", "real_recorded"}:
        raise ValueError("dataset data_kind must be explicit")
    if metadata.get("label_source") not in LABEL_SOURCES:
        raise ValueError("actions require declared demonstrations or labelled synthetic function; random actions are not demonstrations")
    if metadata["label_source"] == "synthetic_function" and metadata["data_kind"] != "synthetic":
        raise ValueError("synthetic labels require data_kind=synthetic")
    if metadata.get("action_unit") not in ACTION_UNITS or metadata.get("action_semantics") not in ACTION_SEMANTICS:
        raise ValueError("action unit and semantics must be known")
    if metadata.get("time_unit") != "s" or not isinstance(metadata.get("clock_domain"), str) or not metadata["clock_domain"]:
        raise ValueError("timestamp unit and clock domain must be explicit")
    obs, act = data["observations"], data["actions"]
    if obs.ndim != 2 or act.ndim != 2 or not 6 <= len(obs) <= 100000 or len(obs) != len(act):
        raise ValueError("observations/actions must be aligned [N,D] arrays")
    if not 1 <= obs.shape[1] <= 512 or not 1 <= act.shape[1] <= 64:
        raise ValueError("feature dimensions exceed budget")
    for value in (obs, act, data["timestamps_s"]):
        if value.dtype.kind not in "fi" or not np.isfinite(value).all():
            raise ValueError("numeric arrays must contain finite real values")
    for key in ("episode_ids", "splits", "timestamps_s"):
        if data[key].shape != (len(obs),):
            raise ValueError(f"{key} must have shape [N]")
    if data["episode_ids"].dtype.kind not in "USiu" or data["splits"].dtype.kind not in "US":
        raise ValueError("episode IDs and splits must be non-object identifiers")
    # Promotion of int8/byte-string data is itself an allocation; budget that
    # representation before astype, not merely the compressed input's size.
    def unicode_bytes(value):
        if value.dtype.kind in "iu":
            return value.size * 21 * 4
        return value.nbytes * (4 if value.dtype.kind == "S" else 1)
    promoted_bytes = ((obs.size + act.size) * 8 + data["timestamps_s"].nbytes
                      + unicode_bytes(data["episode_ids"]) + unicode_bytes(data["splits"]))
    if promoted_bytes > MAX_ARCHIVE_BYTES:
        raise ValueError("dataset promoted representation exceeds 64 MiB budget")
    data["episode_ids"] = data["episode_ids"].astype(str)
    data["splits"] = data["splits"].astype(str)
    if set(data["splits"].tolist()) != {"train", "validation", "test"}:
        raise ValueError("separate train, validation and final test splits are required")
    verified_period = None
    for episode, indices in _episode_groups(data["episode_ids"]):
        if not episode or len(set(data["splits"][indices].tolist())) != 1:
            raise ValueError("one episode cannot cross split boundaries")
        if len(indices) < 2 or not (np.diff(data["timestamps_s"][indices]) > 0).all():
            raise ValueError("timestamps must strictly increase within each episode")
        periods = np.diff(data["timestamps_s"][indices])
        period = float(periods[0])
        if not np.allclose(periods, period, rtol=1e-5, atol=1e-8):
            raise ValueError("action chunks require fixed sampling; resampling is a separate explicit step")
        if verified_period is not None and not math.isclose(period, verified_period, rel_tol=1e-5, abs_tol=1e-8):
            raise ValueError("episode sampling periods must match the same action-chunk contract")
        verified_period = period
    for key, width in (("observation_names", obs.shape[1]), ("action_names", act.shape[1])):
        names = metadata.get(key)
        if (not isinstance(names, list) or len(names) != width or
                any(not isinstance(name, str) or not name for name in names) or len(set(names)) != len(names)):
            raise ValueError(f"{key} must match feature names/order")
    data["observations"], data["actions"] = obs.astype("float64"), act.astype("float64")
    data["timestamps_s"] = data["timestamps_s"].copy()
    data["metadata"] = metadata
    data["sample_period_s_verified"] = verified_period
    data["source_sha256"] = hashlib.sha256(Path(dataset_path).read_bytes()).hexdigest()
    return data


def write_chunk_dataset(dataset_path: Path, *, observations, actions, episode_ids,
                        splits, timestamps_s, metadata: dict) -> Path:
    """Write an explicit labelled dataset; validate before replacing any target."""
    np = _numpy()
    path = Path(dataset_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".writing.npz")
    try:
        np.savez_compressed(temporary, observations=np.asarray(observations), actions=np.asarray(actions),
                            episode_ids=np.asarray(episode_ids), splits=np.asarray(splits),
                            timestamps_s=np.asarray(timestamps_s),
                            metadata_json=np.asarray(json.dumps(metadata, allow_nan=False)))
        load_chunk_dataset(temporary)
        temporary.replace(path)
    finally:
        temporary.unlink(missing_ok=True)
    return path


def create_synthetic_chunk_dataset(dataset_path: Path, *, episodes=9, steps=24, seed=7) -> Path:
    """Analytic labelled smoke fixture, not robot demonstrations or task success."""
    np = _numpy()
    if type(episodes) is not int or type(steps) is not int or not 6 <= episodes <= 30 or not 8 <= steps <= 100:
        raise ValueError("synthetic fixture size exceeds bounds")
    rng = np.random.default_rng(seed)
    obs, actions, ids, splits, times = [], [], [], [], []
    for episode in range(episodes):
        split = "train" if episode < episodes - 4 else ("validation" if episode < episodes - 2 else "test")
        offset = rng.uniform(-0.4, 0.4, 2)
        for step in range(steps):
            t = step / 20.0
            state = [offset[0], offset[1], t, 1.0]
            # Labelled deterministic function; random offsets are inputs, never action labels.
            target = [0.6 * offset[0] + 0.3 * t, -0.5 * offset[1] - 0.2 * t]
            obs.append(state); actions.append(target); ids.append(f"synthetic-{episode}")
            splits.append(split); times.append(t)
    return write_chunk_dataset(dataset_path, observations=obs, actions=actions, episode_ids=ids,
                               splits=splits, timestamps_s=times,
                               metadata={"schema_version": 1, "data_kind": "synthetic",
                                         "label_source": "synthetic_function", "time_unit": "s",
                                         "clock_domain": "synthetic_episode_time", "action_unit": "normalized",
                                         "action_semantics": "synthetic_target",
                                         "observation_names": ["offset_x", "offset_y", "time", "constant"],
                                         "action_names": ["analytic_target_x", "analytic_target_y"]})


def create_synthetic_demonstrations(output_path: Path) -> dict:
    """Return a labelled toy fixture manifest; these are not physical trajectories."""
    path = create_synthetic_chunk_dataset(Path(output_path))
    data = load_chunk_dataset(path)
    return {"status": "passed", "execution_kind": "synthetic", "dataset_path": str(path),
            "dataset_sha256": data["source_sha256"], "samples": len(data["observations"]),
            "label_source": "synthetic_function", "physical_trajectory": False,
            "task_success": "not_evaluated", "real_robot_validation": "not_run"}


def _window_plan(data: dict, chunk_size: int, split: str) -> dict:
    """Count and budget future arrays without constructing the action chunks."""
    np = _numpy()
    if type(chunk_size) is not int or not 1 <= chunk_size <= 32:
        raise ValueError("chunk size exceeds bounded window limits")
    selected = data["episode_ids"][data["splits"] == split]
    _, counts = np.unique(selected, return_counts=True)
    count = sum(max(int(size) - chunk_size + 1, 0) for size in counts)
    if count == 0:
        raise ValueError(f"{split} has no complete action chunk")
    if count > MAX_WINDOWS:
        raise ValueError("action window count budget exceeded before allocation")
    obs, actions = data["observations"], data["actions"]
    estimated_bytes = count * (obs.shape[1] * obs.dtype.itemsize + chunk_size * actions.shape[1] * actions.dtype.itemsize)
    if estimated_bytes > MAX_ARCHIVE_BYTES:
        raise ValueError("action window output exceeds 64 MiB budget before allocation")
    return {"count": count, "estimated_bytes": estimated_bytes}


def _allocate_windows(data: dict, count: int, chunk_size: int):
    np = _numpy()
    return (np.empty((count, data["observations"].shape[1]), dtype=data["observations"].dtype),
            np.empty((count, chunk_size, data["actions"].shape[1]), dtype=data["actions"].dtype))


def _windows(data: dict, chunk_size: int, split: str):
    np = _numpy()
    plan = _window_plan(data, chunk_size, split)
    xs, ys = _allocate_windows(data, plan["count"], chunk_size)
    cursor = 0
    for _, grouped in _episode_groups(data["episode_ids"]):
        indices = grouped[data["splits"][grouped] == split]
        for start in range(len(indices) - chunk_size + 1):
            xs[cursor] = data["observations"][indices[start]]
            ys[cursor] = data["actions"][indices[start:start + chunk_size]]
            cursor += 1
    return xs, ys


def _torch_model(observation_dim: int, action_dim: int, chunk_size: int):
    import torch
    from torch import nn
    class TinyActionChunkTransformer(nn.Module):
        def __init__(self):
            super().__init__()
            self.obs_projection = nn.Linear(observation_dim, 32)
            self.queries = nn.Parameter(torch.zeros(chunk_size, 32))
            nn.init.normal_(self.queries, std=0.02)
            layer = nn.TransformerEncoderLayer(d_model=32, nhead=4, dim_feedforward=64,
                                               dropout=0.0, batch_first=True, activation="gelu")
            self.encoder = nn.TransformerEncoder(layer, num_layers=2, enable_nested_tensor=False)
            self.output = nn.Linear(32, action_dim)
        def forward(self, observation):
            token = self.obs_projection(observation).unsqueeze(1)
            queries = self.queries.unsqueeze(0).expand(len(observation), -1, -1)
            encoded = self.encoder(torch.cat((token, queries), dim=1))
            return self.output(encoded[:, 1:])
    return TinyActionChunkTransformer()


class ChunkPolicy:
    """Pure CPU inference in the stored observation/action contract."""
    def __init__(self, manifest: dict, weights: dict):
        np = _numpy()
        self.manifest, self.weights = manifest, weights
        self.model = None
        if manifest["backend"] == "torch_tiny_chunk_transformer":
            import torch
            self.model = _torch_model(manifest["observation_dim"], manifest["action_dim"], manifest["chunk_size"])
            expected = self.model.state_dict()
            if set(weights) - {"obs_mean", "obs_std", "action_mean", "action_std"} != set(expected):
                raise ValueError("checkpoint parameter names mismatch")
            state = {}
            for key, value in expected.items():
                if tuple(weights[key].shape) != tuple(value.shape):
                    raise ValueError("checkpoint parameter shape mismatch")
                state[key] = torch.from_numpy(weights[key].copy()).to(dtype=value.dtype)
            self.model.load_state_dict(state, strict=True)
            self.model.eval()
        elif manifest["backend"] == "numpy_ridge_chunk":
            required = {"coef", "obs_mean", "obs_std", "action_mean", "action_std"}
            expected_shape = (manifest["observation_dim"] + 1, manifest["chunk_size"] * manifest["action_dim"])
            if set(weights) != required or weights["coef"].shape != expected_shape:
                raise ValueError("ridge checkpoint shape mismatch")
        else:
            raise ValueError("unsupported learning backend")
        for key, width in (("obs_mean", manifest["observation_dim"]), ("obs_std", manifest["observation_dim"]),
                           ("action_mean", manifest["action_dim"]), ("action_std", manifest["action_dim"])):
            if weights[key].shape != (width,) or not np.isfinite(weights[key]).all():
                raise ValueError("checkpoint normalization mismatch")
        if (weights["obs_std"] <= 0).any() or (weights["action_std"] <= 0).any():
            raise ValueError("checkpoint scale must be positive")

    def predict(self, observation):
        np = _numpy()
        value = np.asarray(observation, dtype="float64")
        single = value.ndim == 1
        if single:
            value = value[None, :]
        if value.ndim != 2 or value.shape[1] != self.manifest["observation_dim"] or len(value) > 20000 or not np.isfinite(value).all():
            raise ValueError("observation does not match finite named feature contract")
        normalized = (value - self.weights["obs_mean"]) / self.weights["obs_std"]
        if self.model is None:
            output = np.column_stack((normalized, np.ones(len(value)))) @ self.weights["coef"]
            output = output.reshape(len(value), self.manifest["chunk_size"], self.manifest["action_dim"])
        else:
            import torch
            with torch.no_grad():
                output = self.model(torch.from_numpy(normalized.astype("float32"))).numpy()
        result = output * self.weights["action_std"] + self.weights["action_mean"]
        if not np.isfinite(result).all():
            raise ValueError("policy prediction is nonfinite")
        return result[0] if single else result


def train_chunk_policy(dataset_path: Path, output_dir: Path, epochs=30, chunk_size=4, backend="auto", seed=7) -> dict:
    """Fit train episodes only; report train/validation error, never tune on test."""
    np = _numpy()
    if type(epochs) is not int or not 1 <= epochs <= 200 or type(chunk_size) is not int or not 1 <= chunk_size <= 32:
        raise ValueError("epochs/chunk size exceed bounded smoke training limits")
    if backend not in {"auto", "torch", "numpy"}:
        raise ValueError("backend must be auto, torch or numpy")
    if Path(dataset_path).resolve() in {(Path(output_dir) / name).resolve() for name in ("weights.npz", "policy_manifest.json", "training_report.json")}:
        raise ValueError("training output must not overwrite its source dataset")
    data = load_chunk_dataset(Path(dataset_path))
    plans = {split: _window_plan(data, chunk_size, split) for split in ("train", "validation", "test")}
    if sum(plan["estimated_bytes"] for plan in plans.values()) > MAX_ARCHIVE_BYTES:
        raise ValueError("combined action window output exceeds 64 MiB budget before allocation")
    if math.ceil(plans["train"]["count"] / 64) * epochs > MAX_TRAIN_UPDATES:
        raise ValueError("training update budget exceeded before window allocation")
    x, y = _windows(data, chunk_size, "train")
    vx, vy = _windows(data, chunk_size, "validation")
    _windows(data, chunk_size, "test")  # Readiness only: test values never used for fitting or selection.
    train_mask = data["splits"] == "train"
    obs_mean = data["observations"][train_mask].mean(axis=0)
    obs_std = np.maximum(data["observations"][train_mask].std(axis=0), 1e-6)
    act_mean = data["actions"][train_mask].mean(axis=0)
    act_std = np.maximum(data["actions"][train_mask].std(axis=0), 1e-6)
    nx, ny = (x - obs_mean) / obs_std, (y - act_mean) / act_std
    weights = {"obs_mean": obs_mean, "obs_std": obs_std, "action_mean": act_mean, "action_std": act_std}
    torch_available = importlib.util.find_spec("torch") is not None
    if backend == "torch" and not torch_available:
        raise RuntimeError("PyTorch is not installed; install the approved optional CPU dependency or choose numpy")
    use_torch = backend == "torch" or (backend == "auto" and torch_available)
    losses = []
    if use_torch:
        import torch
        torch.manual_seed(seed)
        model = _torch_model(x.shape[1], y.shape[2], chunk_size)
        optim = torch.optim.Adam(model.parameters(), lr=0.003)
        tx, ty = torch.from_numpy(nx.astype("float32")), torch.from_numpy(ny.astype("float32"))
        generator = torch.Generator().manual_seed(seed)
        previous_threads = torch.get_num_threads()
        torch.set_num_threads(min(previous_threads, 2))
        try:
            model.train()
            for _ in range(epochs):
                order = torch.randperm(len(tx), generator=generator)
                total = 0.0
                for start in range(0, len(tx), 64):
                    indices = order[start:start + 64]
                    optim.zero_grad()
                    loss = torch.mean((model(tx[indices]) - ty[indices]) ** 2)
                    if not torch.isfinite(loss):
                        raise ValueError("training became nonfinite")
                    loss.backward()
                    torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
                    optim.step()
                    total += float(loss.detach()) * len(indices)
                losses.append(total / len(tx))
            weights.update({key: value.detach().cpu().numpy().copy() for key, value in model.state_dict().items()})
        finally:
            torch.set_num_threads(previous_threads)
        backend_id = "torch_tiny_chunk_transformer"
    else:
        design = np.column_stack((nx, np.ones(len(nx))))
        penalty = np.eye(design.shape[1]) * 1e-3
        penalty[-1, -1] = 0.0
        weights["coef"] = np.linalg.solve(design.T @ design + penalty, design.T @ ny.reshape(len(ny), -1))
        backend_id = "numpy_ridge_chunk"
    manifest = {"schema_version": 1, "backend": backend_id, "observation_dim": x.shape[1],
                "action_dim": y.shape[2], "chunk_size": chunk_size, "seed": seed,
                "contract": data["metadata"], "dataset_sha256": data["source_sha256"],
                "sample_period_s_verified": data["sample_period_s_verified"],
                "train_episode_ids": sorted(set(data["episode_ids"][train_mask].tolist())),
                "validation_episode_ids": sorted(set(data["episode_ids"][data["splits"] == "validation"].tolist())),
                "normalization_fit_split": "train", "weights_file": "weights.npz"}
    policy = ChunkPolicy(manifest, weights)
    train_prediction, validation_prediction = policy.predict(x), policy.predict(vx)
    report = {"status": "passed", "execution_kind": data["metadata"]["data_kind"],
              "backend": backend_id, "model_scope": "ACT-style tiny action-chunk smoke model; not original ACT" if use_torch else "linear supervised action-chunk baseline; not ACT",
              "epochs_completed": epochs if use_torch else 0, "fit_method": "gradient_descent" if use_torch else "ridge_closed_form",
              "training_windows": len(x), "validation_windows": len(vx),
              "train_mae": float(np.abs(train_prediction - y).mean()),
              "validation_mae": float(np.abs(validation_prediction - vy).mean()),
              "normalized_epoch_mse": losses, "metric_unit": data["metadata"]["action_unit"],
              "final_test_used_for_training": False, "normalization_fit_split": "train",
              "sample_period_s_verified": data["sample_period_s_verified"],
              "task_success": "not_evaluated", "real_robot_validation": "not_run",
              "label_source_declared": data["metadata"]["label_source"], "demonstration_quality_verified": False,
              "dependency_versions": {"numpy": np.__version__, "torch": torch.__version__ if use_torch else None},
              "limitations": ["Supervised action error is not closed-loop task success.",
                              "Synthetic or simulator labels do not establish real robot transfer.",
                              "Original ACT image/CVAE stack and user ACT assets are not integrated."]}
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(out / "weights.npz", **weights)
    manifest["weights_sha256"] = hashlib.sha256((out / "weights.npz").read_bytes()).hexdigest()
    _json_write(out / "policy_manifest.json", manifest)
    _json_write(out / "training_report.json", report)
    return report


def load_chunk_policy(checkpoint_dir: Path) -> ChunkPolicy:
    root = Path(checkpoint_dir)
    manifest = _strict_json((root / "policy_manifest.json").read_text(encoding="utf-8"))
    if manifest.get("schema_version") != 1 or manifest.get("weights_file") != "weights.npz":
        raise ValueError("unsupported checkpoint manifest")
    for key, limit in (("observation_dim", 512), ("action_dim", 64), ("chunk_size", 32)):
        if type(manifest.get(key)) is not int or not 1 <= manifest[key] <= limit:
            raise ValueError("invalid checkpoint dimensions")
    if (root / "weights.npz").stat().st_size > MAX_ARCHIVE_BYTES:
        raise ValueError("checkpoint exceeds bounded input budget")
    if hashlib.sha256((root / "weights.npz").read_bytes()).hexdigest() != manifest.get("weights_sha256"):
        raise ValueError("checkpoint checksum mismatch")
    weights = _load_npz(root / "weights.npz")
    np = _numpy()
    if any(value.dtype.kind not in "fi" or not np.isfinite(value).all() for value in weights.values()):
        raise ValueError("checkpoint weights must be finite numeric arrays")
    return ChunkPolicy(manifest, weights)


def evaluate_chunk_policy(checkpoint_dir: Path, dataset_path: Path, split="test") -> dict:
    """Evaluate a fixed checkpoint on episode-held-out labels; no task claim."""
    np = _numpy()
    if split not in {"validation", "test"}:
        raise ValueError("evaluation requires validation or test split")
    policy, data = load_chunk_policy(Path(checkpoint_dir)), load_chunk_dataset(Path(dataset_path))
    contract_keys = ("observation_names", "action_names", "action_unit", "action_semantics", "time_unit", "clock_domain")
    if any(data["metadata"][key] != policy.manifest["contract"][key] for key in contract_keys):
        raise ValueError("dataset names, units or timing do not match policy contract")
    if not math.isclose(data["sample_period_s_verified"], policy.manifest["sample_period_s_verified"], rel_tol=1e-5, abs_tol=1e-8):
        raise ValueError("dataset sample period does not match policy timing contract")
    episodes = set(data["episode_ids"][data["splits"] == split].tolist())
    forbidden = set(policy.manifest["train_episode_ids"])
    if split == "test":
        forbidden.update(policy.manifest["validation_episode_ids"])
    if episodes & forbidden:
        raise ValueError("evaluation episode leakage detected")
    x, y = _windows(data, policy.manifest["chunk_size"], split)
    predicted = policy.predict(x)
    report = {"status": "passed", "execution_kind": data["metadata"]["data_kind"],
              "backend": policy.manifest["backend"], "split": split, "episodes": sorted(episodes),
              "windows": len(x), "mae": float(np.abs(predicted - y).mean()),
              "mse": float(np.square(predicted - y).mean()), "metric_unit": data["metadata"]["action_unit"],
              "task_success": "not_evaluated", "real_robot_validation": "not_run",
              "dataset_sha256": data["source_sha256"], "checkpoint_weights_sha256": policy.manifest["weights_sha256"]}
    _json_write(Path(checkpoint_dir) / f"{split}_evaluation.json", report)
    return report
